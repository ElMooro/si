╔══════════════════════════════════════════════════╗
║     JUSTHODL BLOOMBERG TERMINAL V10.3            ║
║     Built by Khalid | justhodl.ai                ║
╠══════════════════════════════════════════════════╣
║                                                  ║
║  HOW TO LAUNCH:                                  ║
║  Double-click "JustHodl Terminal.vbs"            ║
║  (or "JustHodl Terminal.bat")                    ║
║                                                  ║
║  This opens as a native desktop app with no      ║
║  browser chrome - just the pure terminal.        ║
║                                                  ║
║  PIN TO TASKBAR:                                 ║
║  Right-click the running app in taskbar          ║
║  → "Pin to taskbar" for quick access             ║
║                                                  ║
║  CREATE DESKTOP SHORTCUT:                        ║
║  Right-click "JustHodl Terminal.vbs"             ║
║  → Send to → Desktop (create shortcut)           ║
║                                                  ║
╠══════════════════════════════════════════════════╣
║  WHAT'S INCLUDED:                                ║
║  • 188 Stocks & ETFs with full technicals        ║
║  • 230+ FRED economic series                     ║
║  • 25 Cryptocurrencies                           ║
║  • 11 ECB CISS systemic stress indicators        ║
║  • AI Chat (Claude-powered, live market data)    ║
║  • AI Agent (10 autonomous analysis tasks)       ║
║  • Khalid Index™ proprietary scoring             ║
║  • 40+ Breaking news headlines                   ║
║  • Auto-updates at 8AM & 6PM ET                  ║
║  • 20 dashboard tabs                             ║
║                                                  ║
║  REQUIREMENTS:                                   ║
║  • Windows 10 or 11                              ║
║  • Edge or Chrome browser (pre-installed)        ║
║  • Internet connection                           ║
║  • No installation needed                        ║
╚══════════════════════════════════════════════════╝
