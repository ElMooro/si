# ops 5209 -- KATLIN v2.0.0 learning loop

**Status:** success  
**Duration:** 661.9s  
**Finished:** 2026-09-07T15:43:58+00:00  

## Error

```
SystemExit: 0
```

## Log
- `15:32:56`    env keys from justhodl-equity-research: ['FMP_KEY', 'POLYGON_API_KEY']
- `15:32:57`   Lambda exists — updating
- `15:33:00` ✅   ✓ updated justhodl-katlin
- `15:33:10`    function state Active / Successful, 8192MB / 900s
- `15:33:11`    walk-forward invoked async (prior as_of=2026-09-06T09:38:07Z)
## walk-forward v2.0.0: 40542 obs, 31 dates, 442.9s, budget_hit=None, universe {'stocks': 1800, 'etfs': 320, 'sampling': 'seeded random sample of the tradable universe; point-in-time $2M ADV / $2 price'}

- `15:40:37`    cohort                       63s n/mean/med/hit/p90         | 126s                           | 252s                          
- `15:40:37`    above200                     22627   -0.7  -2.69 43.0  21.78 | 20756  -1.36  -5.17 40.0  31.42 | 16010  -4.04  -11.2 35.0  44.68
- `15:40:37`    below200                     16093  -1.48  -3.69 41.0  22.98 | 14931  -3.78  -8.92 36.0  31.47 | 12454  -4.94 -15.32 34.0  49.03
- `15:40:37`    below200+washout             15546  -1.43  -3.68 41.0  23.55 | 14453  -3.67  -8.95 36.0  32.26 | 12051  -4.69 -15.46 34.0  50.94
- `15:40:37`    below200+oversold            12446  -1.37  -3.55 41.0  24.02 | 11579   -4.0  -9.38 35.0  32.66 |  9788  -5.16 -16.07 33.0   49.3
- `15:40:37`    below200+structure            6357  -1.54  -3.84 41.0  22.44 |  5888   -3.9  -8.77 36.0  30.97 |  4899   -6.9 -15.46 33.0  45.31
- `15:40:37`    below200+confirmed            3849  -1.95  -4.37 40.0   22.3 |  3586   -4.9  -9.28 35.0   29.7 |  2977  -8.36 -15.94 33.0  41.51
- `15:40:37`    below200+accum                1977  -2.34  -4.13 40.0  20.71 |  1887  -4.35  -8.43 36.0  31.08 |  1618   -7.2 -15.62 34.0  44.61
- `15:40:37`    confirmed+oversold+washout    2502   -2.0  -4.56 41.0  23.54 |  2332  -4.93  -9.45 36.0  31.64 |  1993  -8.03 -16.01 34.0  45.46
- `15:40:37`    KATLIN_price_3of3              636   -2.2  -4.72 40.0  22.97 |   610  -1.62  -6.35 39.0  36.69 |   546  -6.23 -11.83 36.0  44.61
- `15:40:37`    confirmed_bottom+accum         688  -2.79  -5.22 38.0  20.22 |   662  -2.88  -7.91 37.0   34.2 |   573  -7.55 -13.72 36.0  44.61
- `15:40:37`    knife                          249   3.11  -4.27 45.0  52.04 |   225   6.68  -7.57 44.0  79.83 |   180  24.63 -12.41 42.0 131.53
- `15:40:37`    OOS 63s: split 2025-02-03 train 21957 test 17012 spread 3.72 corr 0.014 top {'mean_excess_pct': 2.62, 'median_excess_pct': -3.48, 'hit_rate_pct': 44.0} bottom {'mean_excess_pct': -1.11, 'median_excess_pct': -2.66, 'hit_rate_pct': 41.0} below200-top {'n': 716, 'mean_excess_pct': 2.78, 'median_excess_pct': -2.52, 'hit_rate_pct': 45.0, 'spread_vs_bottom_pct': 5.21}
- `15:40:37`    OOS 126s: split 2025-02-03 train 21954 test 13958 spread 12.41 corr 0.093 top {'mean_excess_pct': 7.87, 'median_excess_pct': -7.4, 'hit_rate_pct': 44.0} bottom {'mean_excess_pct': -4.55, 'median_excess_pct': -9.13, 'hit_rate_pct': 34.0} below200-top {'n': 600, 'mean_excess_pct': 8.28, 'median_excess_pct': -8.22, 'hit_rate_pct': 44.0, 'spread_vs_bottom_pct': 16.37}
- `15:40:37`    feature_stats 126s grand mean -2.31 over 35912 obs; features: ['accum', 'bbw', 'cls', 'd200', 'dbs', 'dd52', 'hl', 'mkt', 'mom', 'rsi_div', 'rsi_w', 'struct', 'tbreak', 'vol', 'volr']
- `15:40:37`    d200    >0%: n=20756 mean=-1.36 hit=40.0 | -30..-15%: n=3642 mean=-3.29 hit=37.0 | -6..0%: n=4946 mean=-4.68 hit=34.0 | -15..-6%: n=4989 mean=-5.63 hit=34.0 | -50..-30%: n=1324 mean=3.94 hit=43.0 | <-50%: n=255 mean=12.06 hit=44.0
- `15:40:37`    rsi_w   >60: n=8833 mean=-0.31 hit=41.0 | 50-60: n=11554 mean=-2.56 hit=39.0 | 40-50: n=10429 mean=-2.76 hit=37.0 | 30-40: n=4331 mean=-4.26 hit=36.0 | <30: n=765 mean=-4.69 hit=34.0
- `15:40:37`    struct  NONE: n=14570 mean=-2.23 hit=38.0 | CONFIRMED: n=16283 mean=-2.35 hit=39.0 | FORMING: n=5059 mean=-2.44 hit=38.0
- `15:40:37`    dd52    >-10%: n=13118 mean=-2.15 hit=40.0 | -25..-10%: n=11214 mean=-4.22 hit=36.0 | -65..-45%: n=3079 mean=3.68 hit=41.0 | -45..-25%: n=7633 mean=-3.33 hit=37.0 | <-65%: n=868 mean=7.43 hit=43.0
- `15:40:37`    vol     25-45%: n=16651 mean=-4.51 hit=38.0 | 45-70%: n=8372 mean=-0.17 hit=42.0 | >70%: n=4377 mean=7.78 hit=41.0 | <25%: n=6512 mean=-6.25 hit=31.0
- `15:40:37`    mkt     SPY<200d: n=4978 mean=-2.85 hit=33.0 | SPY>200d: n=30934 mean=-2.23 hit=39.0
- `15:40:37`    regime below200             {'SPY<200d': (2788, -1.59, 35.0), 'SPY>200d': (12143, -4.28, 36.0)}
- `15:40:37`    regime below200+confirmed   {'SPY<200d': (454, -4.67, 33.0), 'SPY>200d': (3132, -4.94, 35.0)}
- `15:40:37`    regime KATLIN_price_3of3    {'SPY<200d': (83, 5.77, 49.0), 'SPY>200d': (527, -2.79, 38.0)}
- `15:40:37`    regime knife                {'SPY<200d': (69, 12.16, 46.0), 'SPY>200d': (156, 4.26, 43.0)}
- `15:40:37`    regime above200             {'SPY<200d': (2121, -5.0, 30.0), 'SPY>200d': (18635, -0.95, 41.0)}
- `15:40:38`    invoked async (prior generated_at=2026-09-05T04:13:13Z); polling data/katlin.json
- `15:43:24`    fresh artifact after 166s: v2.0.0 session 2026-09-04 elapsed 157.3s
## war room

- `15:43:24`    posture FULL_RISK cap 75% thermometer 34.5 legs 16 red 0 vetoes []
- `15:43:24`    missing legs: []
- `15:43:24`       Bond heartbeat                     8.0 GREEN CALM -- Bond markets are calm: Japan 30Y (JGB) -8.7bp (z -2.4); Australia 3Y +10.1bp (z +2.0); Australia 2s10s
- `15:43:24`       Bond volatility -> stocks           40 GREEN CALM: Bond prices and yields are inside their normal daily range (TLT +0.2% (z +0.3); 10Y +0.4bp (z +0.0); MOV
- `15:43:24`       Eurodollar shortage                 20 GREEN NONE (0 pts)
- `15:43:24`       Treasury auction desk               20 GREEN $12.5B buyback at max · $185.5B bills -> risk-on supportive [LIQUIDITY EASY, EASY-POLICY SIGNAL, RISK-ASSET BU
- `15:43:24`       Risk gate (brain)                   40 GREEN NEUTRAL -- sizing x0.75
- `15:43:24`       Black-swan watch                    55 AMBER barometer 13.0, 1 red extremes today -- strip RED
- `15:43:24`       Crisis composite                   27.0 GREEN NORMAL (DEFCON 4.0) -- no single component in stress territory
- `15:43:24`       Options tail risk (P[-10%])         20 GREEN 2% option-implied chance of a 10% drop; system tail gauge 48/100 (WATCH)
- `15:43:24`       Regime composite                    55 AMBER LATE_CYCLE / late-cycle -- Risk-on continues (risk=+0.67) BUT policy hawkish (pol=-1.00) + reflation elevated 
- `15:43:24`       Volatility regime                   25 GREEN CONCERNED (score 42.2)
- `15:43:24`       VIX term structure                  25 GREEN NORMAL_CONTANGO -- VIX 14.53
- `15:43:24`       Credit spreads (visible liquidity)  25 GREEN MELTUP_PRONE
- `15:43:24`       Global recession probability       44.0 GREEN 29% (BENIGN — expansion intact)
- `15:43:24`       Global business cycle              35.0 GREEN phase GLOBAL_EXPANSION -- CLI 100.0 -- 6m downturn prob 35%
- `15:43:24`       Dollar (view first)                 45 AMBER NEUTRAL -- Dollar Pressure +14/100 -- NEUTRAL. 7 canaries lean pump, 3 lean dump. Risk-asset transmission: NEU
- `15:43:24`       Global liquidity impulse           58.0 AMBER NEUTRAL -- 13w impulse -1.3%
- `15:43:24`    brief: Risk thermometer 35/100 across 16 fleet legs (0 red, 4 amber). Posture FULL RISK: green light -- deploy into the best asymmetric setups. Loudest warnings: Global liquidity impulse (NEUTRAL -- 13w impulse -1.3%); Black-swan watch (barometer 13.0, 1 red extremes today -- strip RED); Regime composite (LATE_CYCLE / late-cycle -- Risk-on continues (risk=+0.67) BUT policy hawkish (po). Supportive: Bond heartbeat (CALM -- Bond markets are calm: Japan 30Y (JGB) -8.7bp (z -2.4); Austra); Eurodollar shortage (NONE (0 pts)). Cycle: global phase GLOBAL_EXPANSION, CLI 100.0. Crypto dump-risk 32/100 from th
## universe / tiers / gates

- `15:43:24`    universe {"stocks_in_universe": 3838, "etfs_in_universe": 3647, "crypto_symbols": 93, "scored": 5761, "stocks_scored": 3099, "etfs_scored": 2578, "crypto_scored": 84, "sessions": 1260, "first_session": "2021-08-30", "published": 1512}
- `15:43:24`    tiers {"KATLIN_PRIME": 3, "READY": 91, "BASING": 129, "WATCH": 1289, "SCREENED": 4249}
- `15:43:24`    gates {"location": 1926, "washout": 2462, "oversold": 1574, "accumulation": 1911, "inflows": 1947, "structure": 3572, "catalyst": 359, "not_knife": 5731, "quality": 5562}
- `15:43:24`    degraded []
## joins on the picks (PROBE-THEN-WIRE: a silent zero here is a bug, not a quiet market)

- `15:43:24`    inflow_legs       218 / 223 picks (98%)
- `15:43:24`    inflow_evidence    51 / 223 picks (23%)
- `15:43:24`    catalysts         113 / 223 picks (51%)
- `15:43:24`    fleet_accum        88 / 223 picks (39%)
- `15:43:24`    quality_pe        116 / 223 picks (52%)
- `15:43:24`    dilution          173 / 223 picks (78%)
- `15:43:24`    dark_pool          56 / 223 picks (25%)
- `15:43:24`    f13               164 / 223 picks (74%)
- `15:43:24`    industry_flow     173 / 223 picks (78%)
- `15:43:24`    sniper             70 / 223 picks (31%)
- `15:43:24`    why               223 / 223 picks (100%)
- `15:43:24`    plan              223 / 223 picks (100%)
## top of the board

- `15:43:24`    RNA    KATLIN_PRIME stock  score  78.9 conv  68.6 vs200  -57.2 rsiW 33.5 CONFIRMED acc 57.0 inf 60.0 cat 38.4 rr 10.0 4h WAIT
- `15:43:24`    KBR    KATLIN_PRIME stock  score  61.0 conv  58.2 vs200   -3.8 rsiW 48.3 CONFIRMED acc 77.8 inf 64.1 cat 52.1 rr  2.3 4h WAIT
- `15:43:24`    SNY    KATLIN_PRIME stock  score  58.4 conv  56.0 vs200   -3.3 rsiW 47.7 CONFIRMED acc 71.5 inf 69.3 cat 37.1 rr  3.5 4h WAIT
- `15:43:24`    UPWK   READY        stock  score  69.8 conv  65.9 vs200  -31.6 rsiW 39.6 CONFIRMED acc 62.4 inf 40.1 cat 38.4 rr 10.0 4h WAIT_BREAK
- `15:43:24`    TIGR   READY        stock  score  69.2 conv  67.0 vs200  -24.9 rsiW 42.4 CONFIRMED acc 56.4 inf 57.0 cat  0.0 rr  9.8 4h SNIPE_PULLBACK
- `15:43:24`    ADMA   READY        stock  score  67.8 conv  66.5 vs200  -23.9 rsiW 44.5 CONFIRMED acc 63.5 inf 62.7 cat 25.6 rr 10.0 4h SNIPE_PULLBACK
- `15:43:24`    HCKT   READY        stock  score  66.0 conv  61.7 vs200  -19.5 rsiW 44.3 FORMING   acc 66.1 inf 51.7 cat 16.6 rr  8.3 4h SNIPE_PULLBACK
- `15:43:24`    TLRY   READY        stock  score  65.9 conv  57.8 vs200  -32.1 rsiW 37.5 FORMING   acc 59.6 inf 52.3 cat 24.4 rr 10.0 4h SNIPE_PULLBACK
- `15:43:24`    KROS   READY        stock  score  63.5 conv  48.2 vs200  -17.1 rsiW 47.1 CONFIRMED acc 59.7 inf 64.3 cat 25.6 rr  9.9 4h WAIT
- `15:43:24`    DXC    READY        stock  score  62.7 conv  53.0 vs200   -2.0 rsiW 54.4 CONFIRMED acc 59.6 inf 56.6 cat 29.4 rr  2.4 4h WAIT
- `15:43:24`    CWH    READY        stock  score  61.6 conv  53.3 vs200  -17.7 rsiW 45.1 FORMING   acc 72.7 inf 36.8 cat 12.8 rr 10.0 4h WAIT
- `15:43:24`    ARVN   READY        stock  score  60.8 conv  57.8 vs200  -10.9 rsiW 50.7 CONFIRMED acc 77.7 inf 61.9 cat 25.6 rr  3.0 4h SNIPE_PULLBACK
- `15:43:24`    WHY[RNA]: Atrium Therapeutics Inc (RNA) is a stock trading 57% below its 200-day average and 62% below the 250-day. It has been under that average for 132 sessions, so this is a long downtrend, not a dip. On the long-term chart the bottom looks CONFIRMED: weekly double bottom confirmed, weekly downtrend line broken, weekly RSI bullish divergence. Momentum is washed out: weekly RSI 34 (oversold), monthly RSI 40, weekly RSI turning up from 22. Accumulation fingerprints: volume has dried up: last 20 days run 47% below the 6-month average; up days carry 1.8x the volume of down days over the last month; the 20-day low is holding above the prior 2-month low on shrinking volume (Wyckoff test of support). Money is flowing in: its industry ETF XBI is seeing major inflows (4.4% of AUM over 21d, z 0.1). Catalysts the engine can name: its industry is booming: Biotechnology revenue growth 40% y/y with 100% of 
## v1.2.0 lanes

- `15:43:24`    learned prior on picks: 223 / 223; history: In this regime (SPY>200d) since 2021, names under their 200-day averaged -4.3% vs SPY over the next 6 months (hit 36%, n=12143) against -0.9% for names above it; the top decile of past bottoms did +30.2% -- the edge is in the right tail, which is why the desk ranks by evidence rather than buying every dip.
- `15:43:24`    RNA    KATLIN_PRIME learned  26.58% (n_feat 15) top-lever [('d200', '<-50%', 14.37), ('vol', '>70%', 10.09), ('dd52', '<-65%', 9.75)]
- `15:43:24`    KBR    KATLIN_PRIME learned  -11.7% (n_feat 15) top-lever [('d200', '-6..0%', -2.36), ('vol', '25-45%', -2.19), ('dbs', '1-40', -1.4)]
- `15:43:24`    SNY    KATLIN_PRIME learned -13.88% (n_feat 15) top-lever [('vol', '<25%', -3.94), ('d200', '-6..0%', -2.36), ('dd52', '-25..-10%', -1.9)]
- `15:43:24`    UPWK   READY        learned    8.4% (n_feat 15) top-lever [('d200', '-50..-30%', 6.25), ('dd52', '-65..-45%', 5.99), ('vol', '45-70%', 2.14)]
- `15:43:24`    TIGR   READY        learned   6.25% (n_feat 15) top-lever [('dd52', '-65..-45%', 5.99), ('vol', '45-70%', 2.14), ('mom', '>60', 1.38)]
- `15:43:24`    ADMA   READY        learned   1.67% (n_feat 15) top-lever [('dd52', '-65..-45%', 5.99), ('vol', '45-70%', 2.14), ('mom', '40-60', -1.27)]
- `15:43:24`    HCKT   READY        learned   7.39% (n_feat 15) top-lever [('dd52', '-65..-45%', 5.99), ('vol', '45-70%', 2.14), ('dbs', '>250', 1.71)]
- `15:43:24`    TLRY   READY        learned  18.74% (n_feat 15) top-lever [('vol', '>70%', 10.09), ('dd52', '<-65%', 9.75), ('d200', '-50..-30%', 6.25)]
- `15:43:24`    washout gate passes: 2462 of 5761 scored
- `15:43:24`    ports catalysts on picks: 14; T1 labels: ['100-day average', '200-day average', '50-day average', '52-week high', 'neckline']
- `15:43:24`    [katlin] feeds in 3.2s: finviz=11606 census=492 boom=129 rotation=40 flows=300/128 f13=7526 dark=936 insider=24 congress=32 options=58 blocks=12 catalyst=201 calendar=91 contracts=79 backlog=121 floor=168 ports=16 fleet_accum=814 warroom=bond_warroom,auction,risk_gate,blackswan,crisis,tail,regime,vo
- `15:43:24`    [katlin] war room: FULL_RISK (therm 34.5, 16 legs, vetoes [], missing [])
- `15:43:24`    [katlin] stocks scored: 3099 (thin 384, hygiene 355) in 45s
- `15:43:24`    [katlin] crypto lane: 93 symbols banked, 89 with >=200 days, 0 errors (BTC=ok:+2, ETH=ok:+2, SOL=ok:+2, XRP=ok:+2, BNB=ok:+2)
- `15:43:24`    [katlin] dilution lane: 196 names, {'banked': 193, 'fmp': 3}, 1s
- `15:43:24`    [katlin] sniper: 70/70 shortlist names got 4h bars (0 errors)
- `15:43:24`    picks with a NAMED catalyst: 74 / 223; catalyst gate passes: 359
- `15:43:24`    catalyst kinds across picks: [('industry_boom', 74), ('squeeze', 37), ('ports', 14), ('scheduled', 8), ('contracts', 5), ('cycle', 4), ('backlog', 4), ('earnings', 2)]
- `15:43:24`    dilution coverage on stock picks: 173 / 174 (fmp-sourced 150)
- `15:43:24`    RNA catalysts: ['its industry is booming: Biotechnology revenue growth 40% y/y with 100', '20% of the float is short with 19.2 days to cover -- fuel for a violen']
- `15:43:24`    RNA plan: {'entry': 14.19, 'stop': 12.71, 'target_1': 33.18, 'target_1_label': '200-day average', 'target_2': 72.93, 'target_2_label': '52-week high', 'upside_1_pct': 133.8, 'upside_2_pct': 414.0, 'downside_pct': 10.5, 'rr_1': 10.0, 'rr_2': 10.0, 'asymmetry': 19.1, 'confirmation_trigger': None, 'rr_best': 10.0} | 3m 15.4 | days<200 132 | knife False
- `15:43:24`    KBR catalysts: ['2 contract/licensing win(s) in 90 days worth $268M = 5.8% of market ca', 'its industry is booming: Engineering & Construction revenue growth 55%']
- `15:43:24`    KBR plan: {'entry': 36.82, 'stop': 31.17, 'target_1': 49.81, 'target_1_label': '52-week high', 'target_2': None, 'target_2_label': None, 'upside_1_pct': 35.3, 'upside_2_pct': None, 'downside_pct': 15.3, 'rr_1': 2.3, 'rr_2': None, 'asymmetry': 2.3, 'confirmation_trigger': 38.04, 'rr_best': 2.3} | 3m 1.9 | days<200 10 | knife False
- `15:43:24`    SNY catalysts: ['its industry is booming: Drug Manufacturers - General revenue growth 4', 'port traffic tied to Drug Manufacturers - General is up 10% y/y (Shang']
- `15:43:24`    SNY plan: {'entry': 44.24, 'stop': 41.94, 'target_1': 52.34, 'target_1_label': '52-week high', 'target_2': None, 'target_2_label': None, 'upside_1_pct': 18.3, 'upside_2_pct': None, 'downside_pct': 5.2, 'rr_1': 3.5, 'rr_2': None, 'asymmetry': 3.5, 'confirmation_trigger': 45.66, 'rr_best': 3.5} | 3m -0.3 | days<200 142 | knife False
- `15:43:24`    UPWK catalysts: ['its industry is booming: Internet Content & Information revenue growth', '16% of the float is short with 5.6 days to cover -- fuel for a violent']
- `15:43:24`    UPWK plan: {'entry': 8.79, 'stop': 8.17, 'target_1': 9.91, 'target_1_label': 'neckline', 'target_2': 22.11, 'target_2_label': '52-week high', 'upside_1_pct': 12.7, 'upside_2_pct': 151.5, 'downside_pct': 7.0, 'rr_1': 1.8, 'rr_2': 10.0, 'asymmetry': 9.3, 'confirmation_trigger': 9.91, 'rr_best': 10.0} | 3m 0.6 | days<200 144 | knife False
- `15:43:24`    TIGR catalysts: []
- `15:43:24`    TIGR plan: {'entry': 5.08, 'stop': 4.35, 'target_1': 5.29, 'target_1_label': '100-day average', 'target_2': 12.29, 'target_2_label': '52-week high', 'upside_1_pct': 4.1, 'upside_2_pct': 141.9, 'downside_pct': 14.5, 'rr_1': 0.3, 'rr_2': 9.8, 'asymmetry': 5.1, 'confirmation_trigger': 5.09, 'rr_best': 9.8} | 3m 6.7 | days<200 163 | knife False
- `15:43:24`    ADMA catalysts: ['its industry is booming: Biotechnology revenue growth 40% y/y with 100']
- `15:43:24`    ADMA plan: {'entry': 9.62, 'stop': 8.94, 'target_1': 12.64, 'target_1_label': '200-day average', 'target_2': 20.38, 'target_2_label': '52-week high', 'upside_1_pct': 31.4, 'upside_2_pct': 111.9, 'downside_pct': 7.0, 'rr_1': 4.5, 'rr_2': 10.0, 'asymmetry': 9.2, 'confirmation_trigger': 14.84, 'rr_best': 10.0} | 3m 20.6 | days<200 161 | knife False
## field coverage (artifact keys)

- `15:43:24`    top-level: ['as_of', 'base_rates', 'changes', 'definitions', 'degraded', 'elapsed_s', 'engine', 'feeds_asof', 'gates', 'generated_at', 'history', 'log', 'market', 'panels', 'params', 'picks', 'schema', 'session', 'tiers', 'top_picks', 'universe', 'validation', 'version', 'war_room', 'watch', 'weights']
- `15:43:24`    panels: {'war_room': 16, 'prime': 3, 'ready': 60, 'basing': 60, 'etfs': 40, 'crypto': 37}
- `15:43:24`    pick row keys (114): ['above_ema10_w', 'absorption_clv', 'accum_evidence', 'accum_legs', 'ad_slope_40', 'adv_usd', 'alpha_prior', 'asset_class', 'asymmetry', 'atr_pctile', 'base_weeks', 'bbw_pctile', 'below_sma200', 'below_sma250', 'beta_1y', 'catalysts', 'composite', 'conviction', 'country', 'cvar5_pct', 'days_below_sma200', 'dd_52w_pct', 'dist_ema200_pct', 'dist_ema250_pct', 'dist_sma200_pct', 'dist_sma250_pct', 'double_bottom_d', 'double_bottom_w', 'ema200', 'ema250', 'evidence_coverage_pct', 'fleet_accumulation', 'gap_risk_pct', 'gates', 'gates_passed', 'high_52w', 'higher_lows_w', 'industry', 'industry_etf', 'inflow_evidence', 'inflow_legs', 'knife', 'knife_why', 'last', 'learned_excess_126s_pct', 'location_legs', 'low_52w', 'lower_half_days_20', 'lower_highs_w', 'lower_lows_w', 'lt_downtrend', 'lt_trend_break', 'm_close_vs_sma12_pct', 'm_higher_low', 'm_lower_lows', 'm_ret_pct', 'macd_w_turn', 'max_dd_1y_pct', 'mcap', 'mom_evidence', 'mom_legs', 'n_months', 'n_named_catalysts', 'n_quarters', 'n_weeks', 'name', 'obv_slope_40', 'oversold_legs', 'pct_b', 'pillars', 'plan', 'pos_52w_pct', 'posture_note', 'q_break', 'q_lower_highs', 'q_ret_pct', 'quality', 'ret_12m_pct', 'ret_1m_pct', 'ret_3m_pct', 'ret_6m_pct', 'roc20_cross_days', 'rr', 'rs_63_pct', 'rs_slope_20', 'rsi_d', 'rsi_div_d', 'rsi_div_w', 'rsi_m', 'rsi_w', 'rsi_w_turning_up', 'sector', 'sessions', 'sma100', 'sma200', 'sma200_slope_20_pct', 'sma250', 'sma40w_falling', 'sma50', 'sniper', 'squeeze', 'squeeze_lean', 'structure_legs', 'structure_state', 'sub_class', 'ticker', 'tier', 'trendline_level', 'updown_vol_20', 'vol_ann_pct', 'vol_ratio_20_120', 'weeks_since_break', 'why', 'worst_day_1y_pct']
## schedules

- `15:43:24`    justhodl-katlin-daily cron(10 4 ? * TUE-SAT *) ENABLED
- `15:43:24`    justhodl-katlin-backtest-weekly cron(30 9 ? * SUN *) ENABLED
## page

- `15:43:24`    katlin.html carries marker KATLIN_DESK_V1 at the edge: True
- `15:43:46`    1440px: {"score": "35", "posture": "FULL RISK", "headline": "green light -- deploy into the best asymmetric setups", "legs": 16, "board": 3, "evid": 1630, "helps": 26, "defs": 18, "valextra": 69, "hist": true, "overflow": 0, "err": ""} errors=[]
- `15:43:58`     390px: {"score": "35", "posture": "FULL RISK", "headline": "green light -- deploy into the best asymmetric setups", "legs": 16, "board": 3, "evid": 1630, "helps": 26, "defs": 18, "valextra": 69, "hist": true, "overflow": 0, "err": ""} errors=[]
- `15:43:58` ✅    GREEN: KATLIN live -- engine, feed, schedules, page
