# ops 5210 -- KATLIN v2.1.0

**Status:** success  
**Duration:** 591.9s  
**Finished:** 2026-09-07T15:57:48+00:00  

## Error

```
SystemExit: 0
```

## Log
- `15:47:56`    env keys from justhodl-equity-research: ['FMP_KEY', 'POLYGON_API_KEY']
- `15:47:57`   Lambda exists — updating
- `15:48:03` ✅   ✓ updated justhodl-katlin
- `15:48:08`    function state Active / Successful, 8192MB / 900s
- `15:48:08`    walk-forward invoked async (prior as_of=2026-09-07T15:40:34Z)
## walk-forward v2.1.0: 40542 obs, 31 dates, 393.1s, budget_hit=None, universe {'stocks': 1800, 'etfs': 320, 'sampling': 'seeded random sample of the tradable universe; point-in-time $2M ADV / $2 price'}

- `15:54:50`    cohort                       63s n/mean/med/hit/p90         | 126s                           | 252s                          
- `15:54:50`    above200                     22627   -0.7  -2.69 43.0  21.78 | 20756  -1.36  -5.17 40.0  31.42 | 16010  -4.04  -11.2 35.0  44.68
- `15:54:50`    below200                     15891  -1.59  -3.72 41.0  22.55 | 14744  -3.95  -8.96 36.0  30.85 | 12289  -5.28  -15.3 34.0  48.28
- `15:54:50`    below200+washout             15344  -1.54   -3.7 41.0  23.14 | 14266  -3.84  -9.01 36.0   31.8 | 11886  -5.04 -15.32 34.0  49.76
- `15:54:50`    below200+oversold            12245   -1.5  -3.57 41.0  23.41 | 11393   -4.2  -9.43 35.0  32.18 |  9624  -5.59 -16.03 33.0  48.26
- `15:54:50`    below200+structure            2449   -1.9  -4.18 40.0  23.16 |  2280  -4.17  -7.93 37.0  31.38 |  1831  -6.56 -13.91 35.0  46.42
- `15:54:50`    below200+confirmed             763  -1.15  -4.72 42.0  24.75 |   704  -2.64  -8.32 36.0  30.97 |   550  -7.23  -15.2 33.0  40.35
- `15:54:50`    below200+accum                1973  -2.33  -4.13 40.0  20.59 |  1883  -4.44  -8.44 36.0  30.75 |  1615  -7.36 -15.61 34.0  44.44
- `15:54:50`    KATLIN_price_3of3              280  -4.07  -5.66 36.0  22.35 |   267  -4.75  -7.05 39.0  36.69 |   244  -9.84 -13.81 34.0  38.32
- `15:54:50`    knife                          451   4.79  -1.56 48.0  53.79 |   412    8.0  -6.28 45.0  79.83 |   345  22.48  -14.8 41.0 143.98
- `15:54:50`    confirmed+oversold+washout     514  -0.86  -5.02 40.0  27.49 |   472  -2.99 -10.71 33.0  32.24 |   387  -7.53 -16.01 33.0  39.17
- `15:54:50`    confirmed_bottom+accum         143  -4.89  -8.04 37.0  19.85 |   137  -4.58  -10.6 34.0  39.47 |   115  -8.31 -12.57 36.0  33.85
- `15:54:50`    OOS 63s: split 2025-02-03 train 21957 test 17012 spread 3.68 corr 0.018 top {'mean_excess_pct': 2.91, 'median_excess_pct': -3.67, 'hit_rate_pct': 44.0} bottom {'mean_excess_pct': -0.77, 'median_excess_pct': -1.93, 'hit_rate_pct': 44.0} below200-top {'n': 708, 'mean_excess_pct': 2.31, 'median_excess_pct': -2.56, 'hit_rate_pct': 44.0, 'spread_vs_bottom_pct': 5.25}
- `15:54:50`    OOS 126s: split 2025-02-03 train 21954 test 13958 spread 14.27 corr 0.097 top {'mean_excess_pct': 9.31, 'median_excess_pct': -6.29, 'hit_rate_pct': 45.0} bottom {'mean_excess_pct': -4.96, 'median_excess_pct': -8.26, 'hit_rate_pct': 35.0} below200-top {'n': 593, 'mean_excess_pct': 8.04, 'median_excess_pct': -8.25, 'hit_rate_pct': 43.0, 'spread_vs_bottom_pct': 15.96}
- `15:54:50`    feature_stats 126s grand mean -2.31 over 35912 obs; features: ['accum', 'bbw', 'cls', 'd200', 'dbs', 'dd52', 'hl', 'mkt', 'mom', 'rsi_div', 'rsi_w', 'struct', 'tbreak', 'vol', 'volr']
- `15:54:50`    accum   40-55: n=11911 mean=-2.2 hit=38.0 | 55-70: n=5999 mean=-2.56 hit=38.0 | <40: n=17120 mean=-2.26 hit=38.0 | >70: n=882 mean=-3.29 hit=37.0
- `15:54:50`    bbw     40-70: n=9998 mean=-1.99 hit=38.0 | 10-20: n=3832 mean=-2.14 hit=39.0 | >70: n=10213 mean=-2.15 hit=38.0 | 20-40: n=6945 mean=-2.5 hit=38.0 | <=10: n=4924 mean=-3.19 hit=39.0
- `15:54:50`    cls     stock: n=33905 mean=-2.17 hit=39.0 | etf: n=2007 mean=-4.8 hit=27.0
- `15:54:50`    d200    >0%: n=20756 mean=-1.36 hit=40.0 | -30..-15%: n=3642 mean=-3.29 hit=37.0 | -6..0%: n=4946 mean=-4.68 hit=34.0 | -15..-6%: n=4989 mean=-5.63 hit=34.0 | -50..-30%: n=1324 mean=3.94 hit=43.0 | <-50%: n=255 mean=12.06 hit=44.0
- `15:54:50`    dbs     0: n=20756 mean=-1.36 hit=40.0 | 121-250: n=2952 mean=-3.07 hit=36.0 | 1-40: n=6981 mean=-3.71 hit=36.0 | 41-120: n=4705 mean=-4.16 hit=35.0 | >250: n=518 mean=-0.6 hit=39.0
- `15:54:50`    dd52    >-10%: n=13118 mean=-2.15 hit=40.0 | -25..-10%: n=11214 mean=-4.22 hit=36.0 | -65..-45%: n=3079 mean=3.68 hit=41.0 | -45..-25%: n=7633 mean=-3.33 hit=37.0 | <-65%: n=868 mean=7.43 hit=43.0
- `15:54:50`    hl      0: n=16696 mean=-2.62 hit=37.0 | 2+: n=9651 mean=-1.61 hit=41.0 | 1: n=9565 mean=-2.49 hit=38.0
- `15:54:50`    mkt     SPY<200d: n=4978 mean=-2.85 hit=33.0 | SPY>200d: n=30934 mean=-2.23 hit=39.0
- `15:54:50`    mom     40-60: n=12849 mean=-3.58 hit=37.0 | <40: n=10051 mean=-2.48 hit=38.0 | >60: n=13012 mean=-0.94 hit=40.0
- `15:54:50`    rsi_div no: n=34986 mean=-2.2 hit=38.0 | yes: n=926 mean=-6.6 hit=33.0
- `15:54:50`    rsi_w   >60: n=8833 mean=-0.31 hit=41.0 | 50-60: n=11554 mean=-2.56 hit=39.0 | 40-50: n=10429 mean=-2.76 hit=37.0 | 30-40: n=4331 mean=-4.26 hit=36.0 | <30: n=765 mean=-4.69 hit=34.0
- `15:54:50`    struct  NONE: n=21912 mean=-2.67 hit=37.0 | CONFIRMED: n=1889 mean=0.43 hit=39.0 | FORMING: n=12111 mean=-2.1 hit=40.0
- `15:54:50`    tbreak  broken: n=6528 mean=-2.53 hit=38.0 | intact: n=21359 mean=-3.09 hit=37.0 | n/a: n=8025 mean=-0.06 hit=42.0
- `15:54:50`    vol     25-45%: n=16651 mean=-4.51 hit=38.0 | 45-70%: n=8372 mean=-0.17 hit=42.0 | >70%: n=4377 mean=7.78 hit=41.0 | <25%: n=6512 mean=-6.25 hit=31.0
- `15:54:50`    volr    1.0-1.3: n=11672 mean=-3.19 hit=38.0 | 0.6-0.8: n=5702 mean=-1.81 hit=39.0 | 0.8-1.0: n=11682 mean=-2.22 hit=39.0 | >1.3: n=5885 mean=-1.36 hit=38.0 | <0.6: n=971 mean=-1.65 hit=35.0
- `15:54:50`    regime below200             {'SPY<200d': (2747, -1.75, 35.0), 'SPY>200d': (11997, -4.45, 36.0)}
- `15:54:50`    regime below200+confirmed   {'SPY<200d': (117, -7.21, 26.0), 'SPY>200d': (587, -1.73, 38.0)}
- `15:54:50`    regime KATLIN_price_3of3    {'SPY<200d': (46, -3.45, 43.0), 'SPY>200d': (221, -5.02, 38.0)}
- `15:54:50`    regime knife                {'SPY<200d': (110, 10.93, 47.0), 'SPY>200d': (302, 6.93, 44.0)}
- `15:54:50`    regime above200             {'SPY<200d': (2121, -5.0, 30.0), 'SPY>200d': (18635, -0.95, 41.0)}
- `15:54:51`    invoked async (prior generated_at=2026-09-07T15:43:15Z); polling data/katlin.json
- `15:57:12`    fresh artifact after 142s: v2.1.0 session 2026-09-04 elapsed 133.4s
## war room

- `15:57:12`    posture FULL_RISK cap 75% thermometer 34.5 legs 16 red 0 vetoes []
- `15:57:12`    missing legs: []
- `15:57:12`       Bond heartbeat                     8.0 GREEN CALM -- Bond markets are calm: Japan 30Y (JGB) -8.7bp (z -2.4); Australia 3Y +10.1bp (z +2.0); Australia 2s10s
- `15:57:12`       Bond volatility -> stocks           40 GREEN CALM: Bond prices and yields are inside their normal daily range (TLT +0.2% (z +0.3); 10Y +0.4bp (z +0.0); MOV
- `15:57:12`       Eurodollar shortage                 20 GREEN NONE (0 pts)
- `15:57:12`       Treasury auction desk               20 GREEN $12.5B buyback at max · $185.5B bills -> risk-on supportive [LIQUIDITY EASY, EASY-POLICY SIGNAL, RISK-ASSET BU
- `15:57:12`       Risk gate (brain)                   40 GREEN NEUTRAL -- sizing x0.75
- `15:57:12`       Black-swan watch                    55 AMBER barometer 13.0, 1 red extremes today -- strip RED
- `15:57:12`       Crisis composite                   27.0 GREEN NORMAL (DEFCON 4.0) -- no single component in stress territory
- `15:57:12`       Options tail risk (P[-10%])         20 GREEN 2% option-implied chance of a 10% drop; system tail gauge 48/100 (WATCH)
- `15:57:12`       Regime composite                    55 AMBER LATE_CYCLE / late-cycle -- Risk-on continues (risk=+0.67) BUT policy hawkish (pol=-1.00) + reflation elevated 
- `15:57:12`       Volatility regime                   25 GREEN CONCERNED (score 42.2)
- `15:57:12`       VIX term structure                  25 GREEN NORMAL_CONTANGO -- VIX 14.53
- `15:57:12`       Credit spreads (visible liquidity)  25 GREEN MELTUP_PRONE
- `15:57:12`       Global recession probability       44.0 GREEN 29% (BENIGN — expansion intact)
- `15:57:12`       Global business cycle              35.0 GREEN phase GLOBAL_EXPANSION -- CLI 100.0 -- 6m downturn prob 35%
- `15:57:12`       Dollar (view first)                 45 AMBER NEUTRAL -- Dollar Pressure +14/100 -- NEUTRAL. 7 canaries lean pump, 3 lean dump. Risk-asset transmission: NEU
- `15:57:12`       Global liquidity impulse           58.0 AMBER NEUTRAL -- 13w impulse -1.3%
- `15:57:12`    brief: Risk thermometer 35/100 across 16 fleet legs (0 red, 4 amber). Posture FULL RISK: green light -- deploy into the best asymmetric setups. Loudest warnings: Global liquidity impulse (NEUTRAL -- 13w impulse -1.3%); Black-swan watch (barometer 13.0, 1 red extremes today -- strip RED); Regime composite (LATE_CYCLE / late-cycle -- Risk-on continues (risk=+0.67) BUT policy hawkish (po). Supportive: Bond heartbeat (CALM -- Bond markets are calm: Japan 30Y (JGB) -8.7bp (z -2.4); Austra); Eurodollar shortage (NONE (0 pts)). Cycle: global phase GLOBAL_EXPANSION, CLI 100.0. Crypto dump-risk 32/100 from th
## universe / tiers / gates

- `15:57:12`    universe {"stocks_in_universe": 3838, "etfs_in_universe": 3647, "crypto_symbols": 93, "scored": 5761, "stocks_scored": 3099, "etfs_scored": 2578, "crypto_scored": 84, "sessions": 1260, "first_session": "2021-08-30", "published": 1440}
- `15:57:12`    tiers {"KATLIN_PRIME": 1, "READY": 18, "BASING": 186, "CRASH_BARBELL": 34, "WATCH": 1201, "SCREENED": 4321}
- `15:57:12`    gates {"location": 1926, "washout": 2462, "oversold": 1575, "accumulation": 1910, "inflows": 1947, "structure": 2724, "catalyst": 359, "not_knife": 5716, "quality": 5568}
- `15:57:12`    degraded []
## joins on the picks (PROBE-THEN-WIRE: a silent zero here is a bug, not a quiet market)

- `15:57:12`    inflow_legs       234 / 239 picks (98%)
- `15:57:12`    inflow_evidence    60 / 239 picks (25%)
- `15:57:12`    catalysts         135 / 239 picks (56%)
- `15:57:12`    fleet_accum        82 / 239 picks (34%)
- `15:57:12`    quality_pe        112 / 239 picks (47%)
- `15:57:12`    dilution          161 / 239 picks (67%)
- `15:57:12`    dark_pool          55 / 239 picks (23%)
- `15:57:12`    f13               187 / 239 picks (78%)
- `15:57:12`    industry_flow     195 / 239 picks (82%)
- `15:57:12`    sniper             70 / 239 picks (29%)
- `15:57:12`    why               239 / 239 picks (100%)
- `15:57:12`    plan              239 / 239 picks (100%)
## top of the board

- `15:57:12`    RNA    KATLIN_PRIME stock  score  82.1 conv  68.6 vs200  -57.2 rsiW 33.5 CONFIRMED acc 57.0 inf 60.0 cat 38.4 rr 10.0 4h WAIT
- `15:57:12`    ADMA   READY        stock  score  71.0 conv  66.5 vs200  -23.9 rsiW 44.5 CONFIRMED acc 63.5 inf 62.7 cat 25.6 rr 10.0 4h SNIPE_PULLBACK
- `15:57:12`    TLRY   READY        stock  score  71.0 conv  57.8 vs200  -32.1 rsiW 37.5 FORMING   acc 59.6 inf 52.3 cat 24.4 rr 10.0 4h SNIPE_PULLBACK
- `15:57:12`    HCKT   READY        stock  score  69.2 conv  61.7 vs200  -19.5 rsiW 44.3 FORMING   acc 66.1 inf 51.7 cat 16.6 rr  8.3 4h SNIPE_PULLBACK
- `15:57:12`    TIGR   READY        stock  score  67.6 conv  61.6 vs200  -24.9 rsiW 42.4 FORMING   acc 56.4 inf 57.0 cat  0.0 rr  9.8 4h SNIPE_PULLBACK
- `15:57:12`    CWH    READY        stock  score  66.5 conv  53.3 vs200  -17.7 rsiW 45.1 FORMING   acc 72.7 inf 36.8 cat 12.8 rr 10.0 4h WAIT
- `15:57:12`    DXC    READY        stock  score  63.3 conv  53.0 vs200   -2.0 rsiW 54.4 CONFIRMED acc 59.6 inf 56.6 cat 29.4 rr  2.4 4h WAIT
- `15:57:12`    LEU    READY        stock  score  63.2 conv  44.9 vs200  -17.4 rsiW 44.7 CONFIRMED acc 65.7 inf 59.7 cat 12.8 rr 10.0 4h SNIPE_PULLBACK
- `15:57:12`    HUBS   READY        stock  score  63.1 conv  46.7 vs200   -5.0 rsiW 51.1 FORMING   acc 59.2 inf 36.7 cat 25.6 rr 10.0 4h WAIT
- `15:57:12`    SGML   READY        stock  score  62.0 conv  44.3 vs200   -7.9 rsiW 49.1 FORMING   acc 71.5 inf 64.3 cat  0.0 rr  4.9 4h WAIT
- `15:57:12`    ZG     READY        stock  score  61.2 conv  57.1 vs200  -24.3 rsiW 41.1 FORMING   acc 66.6 inf 37.1 cat 25.6 rr  9.1 4h SNIPE_PULLBACK
- `15:57:12`    ORCL   READY        stock  score  59.8 conv  46.6 vs200   -5.9 rsiW 49.0 FORMING   acc 68.9 inf 42.3 cat 54.4 rr  6.7 4h WAIT
- `15:57:12`    WHY[RNA]: Atrium Therapeutics Inc (RNA) is a stock trading 57% below its 200-day average and 62% below the 250-day. It has been under that average for 132 sessions, so this is a long downtrend, not a dip. On the long-term chart the bottom looks CONFIRMED: weekly double bottom confirmed, weekly downtrend line broken, weekly RSI bullish divergence. Momentum is washed out: weekly RSI 34 (oversold), monthly RSI 40, weekly RSI turning up from 22. Accumulation fingerprints: volume has dried up: last 20 days run 47% below the 6-month average; up days carry 1.8x the volume of down days over the last month; the 20-day low is holding above the prior 2-month low on shrinking volume (Wyckoff test of support). Money is flowing in: its industry ETF XBI is seeing major inflows (4.4% of AUM over 21d, z 0.1). Catalysts the engine can name: its industry is booming: Biotechnology revenue growth 40% y/y with 100% of 
## v1.2.0 lanes

- `15:57:12`    learned prior on picks: 239 / 239; history: In this regime (SPY>200d) since 2021, names under their 200-day averaged -4.5% vs SPY over the next 6 months (hit 36%, n=11997) against -0.9% for names above it; the top decile of past bottoms did +29.7% -- the edge is in the right tail, which is why the desk ranks by evidence rather than buying every dip.
- `15:57:12`    RNA    KATLIN_PRIME learned   29.5% (n_feat 15) top-lever [('d200', '<-50%', 14.37), ('vol', '>70%', 10.09), ('dd52', '<-65%', 9.75)]
- `15:57:12`    ADMA   READY        learned   4.59% (n_feat 15) top-lever [('dd52', '-65..-45%', 5.99), ('struct', 'CONFIRMED', 2.74), ('vol', '45-70%', 2.14)]
- `15:57:12`    TLRY   READY        learned  19.22% (n_feat 15) top-lever [('vol', '>70%', 10.09), ('dd52', '<-65%', 9.75), ('d200', '-50..-30%', 6.25)]
- `15:57:12`    HCKT   READY        learned   7.87% (n_feat 15) top-lever [('dd52', '-65..-45%', 5.99), ('vol', '45-70%', 2.14), ('dbs', '>250', 1.71)]
- `15:57:12`    TIGR   READY        learned   6.08% (n_feat 15) top-lever [('dd52', '-65..-45%', 5.99), ('vol', '45-70%', 2.14), ('mom', '>60', 1.38)]
- `15:57:12`    CWH    READY        learned  15.34% (n_feat 15) top-lever [('vol', '>70%', 10.09), ('dd52', '-65..-45%', 5.99), ('dbs', '>250', 1.71)]
- `15:57:12`    DXC    READY        learned  -0.62% (n_feat 15) top-lever [('struct', 'CONFIRMED', 2.74), ('d200', '-6..0%', -2.36), ('vol', '45-70%', 2.14)]
- `15:57:12`    LEU    READY        learned   8.98% (n_feat 15) top-lever [('vol', '>70%', 10.09), ('dd52', '-65..-45%', 5.99), ('rsi_div', 'yes', -4.28)]
- `15:57:12`    CRASH_BARBELL: 34 names; base rate {'63s': {'n': 451, 'mean_excess_pct': 4.79, 'median_excess_pct': -1.56, 'hit_rate_pct': 48.0, 'p90_excess_pct': 53.79, 'median_max_adverse_pct': -15.13, 'payoff': 1.48}, '126s': {'n': 412, 'mean_excess_pct': 8.0, 'median_excess_pct': -6.28, 'hit_rate_pct': 45.0, 'p90_excess_pct': 79.83, 'median_max_adverse_pct': -24.39, 'payoff': 1.72}, '252s': {'n': 345, 'mean_excess_pct': 22.48, 'median_excess_pct': -14.8, 'hit_rate_pct': 41.0, 'p90_excess_pct': 143.98, 'median_max_adverse_pct': -34.03, 'payoff': 2.62}}
- `15:57:12`       EOSE   dd52 -79.8 vol 119.0 learned 26.87 3m -52.0 | fell 52% in 3 months with no higher low yet
- `15:57:12`       LUNR   dd52 -67.6 vol 111.5 learned 17.08 3m -56.0 | fell 56% in 3 months with no higher low yet
- `15:57:12`       ADTN   dd52 -63.4 vol 67.6 learned 10.95 3m -58.9 | fell 59% in 3 months with no higher low yet
- `15:57:12`       LAC    dd52 -70.1 vol 131.3 learned 18.08 3m -41.2 | fell 41% in 3 months with no higher low yet
- `15:57:12`       SIDU   dd52 -66.6 vol 192.0 learned 13.33 3m -56.0 | fell 56% in 3 months with no higher low yet
- `15:57:12`       RDW    dd52 -59.3 vol 115.8 learned 11.57 3m -50.9 | fell 51% in 3 months with no higher low yet
- `15:57:12`    structure states across published rows: {'CONFIRMED': 62, 'FORMING': 98, 'NONE': 479}
- `15:57:12`    washout gate passes: 2462 of 5761 scored
- `15:57:12`    ports catalysts on picks: 17; T1 labels: ['100-day average', '200-day average', '50-day average', '52-week high', 'neckline']
- `15:57:12`    [katlin] feeds in 3.5s: finviz=11606 census=492 boom=129 rotation=40 flows=300/128 f13=7526 dark=936 insider=24 congress=32 options=58 blocks=12 catalyst=201 calendar=91 contracts=79 backlog=121 floor=168 ports=16 fleet_accum=814 warroom=bond_warroom,auction,risk_gate,blackswan,crisis,tail,regime,vo
- `15:57:12`    [katlin] war room: FULL_RISK (therm 34.5, 16 legs, vetoes [], missing [])
- `15:57:12`    [katlin] stocks scored: 3099 (thin 384, hygiene 355) in 40s
- `15:57:12`    [katlin] crypto lane: 93 symbols banked, 89 with >=200 days, 0 errors (BTC=ok:+0, ETH=ok:+0, SOL=ok:+0, XRP=ok:+0, BNB=ok:+0)
- `15:57:12`    [katlin] dilution lane: 179 names, {'banked': 179}, 1s
- `15:57:12`    [katlin] sniper: 70/70 shortlist names got 4h bars (0 errors)
- `15:57:12`    picks with a NAMED catalyst: 94 / 239; catalyst gate passes: 359
- `15:57:12`    catalyst kinds across picks: [('industry_boom', 93), ('squeeze', 46), ('ports', 17), ('scheduled', 9), ('backlog', 5), ('cycle', 4), ('contracts', 4), ('earnings', 2)]
- `15:57:12`    dilution coverage on stock picks: 161 / 196 (fmp-sourced 139)
- `15:57:12`    RNA catalysts: ['its industry is booming: Biotechnology revenue growth 40% y/y with 100', '20% of the float is short with 19.2 days to cover -- fuel for a violen']
- `15:57:12`    RNA plan: {'entry': 14.19, 'stop': 12.71, 'target_1': 33.18, 'target_1_label': '200-day average', 'target_2': 72.93, 'target_2_label': '52-week high', 'upside_1_pct': 133.8, 'upside_2_pct': 414.0, 'downside_pct': 10.5, 'rr_1': 10.0, 'rr_2': 10.0, 'asymmetry': 19.1, 'confirmation_trigger': None, 'rr_best': 10.0} | 3m 15.4 | days<200 132 | knife False
- `15:57:12`    ADMA catalysts: ['its industry is booming: Biotechnology revenue growth 40% y/y with 100']
- `15:57:12`    ADMA plan: {'entry': 9.62, 'stop': 8.94, 'target_1': 12.64, 'target_1_label': '200-day average', 'target_2': 20.38, 'target_2_label': '52-week high', 'upside_1_pct': 31.4, 'upside_2_pct': 111.9, 'downside_pct': 7.0, 'rr_1': 4.5, 'rr_2': 10.0, 'asymmetry': 9.2, 'confirmation_trigger': 14.84, 'rr_best': 10.0} | 3m 20.6 | days<200 161 | knife False
- `15:57:12`    TLRY catalysts: ['port traffic tied to Drug Manufacturers - Specialty & Generic is up 10', '14% of the float is short with 4.5 days to cover -- fuel for a violent']
- `15:57:12`    TLRY plan: {'entry': 4.5, 'stop': 4.25, 'target_1': 5.05, 'target_1_label': '100-day average', 'target_2': 23.2, 'target_2_label': 'neckline', 'upside_1_pct': 12.2, 'upside_2_pct': 415.6, 'downside_pct': 5.6, 'rr_1': 2.2, 'rr_2': 10.0, 'asymmetry': 13.8, 'confirmation_trigger': 23.2, 'rr_best': 10.0} | 3m -13.3 | days<200 155 | knife False
- `15:57:12`    HCKT catalysts: ['its industry is booming: Information Technology Services revenue growt']
- `15:57:12`    HCKT plan: {'entry': 11.21, 'stop': 10.0, 'target_1': 12.2, 'target_1_label': 'neckline', 'target_2': 21.27, 'target_2_label': '52-week high', 'upside_1_pct': 8.8, 'upside_2_pct': 89.7, 'downside_pct': 10.8, 'rr_1': 0.8, 'rr_2': 8.3, 'asymmetry': 4.6, 'confirmation_trigger': 12.2, 'rr_best': 8.3} | 3m 1.3 | days<200 357 | knife False
- `15:57:12`    TIGR catalysts: []
- `15:57:12`    TIGR plan: {'entry': 5.08, 'stop': 4.35, 'target_1': 5.29, 'target_1_label': '100-day average', 'target_2': 12.29, 'target_2_label': '52-week high', 'upside_1_pct': 4.1, 'upside_2_pct': 141.9, 'downside_pct': 14.5, 'rr_1': 0.3, 'rr_2': 9.8, 'asymmetry': 5.1, 'confirmation_trigger': 5.09, 'rr_best': 9.8} | 3m 6.7 | days<200 163 | knife False
- `15:57:12`    CWH catalysts: ['18% of the float is short with 5.1 days to cover -- fuel for a violent']
- `15:57:12`    CWH plan: {'entry': 6.96, 'stop': 5.9, 'target_1': 8.46, 'target_1_label': '200-day average', 'target_2': 17.91, 'target_2_label': '52-week high', 'upside_1_pct': 21.6, 'upside_2_pct': 157.3, 'downside_pct': 15.3, 'rr_1': 1.4, 'rr_2': 10.0, 'asymmetry': 5.9, 'confirmation_trigger': 8.63, 'rr_best': 10.0} | 3m -0.7 | days<200 388 | knife False
## field coverage (artifact keys)

- `15:57:12`    top-level: ['as_of', 'barbell_base_rate', 'base_rates', 'changes', 'definitions', 'degraded', 'elapsed_s', 'engine', 'feeds_asof', 'gates', 'generated_at', 'history', 'log', 'market', 'panels', 'params', 'picks', 'schema', 'session', 'tiers', 'top_picks', 'universe', 'validation', 'version', 'war_room', 'watch', 'weights']
- `15:57:12`    panels: {'war_room': 16, 'prime': 1, 'ready': 18, 'basing': 60, 'barbell': 30, 'etfs': 40, 'crypto': 36}
- `15:57:12`    pick row keys (114): ['above_ema10_w', 'absorption_clv', 'accum_evidence', 'accum_legs', 'ad_slope_40', 'adv_usd', 'alpha_prior', 'asset_class', 'asymmetry', 'atr_pctile', 'base_weeks', 'bbw_pctile', 'below_sma200', 'below_sma250', 'beta_1y', 'catalysts', 'composite', 'conviction', 'country', 'cvar5_pct', 'days_below_sma200', 'dd_52w_pct', 'dist_ema200_pct', 'dist_ema250_pct', 'dist_sma200_pct', 'dist_sma250_pct', 'double_bottom_d', 'double_bottom_w', 'ema200', 'ema250', 'evidence_coverage_pct', 'fleet_accumulation', 'gap_risk_pct', 'gates', 'gates_passed', 'high_52w', 'higher_lows_w', 'industry', 'industry_etf', 'inflow_evidence', 'inflow_legs', 'knife', 'knife_why', 'last', 'learned_excess_126s_pct', 'location_legs', 'low_52w', 'lower_half_days_20', 'lower_highs_w', 'lower_lows_w', 'lt_downtrend', 'lt_trend_break', 'm_close_vs_sma12_pct', 'm_higher_low', 'm_lower_lows', 'm_ret_pct', 'macd_w_turn', 'max_dd_1y_pct', 'mcap', 'mom_evidence', 'mom_legs', 'n_months', 'n_named_catalysts', 'n_quarters', 'n_weeks', 'name', 'obv_slope_40', 'oversold_legs', 'pct_b', 'pillars', 'plan', 'pos_52w_pct', 'posture_note', 'q_break', 'q_lower_highs', 'q_ret_pct', 'quality', 'ret_12m_pct', 'ret_1m_pct', 'ret_3m_pct', 'ret_6m_pct', 'roc20_cross_days', 'rr', 'rs_63_pct', 'rs_slope_20', 'rsi_d', 'rsi_div_d', 'rsi_div_w', 'rsi_m', 'rsi_w', 'rsi_w_turning_up', 'sector', 'sessions', 'sma100', 'sma200', 'sma200_slope_20_pct', 'sma250', 'sma40w_falling', 'sma50', 'sniper', 'squeeze', 'squeeze_lean', 'structure_legs', 'structure_state', 'sub_class', 'ticker', 'tier', 'trendline_level', 'updown_vol_20', 'vol_ann_pct', 'vol_ratio_20_120', 'weeks_since_break', 'why', 'worst_day_1y_pct']
## schedules

- `15:57:13`    justhodl-katlin-daily cron(10 4 ? * TUE-SAT *) ENABLED
- `15:57:13`    justhodl-katlin-backtest-weekly cron(30 9 ? * SUN *) ENABLED
## page

- `15:57:13`    katlin.html carries marker KATLIN_DESK_V1 at the edge: True
- `15:57:36`    1440px: {"score": "35", "posture": "FULL RISK", "headline": "green light -- deploy into the best asymmetric setups", "legs": 16, "board": 1, "evid": 1630, "helps": 26, "defs": 18, "valextra": 69, "hist": true, "overflow": 0, "err": ""} errors=[]
- `15:57:48`     390px: {"score": "35", "posture": "FULL RISK", "headline": "green light -- deploy into the best asymmetric setups", "legs": 16, "board": 1, "evid": 1630, "helps": 26, "defs": 18, "valextra": 69, "hist": true, "overflow": 0, "err": ""} errors=[]
- `15:57:48` ✅    GREEN: KATLIN live -- engine, feed, schedules, page
