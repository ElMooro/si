# ops 5179 -- Treasury auction data probe

**Status:** success  
**Duration:** 6.4s  
**Finished:** 2026-09-03T23:59:25+00:00  

## Data

| n | newest | section |
|---|---|---|
| 10 | 2026-09-03 | B_auctioned |

## Log
## A. current feed data/auction-crisis.json

- `23:59:19`    keys=['schema_version', 'generated_at', 'elapsed_sec', 'elapsed_v2_sec', 'regime', 'composite_score', 'interpretation', 'n_recent_auctions_14d', 'issuance_anomaly', 'fed_funds_rate', 'freshness', 'recent_auctions', 'indicator_aggregate_14d', 'historical_reference', 'tenor_decomposition', 'forward_calendar', 'historical_analog', 'cross_signals', 'composite_history', 'tail_risk']
- `23:59:19`    generated_at=2026-09-03T19:50:40.642787+00:00
- `23:59:19`    records=10 newest={'auction_date': '2026-09-03', 'issue_date': '2026-09-08', 'security_type': 'Bill', 'security_term': '4-Week', 'cusip': '912797VK0', 'tenor_bucket': 'bills_lt_90d', 'high_rate': 3.7, 'low_rate': 3.59}
- `23:59:19`    newest auction dates in feed: ['2026-08-27', '2026-08-31', '2026-09-01', '2026-09-02', '2026-09-03']
## B. TreasuryDirect TA_WS

- `23:59:19`    securities/auctioned?format=json&days=7 -> 200 rows=10
- `23:59:19`       fields: ['cusip', 'issueDate', 'securityType', 'securityTerm', 'maturityDate', 'interestRate', 'refCpiOnIssueDate', 'refCpiOnDatedDate', 'announcementDate', 'auctionDate', 'auctionDateYear', 'datedDate', 'accruedInterestPer1000', 'accruedInterestPer100', 'adjustedAccruedInterestPer1000', 'adjustedPrice', 'allocationPercentage', 'allocationPercentageDecimals', 'announcedCusip', 'auctionFormat', 'averageMedianDiscountRate', 'averageMedianInvestmentRate', 'averageMedianPrice', 'averageMedianDiscountMargin', 'averageMedianYield', 'backDated', 'backDatedDate', 'bidToCoverRatio', 'callDate', 'callable', 'calledDate', 'cashManagementBillCMB', 'closingTimeCompetitive', 'closingTimeNoncompetitive', 'competitiveAccepted', 'competitiveBidDecimals', 'competitiveTendered', 'competitiveTendersAccepted', 'corpusCusip', 'cpiBaseReferencePeriod', 'currentlyOutstanding', 'directBidderAccepted', 'directBidderTendered', 'estimatedAmountOfPubliclyHeldMaturingSecuritiesByType', 'fimaIncluded', 'fimaNoncompetitiveAccepted', 'fimaNoncompetitiveTendered', 'firstInterestPeriod', 'firstInterestPaymentDate', 'floatingRate', 'frnIndexDeterminationDate', 'frnIndexDeterminationRate', 'highDiscountRate', 'highInvestmentRate', 'highPrice', 'highDiscountMargin', 'highYield', 'indexRatioOnIssueDate', 'indirectBidderAccepted', 'indirectBidderTendered']
- `23:59:19`       sample: {"cusip": "912797VK0", "securityType": "Bill", "securityTerm": "4-Week", "auctionDate": "2026-09-03T00:00:00", "issueDate": "2026-09-08T00:00:00", "maturityDate": "2026-10-06T00:00:00", "highYield": "", "highDiscountRate": "3.700000", "bidToCoverRatio": "2.970000", "primaryDealerAccepted": "23875680000", "directBidderAccepted": "2775320000", "indirectBidderAccepted": "55571291900", "totalAccepted": "95385335100", "totalTendered": "272835287900", "competitiveAccepted": "82222291900", "noncompetitiveAccepted": "5878560400", "allocationPercentage": "58.440000", "offeringAmount": "90000000000", "type": "Bill", "reopening": "Yes", "somaAccepted": "5384482800", "somaIncluded": "No", "somaHoldings"
- `23:59:19`       newest auction dates: ['2026-08-27', '2026-08-31', '2026-09-01', '2026-09-02', '2026-09-03']
- `23:59:19`    securities/announced?format=json&days=10 -> 200 rows=16
- `23:59:19`       fields: ['cusip', 'issueDate', 'securityType', 'securityTerm', 'maturityDate', 'interestRate', 'refCpiOnIssueDate', 'refCpiOnDatedDate', 'announcementDate', 'auctionDate', 'auctionDateYear', 'datedDate', 'accruedInterestPer1000', 'accruedInterestPer100', 'adjustedAccruedInterestPer1000', 'adjustedPrice', 'allocationPercentage', 'allocationPercentageDecimals', 'announcedCusip', 'auctionFormat', 'averageMedianDiscountRate', 'averageMedianInvestmentRate', 'averageMedianPrice', 'averageMedianDiscountMargin', 'averageMedianYield', 'backDated', 'backDatedDate', 'bidToCoverRatio', 'callDate', 'callable', 'calledDate', 'cashManagementBillCMB', 'closingTimeCompetitive', 'closingTimeNoncompetitive', 'competitiveAccepted', 'competitiveBidDecimals', 'competitiveTendered', 'competitiveTendersAccepted', 'corpusCusip', 'cpiBaseReferencePeriod', 'currentlyOutstanding', 'directBidderAccepted', 'directBidderTendered', 'estimatedAmountOfPubliclyHeldMaturingSecuritiesByType', 'fimaIncluded', 'fimaNoncompetitiveAccepted', 'fimaNoncompetitiveTendered', 'firstInterestPeriod', 'firstInterestPaymentDate', 'floatingRate', 'frnIndexDeterminationDate', 'frnIndexDeterminationRate', 'highDiscountRate', 'highInvestmentRate', 'highPrice', 'highDiscountMargin', 'highYield', 'indexRatioOnIssueDate', 'indirectBidderAccepted', 'indirectBidderTendered']
- `23:59:19`       sample: {"cusip": "912810UW6", "securityType": "Bond", "securityTerm": "29-Year 11-Month", "auctionDate": "2026-09-10T00:00:00", "issueDate": "2026-09-15T00:00:00", "maturityDate": "2056-08-15T00:00:00", "highYield": "", "highDiscountRate": "", "bidToCoverRatio": "", "primaryDealerAccepted": "", "directBidderAccepted": "", "indirectBidderAccepted": "", "totalAccepted": "", "totalTendered": "", "competitiveAccepted": "", "noncompetitiveAccepted": "", "allocationPercentage": "", "offeringAmount": "22000000000", "type": "Bond", "reopening": "Yes", "somaAccepted": "", "somaIncluded": "No", "somaHoldings": "0", "somaTendered": ""}
- `23:59:20`    securities/upcoming?format=json -> 200 rows=6
- `23:59:20`       fields: ['cusip', 'issueDate', 'securityType', 'securityTerm', 'maturityDate', 'interestRate', 'refCpiOnIssueDate', 'refCpiOnDatedDate', 'announcementDate', 'auctionDate', 'auctionDateYear', 'datedDate', 'accruedInterestPer1000', 'accruedInterestPer100', 'adjustedAccruedInterestPer1000', 'adjustedPrice', 'allocationPercentage', 'allocationPercentageDecimals', 'announcedCusip', 'auctionFormat', 'averageMedianDiscountRate', 'averageMedianInvestmentRate', 'averageMedianPrice', 'averageMedianDiscountMargin', 'averageMedianYield', 'backDated', 'backDatedDate', 'bidToCoverRatio', 'callDate', 'callable', 'calledDate', 'cashManagementBillCMB', 'closingTimeCompetitive', 'closingTimeNoncompetitive', 'competitiveAccepted', 'competitiveBidDecimals', 'competitiveTendered', 'competitiveTendersAccepted', 'corpusCusip', 'cpiBaseReferencePeriod', 'currentlyOutstanding', 'directBidderAccepted', 'directBidderTendered', 'estimatedAmountOfPubliclyHeldMaturingSecuritiesByType', 'fimaIncluded', 'fimaNoncompetitiveAccepted', 'fimaNoncompetitiveTendered', 'firstInterestPeriod', 'firstInterestPaymentDate', 'floatingRate', 'frnIndexDeterminationDate', 'frnIndexDeterminationRate', 'highDiscountRate', 'highInvestmentRate', 'highPrice', 'highDiscountMargin', 'highYield', 'indexRatioOnIssueDate', 'indirectBidderAccepted', 'indirectBidderTendered']
- `23:59:20`       sample: {"cusip": "912797VG9", "securityType": "Bill", "securityTerm": "13-Week", "auctionDate": "2026-09-08T00:00:00", "issueDate": "2026-09-10T00:00:00", "maturityDate": "2026-12-10T00:00:00", "highYield": "", "highDiscountRate": "", "bidToCoverRatio": "", "primaryDealerAccepted": "", "directBidderAccepted": "", "indirectBidderAccepted": "", "totalAccepted": "", "totalTendered": "", "competitiveAccepted": "", "noncompetitiveAccepted": "", "allocationPercentage": "", "offeringAmount": "92000000000", "type": "Bill", "reopening": "Yes", "somaAccepted": "", "somaIncluded": "No", "somaHoldings": "18898000000", "somaTendered": ""}
## C. buyback sources

- `23:59:20`    www.treasurydirect.gov/TA_WS/securities/buybacks?format=json -> 404 
- `23:59:20`    www.treasurydirect.gov/TA_WS/buybacks?format=json -> 404 
- `23:59:20`    www.treasurydirect.gov/TA_WS/buybacks/results?format=json -> 404 
- `23:59:21`    www.treasurydirect.gov/TA_WS/buybacks/operations?format=json -> 404 
- `23:59:21`    www.treasurydirect.gov/auctions/buybacks/ -> 404 
- `23:59:21`    www.treasurydirect.gov/auctions/buybacks/results/ -> 404 
- `23:59:21`    www.treasurydirect.gov/auctions/buybacks/operations/ -> 404 
- `23:59:22`    api.fiscaldata.treasury.gov/services/api/fiscal_service/v1/accounting/od/buybacks_operations?fo -> 200 JSON data rows=5 fields=['operation_date', 'operation_start_time_est', 'operation_close_time_est', 'settlement_date', 'preliminary_ann_pdf', 'preliminary_ann_xml', 'final_ann_pdf', 'final_ann_xml', 'results_pdf', 'results_xml', 'special_ann_pdf', 'operation_type', 'security_type', 'maturity_bucket', 'nbr_issues_accepted', 'total_par_amt_offered', 'par_amt_per_offer', 'max_par_amt_redeemed', 'max_n
- `23:59:22`    api.fiscaldata.treasury.gov/services/api/fiscal_service/v1/accounting/od/buyback_operations?for -> 404 
- `23:59:23`    api.fiscaldata.treasury.gov/services/api/fiscal_service/v1/accounting/od/buybacks?format=json&p -> 404 
- `23:59:23`    api.fiscaldata.treasury.gov/services/api/fiscal_service/v1/accounting/od/buybacks_security_deta -> 200 JSON data rows=5 fields=['operation_date', 'operation_start_time_est', 'cusip_nbr', 'coupon_rate_pct', 'maturity_date', 'par_amt_accepted', 'weighted_avg_accepted_price']
- `23:59:24`    api.fiscaldata.treasury.gov/services/api/fiscal_service/v2/accounting/od/buybacks?format=json&p -> 404 
- `23:59:24`    www.treasurydirect.gov/TA_WS/securities/search?format=json&type=Buyback&days=60 -> 400 
- `23:59:24`    www.treasurydirect.gov/TA_WS/securities/auctioned?format=json&type=Buyback&days=60 -> 400 
- `23:59:25`    fiscaldata dataset search -> 404 
- `23:59:25` ✅ probe complete
