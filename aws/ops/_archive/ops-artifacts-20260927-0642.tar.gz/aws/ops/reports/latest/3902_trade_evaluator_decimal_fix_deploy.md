# ops 3902 — deploy the Decimal fix, hard-gate on updated > 0 (was structurally 0 every run)

**Status:** failure  
**Duration:** 180.0s  
**Finished:** 2026-07-26T03:33:50+00:00  

## Error

```
SystemExit: 1
```

## Data

| after_n_open | after_s3 | after_total_evaluated_30d | before_n_open | before_s3 | before_total_evaluated_30d | n_updated_this_invoke |
|---|---|---|---|---|---|---|
|  |  |  | 1973 | 2026-07-25T23:03:30+00:00 | 0 |  |
| 1984 | 2026-07-26T03:33:51+00:00 | 1557 |  |  |  | None |

## Log
## 1. BEFORE

## 2. ZIP-SETTLE BY MARKER

- `03:30:52` ✅   new artifact live on attempt 1 (89,778 zip bytes)
- `03:30:52` ✅   State=Active LastUpdateStatus=Successful
## 3. invoke (may run close to the full 600s timeout — real Polygon calls per checkpoint)

- `03:33:50`   invoke response: {"statusCode": 200, "body": "{\"success\": true, \"version\": \"1.0.0\", \"n_calls_scanned\": 1984, \"n_updated\": 1946, \"n_strategies_tracked\": 5, \"overall_win_rate_30d_pct\": 53.2, \"overall_avg_return_30d_pct\": 1.05, \"elapsed_seconds\": 177.52}"}
## 4. THE REAL GATE — did updated actually move off the structural 0

- `03:33:50` ✅   journal artifact was rewritten this invoke
- `03:33:50` ✗   n_updated this invoke is a real positive number (was structurally 0 every prior run)
- `03:33:50` ✅   total_evaluated_30d increased from before
## 5. spot-check a real evaluated call, if any exist now

- `03:33:50`   {"strategy": "DEBATE_BUY", "total_calls_90d": 7, "evaluated_30d": 6, "win_rate_30d_pct": 33.3, "avg_return_30d_pct": 9.47, "evaluated_90d": 0, "win_rate_90d_pct": null, "avg_return_90d_pct": null}
- `03:33:50`   {"strategy": "REGIME_PICK", "total_calls_90d": 454, "evaluated_30d": 260, "win_rate_30d_pct": 61.9, "avg_return_30d_pct": 2.83, "evaluated_90d": 0, "win_rate_90d_pct": null, "avg_return_90d_pct": null}
- `03:33:50`   {"strategy": "OPTIONS_TIER_A", "total_calls_90d": 1468, "evaluated_30d": 1262, "win_rate_30d_pct": 52.1, "avg_return_30d_pct": 0.78, "evaluated_90d": 0, "win_rate_90d_pct": null, "avg_return_90d_pct": null}
- `03:33:50`   {"strategy": "TIER_A_ALPHA", "total_calls_90d": 45, "evaluated_30d": 29, "win_rate_30d_pct": 24.1, "avg_return_30d_pct": -5.11, "evaluated_90d": 0, "win_rate_90d_pct": null, "avg_return_90d_pct": null}
- `03:33:50` ✗ FAILED 1: ['n_updated this invoke is a real positive number (was structurally 0 every prior run)']
