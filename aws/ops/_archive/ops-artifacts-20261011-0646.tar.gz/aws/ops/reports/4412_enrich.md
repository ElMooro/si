# ops 4412 — crisis + plumbing enrichment — PASS — crisis +32, plumbing +25 series, four-canary live
## crisis-plumbing
{
 "feed": "data/crisis-plumbing.json",
 "deployed": true,
 "invoke": {
  "code": 200,
  "fn_err": null
 },
 "n_series": 32,
 "categories": [
  "bank",
  "credit",
  "derived",
  "dollar",
  "real",
  "stress"
 ],
 "spot": {
  "BAMLH0A0HYM2": {
   "value": 2.85,
   "z": -0.15
  },
  "BAMLH0A3HYC": {
   "value": 10.34,
   "z": 2.8
  },
  "STLFSI4": {
   "value": -0.8263,
   "z": -1.0
  },
  "ICSA": {
   "value": 197000.0,
   "z": -2.1
  },
  "DRTSCILM": {
   "value": 0.0,
   "z": -0.3
  }
 },
 "derived": {
  "hy_ig_spread": {
   "label": "HY \u2212 IG spread",
   "unit": "pp",
   "value": 2.06,
   "note": "credit-quality dispersion"
  },
  "ccc_bb_spread": {
   "label": "CCC \u2212 BB spread",
   "unit": "pp",
   "value": 8.61,
   "note": "internal-credit dispersion tell"
  }
 }
}
## plumbing-aggregator
{
 "feed": "data/plumbing-stress.json",
 "deployed": true,
 "invoke": {
  "code": 200,
  "fn_err": null
 },
 "n_series": 25,
 "categories": [
  "canary",
  "l1_funding",
  "l2_bank",
  "l3_real",
  "l4_cross"
 ],
 "four_canary": {
  "verdict": "CALM",
  "n_firing": 0,
  "sofr_iorb": {
   "label": "SOFR \u2212 IORB",
   "value_bp": 0.0,
   "state": "CALM",
   "thresholds": {
    "amber": 5,
    "red": 10,
    "note": "brain: >+5bp amber, >+10bp red"
   }
  }
 },
 "spot": {
  "BAMLH0A0HYM2": {
   "value": 2.85,
   "z": -0.15
  },
  "ICSA": {
   "value": 197000.0,
   "z": -2.1
  },
  "SOFR": {
   "value": 3.65,
   "z": 0.49
  },
  "DRTSCILM": {
   "value": 0.0,
   "z": -0.3
  }
 }
}
