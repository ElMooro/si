# ops 4629 — fleet-join close: nested columnar + structural ceiling resolution

**Status:** success  
**Duration:** 20.1s  
**Finished:** 2026-08-12T02:27:13+00:00  

## Data

| alarm | amber | extremes | red | resolved | with_history |
|---|---|---|---|---|---|
| AMBER | 2 | 43 | 0 | 361 | 217 |

## Log
## pre-dump store shapes

- `02:26:54` data/_ma200/closes.json: {"dates": ["len=235", "2025-09-03"], "series": {"IBKR": ["len=235", "float"], "ELF": ["len=235", "float"], "DIA": ["len=235", "float"], "XLB": ["len=235", "float"], "DOW": ["len=235", "float"]}}
- `02:26:54` data/vix-curve-history.json: {"generated_at": "2026-08-12T02:14:36.765267+00:00", "n_days": 1764, "first_date": "2019-08-05", "last_date": "2026-08-11", "dates": ["len=1764", "2019-08-05"]}
- `02:26:54` data/dollar-radar-history.json: {"rows": ["len=37", {"date": "str", "ts": "str", "dollar_pressure": "int", "regime": "str", "risk_score": "int"}], "updated": "2026-08-12T01:15:31.982569+00:00"}
## deploy-settle

- `02:26:55` ✅   [deploy] v1.3.2 live
## run + fleet-join truth

- `02:27:07` TVC:MOVE         CALM      z=0.6   n=260  +3.96% (chg)
- `02:27:07` CBOE:VIX3M       CALM      z=0.04  n=400  -0.37% (DoD)
- `02:27:07` CBOE:VXN         CALM      z=0.46  n=400  -2.86% (DoD)
- `02:27:07` TVC:DXY          CALM      z=None  n=2    
- `02:27:07` NASDAQ:TLT       CALM      z=1.4   n=235  -0.85% (DoD)
- `02:27:07` AMEX:HYG         CALM      z=0.65  n=235  -0.16% (DoD)
- `02:27:07` NASDAQ:SMH       CALM      z=0.88  n=235  -2.28% (DoD)
- `02:27:07` ECONOMICS:USWEI  CALM      z=0.6   n=300  +10.74% (WoW)
- `02:27:07` ✅   [fleet-z] z-basis via fleet joins: ['TVC:MOVE', 'CBOE:VIX3M', 'NASDAQ:TLT', 'AMEX:HYG']
- `02:27:07` ✅   [wei] ECONOMICS:USWEI via FRED alias
- `02:27:07` ✅   [resolution] 361/500 resolved — remainder is TV-native (EUREX/ICE futures, NQ indexes, FX_IDC, MULTPL) awaiting extension vault sync
- `02:27:07` ✅   [history-depth] 217 rows on statistical basis
- `02:27:07` ✅   [alarm-valid] alarm AMBER
## canary + edge

- `02:27:12` ✅   [canary] board parity: {"state": "AMBER", "n_red": 0, "n_amber": 2, "n_range_extreme": 43, "list": "Black Swan Event", "doctrine": "K
- `02:27:13` ✅   [edge] edge serves fleet-joined TLT z-basis
## verdict

- `02:27:13` ✅ FLEET-JOINED — 361/500 resolved, 217 on statistical basis, alarm AMBER; MOVE/VIX-curve/DXY/ETF histories now sourced from the fleet's own engines
