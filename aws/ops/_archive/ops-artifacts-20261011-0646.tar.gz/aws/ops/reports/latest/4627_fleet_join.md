# ops 4627 — blackswan fleet-join resolution

**Status:** failure  
**Duration:** 184.9s  
**Finished:** 2026-08-12T02:21:24+00:00  

## Error

```
SystemExit: 1
```

## Data

| alarm | amber | extremes | red | resolved | with_history |
|---|---|---|---|---|---|
| AMBER | 2 | 35 | 0 | 361 | 207 |

## Log
## pre-dump store shapes

- `02:18:20` data/_ma200/closes.json: {"dates": ["len=235", "2025-09-03"], "series": {"IBKR": ["len=235", "float"], "ELF": ["len=235", "float"], "DIA": ["len=235", "float"], "XLB": ["len=235", "float"], "DOW": ["len=235", "float"]}}
- `02:18:20` data/vix-curve-history.json: {"generated_at": "2026-08-12T02:14:36.765267+00:00", "n_days": 1764, "first_date": "2019-08-05", "last_date": "2026-08-11", "dates": ["len=1764", "2019-08-05"]}
- `02:18:20` data/dollar-radar-history.json: {"rows": ["len=37", {"date": "str", "ts": "str", "dollar_pressure": "int", "regime": "str", "risk_score": "int"}], "updated": "2026-08-12T01:15:31.982569+00:00"}
## deploy-settle

- `02:18:21` ✅   [deploy] v1.3.0 live
## run + fleet-join truth

- `02:18:34` TVC:MOVE         CALM      z=0.6   n=260  +3.96% (chg)
- `02:18:34` CBOE:VIX3M       NO_HISTORY z=None  n=1    
- `02:18:34` CBOE:VXN         AMBER     z=None  n=2    
- `02:18:34` TVC:DXY          CALM      z=None  n=2    
- `02:18:34` NASDAQ:TLT       CALM      z=None  n=2    
- `02:18:34` AMEX:HYG         CALM      z=None  n=2    
- `02:18:34` NASDAQ:SMH       CALM      z=None  n=2    
- `02:18:34` ECONOMICS:USWEI  CALM      z=0.6   n=300  +10.74% (WoW)
- `02:18:34` ✗   [fleet-z] CONTRACT MISS — z-basis via fleet joins: ['TVC:MOVE']
- `02:18:34` ✅   [wei] ECONOMICS:USWEI via FRED alias
- `02:18:34` ✗   [resolution] CONTRACT MISS — 361/500 resolved
- `02:18:34` ✗   [history-depth] CONTRACT MISS — 207 rows on statistical basis
- `02:18:34` ✅   [alarm-valid] alarm AMBER
## canary + edge

- `02:18:40` ✅   [canary] board parity: {"state": "AMBER", "n_red": 0, "n_amber": 2, "n_range_extreme": 35, "list": "Black Swan Event", "doctrine": "K
- `02:21:24` ✗   [edge] CONTRACT MISS — edge serves fleet-joined TLT z-basis
## verdict

- `02:21:24` ✗ fleet-join: 4 red (shapes above are the repair evidence)
