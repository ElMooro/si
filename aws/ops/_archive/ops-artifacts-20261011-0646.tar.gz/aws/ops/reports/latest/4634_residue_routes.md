# ops 4630 — barometer + TE join

**Status:** failure  
**Duration:** 68.8s  
**Finished:** 2026-08-12T03:35:33+00:00  

## Error

```
SystemExit: 1
```

## Data

| barometer | by_prefix | extreme | label | n_unresolved | resolved | shock | stretched | top_extremes |
|---|---|---|---|---|---|---|---|---|
| 14.4 |  | 28.6 | QUIET |  | 394 | 1.4 | 15.7 | [{"symbol": "FRED:PCOPPUSDM", "range_pos_pct": 100.0}, {"symbol": "NASDAQ:TLT", "range_pos_pct": 0.0}, {"symbol": "FRED:HOANBS", "range_pos_pct": 100.0}, {"symbol": "FRED:RRSFS", "range_pos_pct": 100. |
|  | [["NASDAQ", 29], ["ECONOMICS", 27], ["ICEEUR", 8], ["FTSE", 7], ["EUREX", 6], ["TVC", 4], ["ICEUS", 3], ["AMEX", 3], ["NYSE", 2], ["NYMEX", 1], ["SGX", 1], ["NSE", 1]] |  |  | 106 |  |  |  |  |

## Log
## deploy-settle

- `03:34:25` ✅   [deploy] blackswan v1.7.0 + signal v2.1.3
## purge poisoned negative caches

- `03:34:25` purged 0 poisoned miss stubs
## run + barometer truth

- `03:35:26` ✅   [barometer] barometer 14.4 (QUIET)
- `03:35:26` TE-joined: ['ECONOMICS:CLGDPYY', 'ECONOMICS:CLUR', 'ECONOMICS:CHUR', 'ECONOMICS:HKUR', 'ECONOMICS:USRSYY', 'ECONOMICS:EURSYY', 'ECONOMICS:NLCU', 'ECONOMICS:USBCOI', 'ECONOMICS:FIGDPYY', 'ECONOMICS:CHBCOI', 'ECONOMICS:FIBCOI', 'ECONOMICS:KYGDPYY']
- `03:35:26` ✅   [te-join] 42 ECONOMICS rows via Trading Economics
## UNRESOLVED CENSUS (the 125, named)

- `03:35:26` NYMEX:CL1!-BLACKBULL:WTI · EUREX:FMOG1! · ECONOMICS:WWOPI · ECONOMICS:WWMPMI · NYSE:C+NYSE:BAC+NYSE:WFC+NYSE:JPM · ECONOMICS:DEIFOCC
- `03:35:26` ECONOMICS:USGDPMAN · ECONOMICS:USFYGDPG · ECONOMICS:USGDPT · SGX:SGP2! · ECONOMICS:EUIS · FTSE:SS03
- `03:35:26` TVC:TRJEFFCRB · EUREX:FMAA1! · ICEEUR:ME32! · FTSE:4GL1 · FTSE:4EU5 · ICEEUR:MPE2!
- `03:35:26` NSE:CNXSMALLCAP · ECONOMICS:WWCOMPPMI · ECONOMICS:DENO · ECONOMICS:USDFSRI · FTSE:AWHDY01.TR · ECONOMICS:EUEMC
- `03:35:26` ICEEUR:USW1! · ECONOMICS:USCPMI · ICEUS:AWN1! · ECONOMICS:USBOI · ECONOMICS:FIMGDPYY · ECONOMICS:CNNO
- `03:35:26` TVC:DE10Y-TVC:IT10Y · ECONOMICS:JPMTO · ECONOMICS:EUMPMI · ECONOMICS:EUCOMPPMI · ECONOMICS:USKFCOMPI · ECONOMICS:JPCIND
- `03:35:26` ECONOMICS:USNMEMP · ECONOMICS:USNMBA · NASDAQ:NQUSS50206015N · NASDAQ:NQDXUSMLTCG · ECONOMICS:JPJAR · FTSE:SD10
- `03:35:26` NASDAQ:NQG50 · NASDAQ:B3010PI · NASDAQ:NQEMASIA3010T · NASDAQ:NQEM3010 · NASDAQ:NQHKBANK · NASDAQ:NQASPA35
- `03:35:26` NASDAQ:NQEMASIA35 · NASDAQ:NQEM35 · NASDAQ:NQEM30 · NASDAQ:NQEM5010 · NASDAQ:NQEM5020 · NASDAQ:NQEM50
- `03:35:26` AMEX:RXI/AMEX:KXI · USI:YRLO.US · ECONOMICS:JPSBSI · TSE:TPXLVG · NASDAQ:NQJP35T · NASDAQ:NQUSB50101010
- `03:35:26` NASDAQ:NQTW30 · EUREX:FMMG1! · ICEEUR:MWG2! · NYSE:ADR · 1-TVC:IN03Y · TVC:CN01Y
- `03:35:26` MULTPL:SHILLER_PE_RATIO_MONTH · ICEUS:MWL1! · EUREX:FMEA2! · AMEX:XLP/AMEX:XLY · OANDA:SG30SGD · NASDAQ:NQUSB302010N
- `03:35:26` EUREX:FMXU2! · AMEX:AGG/AMEX:HYG · NASDAQ:TLT/AMEX:SPY · HOSE:VNINDEX · TVC:VN03Y · ICEUS:DX1!-TVC:DXY
- `03:35:26` CBOE:VIX1Y · ICEEUR:US31!-TVC:US30Y · NASDAQ:NQMAFIT · ICEEUR:I2! · FX:SONIA3M · ICEEUR:SA32!
- `03:35:26` TMX:CRA2! · ICEEUR:EON2! · NASDAQ:NQASIAN · NASDAQ:NQBRICT · NASDAQ:NOMXNIN · NASDAQ:NQGRMIT
- `03:35:26` NASDAQ:NQRSKEM · LUXSE:LU0310511422 · SWB:JSGW · FTSE:FEMCRF · CSEMA:MASID · ECONOMICS:USMCEC
- `03:35:26` ECONOMICS:DEZCC · NASDAQ:NQCN55T · NASDAQ:B55PI · NASDAQ:NQEMEA4050T · FTSE:JAPAN.TR · NASDAQ:NQHKBANKN
- `03:35:26` CBOT:UB2! · EUREX:FVS2! · ASX24:AP1! · ECONOMICS:USRCR
- `03:35:26` ✗   [census-shrunk] CONTRACT MISS — 106 unresolved (113->target <=105; ~85+ fetch-slots/hour keep compounding)
- `03:35:26` ICEUS:DX1!-TVC:DXY                     UNRESOLVED z=None  n=-    
- `03:35:26` CBOE:VIX1Y                             UNRESOLVED z=None  n=-    
- `03:35:26` NSE:CNXSMALLCAP                        UNRESOLVED z=None  n=-    
- `03:35:26` ECONOMICS:USINBR-TVC:US03MY            CALM      z=0.78  n=300  
- `03:35:26` TVC:US10Y-MULTPL:SP500_EARNINGS_MONTH  CALM      z=1.54  n=291  
- `03:35:26` TVC:DXY                                CALM      z=0.16  n=253  
- `03:35:26` ✗   [residue-routes] CONTRACT MISS — 2/5 new residue routes z-based
- `03:35:26` KRX:KOSPI200       CALM      z=1.05  n=227  
- `03:35:26` INDEX:FTSEMIB      CALM      z=0.11  n=253  
- `03:35:26` EURONEXT:N100      CALM      z=0.09  n=256  
- `03:35:26` CBOT:ZB2!          CALM      z=0.5   n=252  
- `03:35:26` CME:SR32!          NO_HISTORY z=None  n=1    
- `03:35:26` FX_IDC:INRUSD      CALM      z=0.0   n=260  
- `03:35:26` FX_IDC:MXNJPY      CALM      z=0.53  n=260  
- `03:35:26` ECONOMICS:USJO     CALM      z=0.43  n=300  
- `03:35:26` ✅   [class-routes] 6/7 per-class spot-checks z-based
- `03:35:26` CBOT:ZB1!        CALM      z=0.5   n=252  
- `03:35:26` FX_IDC:KRWUSD    CALM      z=0.01  n=260  
- `03:35:26` ECONOMICS:CHUR   NO_HISTORY z=None  n=1    TE latest
- `03:35:26` NASDAQ:VXUS      CALM      z=0.46  n=235  
- `03:35:26` CBOE:VXEEM       CALM      z=0.69  n=400  
- `03:35:26` AMEX:VEA         CALM      z=0.52  n=235  
- `03:35:26` ✅   [alias-z] 4/5 alias spot-checks on z-basis
- `03:35:26` ✅   [history-depth] 306 rows on statistical basis (steady-state ~330 as the hourly cache compounds)
- `03:35:26` ✅   [ffill-composite] SOFR-FEDFUNDS z-based: z=0.42 +0.01 Δ (DoD)
- `03:35:26` ✅   [resolution] 394/500 — census-attacked; residue enumerated below
## board + edge

- `03:35:33` ✅   [canary-barometer] board carries barometer 14.4 (QUIET)
- `03:35:33` ✅   [edge] edge serves the barometer
## verdict

- `03:35:33` ✗ barometer: 2 red
