# ops 5582 — invoke unify engines (already deployed)

**Status:** success  
**Duration:** 20.7s  
**Finished:** 2026-09-17T19:59:58+00:00  

## Log
## Event (long)

- `19:59:38` ✅ justhodl-13f-positions Event status=202
- `19:59:38` ✅ justhodl-flow-lookthrough Event status=202
- `19:59:38` ✅ justhodl-earnings-tracker Event status=202
- `19:59:38` ✅ justhodl-financial-secretary Event status=202
## RequestResponse (short)

- `19:59:43` ✅ justhodl-estimate-revisions status=200 body={"statusCode": 200, "body": "{\"status\": \"LIVE\", \"n_tracked\": 414, \"n_fmp_enriched\": 263, \"n_with_history\": 414, \"n_up\": 18, \"n_down\": 26, \"n_strength_leaders\": 40, \"n_picks\": 15, \"elapsed_s\": 3.9}"}
- `19:59:44` ✅ justhodl-boom-radar status=200 body={"statusCode": 200, "body": "{\"dimensions_loaded\": {\"BEAT\": 10, \"ANALYST\": 57, \"ESTIMATE\": 74, \"FLOW\": 3136, \"SQUEEZE\": 8, \"BREAKOUT\": 3}, \"n_scanned\": 3163, \"n_2way\": 46, \"n_3way\": 2, \"n_4way_plus\": 0, \"n_picks\": 2,
- `19:59:50` ✅ justhodl-best-ideas status=200 body={"statusCode": 200, "body": "{\"ok\": true, \"n_total\": 183, \"titans\": 43, \"high\": 57}"}
- `19:59:55` ✅ justhodl-master-ranker status=200 body={"statusCode": 200, "body": "{\"ok\": true, \"n_tickers\": 25, \"n_macro\": 9, \"n_tier_3_plus\": 212, \"n_tier_5_plus\": 77, \"regime\": \"MUDDLE\", \"duration_s\": 4.57}"}
- `19:59:57` ✅ justhodl-massive-signals status=200 body={"statusCode": 200, "body": "{\"ok\": true, \"tickers\": 40, \"top_prepump\": 33, \"fut_ok\": false}"}
## S3 poll (13f-desk + by_ticker + boom 1.2)

- `19:59:58` poll 13f-desk.json=ok 13f-by-ticker.json=ok flow-lookthrough.json=ok estimate-revisions.json=ok boom-radar.json=ok
## Harvest shape (counts only)

- `19:59:58` ✅ data/13f-desk.json bytes=364881 lm=2026-09-17T19:08:09+00:00 by_fund_n=18 most_bought_n=25 accumulating_n=15
- `19:59:58` ✅ data/13f-by-ticker.json bytes=1648715 lm=2026-09-17T19:08:09+00:00 tickers_n=7138
- `19:59:58` ✅ data/flow-lookthrough.json bytes=270964 lm=2026-09-17T19:59:49+00:00 by_ticker_n=163 AAPL=yes
- `19:59:58` ✅ data/estimate-revisions.json bytes=226063 lm=2026-09-17T19:59:44+00:00 by_ticker_n=263 AAPL=no upward_revisions_n=18
- `19:59:58` ✅ data/boom-radar.json bytes=10897 lm=2026-09-17T19:59:45+00:00 version=1.2.0 gated_off=['ESTIMATE', 'BREAKOUT'] top_picks_n=2 methodology_n=5
- `19:59:58` ✅ elapsed_s=20.7
