- `02:34:31` sibling data/eurodollar-stress.json: dict keys=as_of,v,composite_score,severity,regime,n_signals_used,n_signals_total,n_failures,signals,hot_signals,cold_signals,failures
- `02:34:31` sibling data/cb-stance.json: dict keys=generated_at,generated_at_unix,version,model,elapsed_seconds,n_fomc_statements_scored,fed,regime_changed_from_prior,new_statement_since_last_run
**Status:** success  
**Duration:** 15.3s  
**Finished:** 2026-07-07T02:34:46+00:00  

## Data

| canaries | netliq_reading | page_has_risk_strip | pressure | regime | risk | summary | tga_reading |
|---|---|---|---|---|---|---|---|
| 14 | +14 $bn |  | 6 | NEUTRAL | LEAN DUMP(-32) |  | +33 $bn / 13w |
|  |  | True |  |  |  |  |  |
|  |  |  |  |  |  | v2.1: canaries=14 pressure=6 NEUTRAL | risk=LEAN DUMP(-32) | tga=+33 $bn / 13w netliq=+14 $bn |  |

## Log
- `02:34:31` sibling data/china-liquidity.json: dict keys=schema_version,method,generated_at,elapsed_s,fred_failed,series_resolved,regime,regime_read,money,credit_impulse,interbank_rate,currency
- `02:34:31` sibling data/cftc-all-cache.json: dict keys=source,contracts,data,timestamp,cached_at
- `02:34:31`   zip: 14170 bytes
## 1. Lambda

- `02:34:32`   Lambda exists — updating
- `02:34:37` ✅   ✓ updated justhodl-dollar-radar
## 3. Smoke test

- `02:34:37`   invoking justhodl-dollar-radar…
- `02:34:46` ✅   ✓ smoke test passed
- `02:34:46`     ok                       True
- `02:34:46`     dollar_pressure          6
- `02:34:46`     regime                   NEUTRAL
- `02:34:46`     canaries                 14
- `02:34:46`     indices                  4
- `02:34:46`     bilaterals               10
- `02:34:46`     double_top               False
- `02:34:46`     double_bottom            False
- `02:34:46`     build_seconds            8.2
- `02:34:46` canary: Fed net liquidity (13w change) | +14 $bn | NEUTRAL
- `02:34:46` canary: Fed balance sheet trend (QE/QT) | +0.74% / 13w | DUMP
- `02:34:46` canary: Reverse repo (RRP) drain | +2 $bn / 13w | NEUTRAL
- `02:34:46` canary: Treasury General Account | +33 $bn / 13w | NEUTRAL
- `02:34:46` canary: US 10y real yield trend | +0.29 pp / 13w | PUMP
- `02:34:46` canary: US-Germany 10y spread | 1.44 pp (-0.20 / 13w) | DUMP
- `02:34:46` canary: Equity volatility (VIX safe-haven) | 15.8 | DUMP
- `02:34:46` canary: High-yield credit spreads | 2.74% (-0.03 / 13w) | NEUTRAL
- `02:34:46` canary: Dollar index momentum | 120.69 vs 50d/200d | PUMP
- `02:34:46` canary: Offshore dollar funding stress | 39/100 | NEUTRAL
- `02:34:46` canary: US 10y nominal yield trend | 4.49% (+0.09 pp / 13w) | NEUTRAL
- `02:34:46` canary: Fed path repricing (2y yield) | 4.14% (+0.26 pp / 13w) | PUMP
- `02:34:46` canary: Fed FX swap lines outstanding | 0.2 $bn | NEUTRAL
- `02:34:46` canary: China credit impulse | -5.5 pp | PUMP
- `02:34:46` ✅ dollar v2.1 verified live: engine, units, page, consumers
