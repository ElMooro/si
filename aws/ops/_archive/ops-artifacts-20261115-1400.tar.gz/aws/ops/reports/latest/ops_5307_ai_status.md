# ops 5307 -- AI status probe (pipeline, market read, ledger)

**Status:** success  
**Duration:** 0.5s  
**Finished:** 2026-09-10T03:42:28+00:00  

## Error

```
SystemExit: 0
```

## Log
## 1. pipeline

- `03:42:28`    20260910T022941Z: status running stage wait_serve (8/16) since 2026-09-10T03:40:11.015285+00:00 | attempts {"dataset": 1, "deploy_embedding": 2, "wait_embedding": 15, "embed": 2, "train": 1, "wait_train": 3, "serve": 1, "wait_serve": 2}
- `03:42:28`    dataset 20260910T022942283354Z {"n_rows": 13051, "n_train": 10456, "n_validation": 2592, "labels": ["philosophy", "thesis"], "excluded_labels": ["lesson", "macro"], "by_label": {"philosophy": 9641, "thesis": 3407, "lesson": 1, "macro": 2}}
- `03:42:28`    embedding jh-ai-huggingface-sentencesimilarity-all-minilm-l6-v2 realtime=True deploy {"image": "763104351884.dkr.ecr.us-east-1.amazonaws.com/huggingface-pytorch-inference:1.13.1-transformers4.26.0-gpu-py39-cu117-ubuntu20.04", "variant": null, "instance_type": "ml.m5.xlarge", "artifact progress {"status": "complete", "cursor": 13051, "n_rows": 13051, "dim": 384, "errors": 0, "n_embedded": 13243}
- `03:42:28`    classifier job jh-ai-brain-clf-20260910-032814-500 metrics {"validation:mlogloss": 0.13564999401569366, "train:mlogloss": 0.04515000060200691} billable 50s endpoint jh-ai-clf-jh-ai-brain-clf-20260910-032814-500
- `03:42:28`    infer proof null
- `03:42:28`    retrieval None progress null
- `03:42:28`    market read (pipeline) null
- `03:42:28`       02:29:43 deploy_embedding: mxnet-tcembedding-robertafin-base-uncased serverless: serverless needs a CPU image; the hub only declares 763104351884.dkr.ecr.us-east-1.amazonaws.com/mxnet-inference:1.9.0-gpu-py38 for mxnet-tcembedd
- `03:42:28`       02:29:45 wait_embedding: mxnet-tcembedding-robertafin-base-uncased deployed jh-ai-mxnet-tcembedding-robertafin-base-uncased (real-time ml.c5.2xlarge, 763104351884.dkr.ecr.us-east-1.amazonaws.com/mxnet-inference:1.9.0-gpu-py38
- `03:42:28`       02:53:55 wait_embedding: jh-ai-mxnet-tcembedding-robertafin-base-uncased Failed -- The primary container for production variant AllTraffic did not pass the ping health check. Please check CloudWatch logs for this endpoint.
- `03:42:28`       02:53:55 deploy_embedding: next card in the ladder
- `03:42:28`       02:53:55 deploy_embedding: huggingface-sentencesimilarity-all-MiniLM-L6-v2 serverless: serverless needs a CPU image; the hub only declares 763104351884.dkr.ecr.us-east-1.amazonaws.com/huggingface-pytorch-inference:1.13.1-transf
- `03:42:28`       02:53:57 wait_embedding: huggingface-sentencesimilarity-all-MiniLM-L6-v2 deployed jh-ai-huggingface-sentencesimilarity-all-minilm-l6-v2 (real-time ml.m5.xlarge, 763104351884.dkr.ecr.us-east-1.amazonaws.com/huggingface-pytorch
- `03:42:28`       02:59:59 embed: jh-ai-huggingface-sentencesimilarity-all-minilm-l6-v2 InService
- `03:42:28`       03:13:43 embed: cursor 7728/13051
- `03:42:28`       03:28:13 train: embedded 13243 rows dim 384
- `03:42:28`       03:28:14 wait_train: classifier job jh-ai-brain-clf-20260910-032814-500 on ml.m5.xlarge spot=True
- `03:42:28`       03:40:09 serve: job Completed metrics {"validation:mlogloss": 0.13564999401569366, "train:mlogloss": 0.04515000060200691} billable 50s
- `03:42:28`       03:40:11 wait_serve: classifier endpoint jh-ai-clf-jh-ai-brain-clf-20260910-032814-500 (created)
- `03:42:28`    error: jh-ai-mxnet-tcembedding-robertafin-base-uncased: The primary container for production variant AllTraffic did not pass the ping health check. Please check CloudWatch logs for this endpoint.
- `03:42:28`       log: Traceback (most recent call last):
  File "/usr/local/bin/dockerd-entrypoint.py", line 20, in <module>
    from sagemaker_mxnet_serving_container import serving
  File "/usr/local/lib/python3.8/dist-packages/sagemaker_mx
- `03:42:28`       log: OSError: libcuda.so.1: cannot open shared object file: No such file or directory
- `03:42:28`       log: Traceback (most recent call last):
  File "/usr/local/bin/dockerd-entrypoint.py", line 20, in <module>
    from sagemaker_mxnet_serving_container import serving
  File "/usr/local/lib/python3.8/dist-packages/sagemaker_mx
- `03:42:28`       log: OSError: libcuda.so.1: cannot open shared object file: No such file or directory
- `03:42:28`       log: Traceback (most recent call last):
  File "/usr/local/bin/dockerd-entrypoint.py", line 20, in <module>
    from sagemaker_mxnet_serving_container import serving
  File "/usr/local/lib/python3.8/dist-packages/sagemaker_mx
- `03:42:28`       log: OSError: libcuda.so.1: cannot open shared object file: No such file or directory
- `03:42:28`       log: Traceback (most recent call last):
  File "/usr/local/bin/dockerd-entrypoint.py", line 20, in <module>
    from sagemaker_mxnet_serving_container import serving
  File "/usr/local/lib/python3.8/dist-packages/sagemaker_mx
- `03:42:28`       log: OSError: libcuda.so.1: cannot open shared object file: No such file or directory
## 2. market read

- `03:42:28`    read 20260909T220505Z at 2026-09-09T22:05:05.370747+00:00 | playbook False | llm_path direct-failed:HTTP Error 400: Bad Request {"type":"error","error":{"type":"invalid_request_error","message":"Your credit balance is too low to access the Anthropic API. Please go to Plans & Billing to upgrade or purchase credits."},"request_id":"req_011Cetd8evGbwMS8RW55FvQW"} | empty True | parse_error True
- `03:42:28`    raw[:400]: 
- `03:42:28`    stances {"stocks": null, "bonds": null, "metals": null, "crypto": null}
- `03:42:28`    overall: 
- `03:42:28`    opportunities: 
- `03:42:28`    calls: []
- `03:42:28`    performance: {"n_calls": 0, "by_window": {"5": {"hits": 0, "n": 0, "hit_rate": null}, "21": {"hits": 0, "n": 0, "hit_rate": null}, "63": {"hits": 0, "n": 0, "hit_rate": null}}, "error": null}
