# ops 5291 -- BOTTOM launch (Wyckoff bottom desk)

**Status:** success  
**Duration:** 1235.4s  
**Finished:** 2026-09-09T16:16:20+00:00  

## Error

```
SystemExit: 0
```

## Log
- `15:55:46`   Lambda exists — updating
- `15:55:51` ✅   ✓ updated justhodl-bottom
- `15:55:57`    function state Active / Successful, 8192MB / 900s, env keys ['FMP_KEY', 'POLYGON_API_KEY']
- `15:55:58`    invoked async (prior generated_at=2026-09-09T15:40:20Z); polling data/bottom.json
- `15:58:04`    fresh artifact after 126s: v1.1.0 session 2026-09-08 elapsed 118.3s
## universe / states / desks

- `15:58:04`    universe {"instruments": 7666, "scored": 4899, "rows": 599, "sessions": 1260, "window": ["2021-08-31", "2026-09-08"], "crypto_symbols": 64}
- `15:58:04`    by_state {"TRIGGERED": 54, "MARKUP": 142, "ST_CONFIRMED": 18, "TESTING": 49, "CLIMAX": 78, "COMPLETED": 51, "STOPPED": 35, "FAILED": 14, "NO_TEST_BREAKOUT": 70, "EXPIRED": 2, "NO_RALLY": 86}
- `15:58:04`    by_desk  {"stocks": 551, "countries": 13, "crypto": 22, "gold_metals": 1, "equity_etfs": 12}
- `15:58:04`    breadth  {"in_bottom_process": 341, "share_of_universe_pct": 7.0, "climax_5d": 37, "testing": 49, "test_confirmed": 18, "triggered_5d": 43, "failed_10d": 27, "weekly_live": 137}
- `15:58:04`    read: selective bottoming processes
- `15:58:04`    benchmarks: {"SPY": {"last": 765.96, "daily": "NONE", "weekly": "NONE", "daily_sc_date": null, "n_sequences_5y": 2}, "QQQ": {"last": 718.36, "daily": "NONE", "weekly": "NONE", "daily_sc_date": null, "n_sequences_5y": 3}, "IWM": {"last": 294.67, "daily": "NONE", "weekly": "NONE", "daily_sc_date": null, "n_sequences_5y": 6}, "TLT": {"last": 82.2, "daily": "NONE", "weekly": "NONE", "daily_sc_date": null, "n_sequences_5y": 2}, "GLD": {"last": 399.72, "daily": "NONE", "weekly": "NONE", "daily_sc_date": null, "n_sequences_5y": 1}, "UUP": {"last": 27.99, "daily": "NONE", "weekly": "NONE", "daily_sc_date": null, 
- `15:58:04`    authority {"mode": "SELECTIVE", "allows_new_entries": true, "status": "DEGRADED", "cap_pct": 50.0, "policy_cap_pct": 50.0, "generated_at": "2026-09-09T15:20:50.173720+00:00"} | risk gate {"posture": "NEUTRAL", "sizing_multiplier": 0.75, "generated_at": "2026-09-09T15:40:55.323971+00:00"} | katlin posture SELECTIVE
## board / rows / contract

- `15:58:04`    board 320 rows (with charts), board_all 599 rows, weekly_live 120, top_picks 42
- `15:58:04`       PTCT   stocks   TRIGGERED     D      92.7 A     sc 2026-07-31 2.38x  test 2026-08-24 21%  trig 2026-08-25  plan 71.45/67.6504/75.0  fleet 2
- `15:58:04`       PLOW   stocks   TRIGGERED     D      90.5 A     sc 2026-08-03 4.34x  test 2026-08-18 25%  trig 2026-08-21  plan 41.9/40.6029/45.99  fleet 1
- `15:58:04`       ORN    stocks   TRIGGERED     D      89.9 A     sc 2026-07-29 8.04x  test 2026-08-21 11%  trig 2026-08-27  plan 9.33/8.8722/11.38  fleet 1
- `15:58:04`       BKKT   stocks   TRIGGERED     D      89.6 A     sc 2026-08-19 2.39x  test 2026-09-01 31%  trig 2026-09-03  plan 7.55/7.062/9.018  fleet 0
- `15:58:04`       WSO    stocks   TRIGGERED     D      88.3 A     sc 2026-07-29 5.5x  test 2026-08-25 11%  trig 2026-08-26  plan 313.445/296.4285/336.44  fleet 0
- `15:58:04`       PHAT   stocks   TRIGGERED     D      87.2 A     sc 2026-07-30 7.08x  test 2026-08-24 13%  trig 2026-08-27  plan 8.92/8.4378/9.745  fleet 1
- `15:58:04`       SBGI   stocks   TRIGGERED     D      86.8 A     sc 2026-06-26 3.73x  test 2026-07-23 26%  trig 2026-07-28  plan 13.7/13.0685/15.54  fleet 1
- `15:58:04`       PCT    stocks   TRIGGERED     W      85.4 A     sc 2026-02-27 2.25x  test 2026-07-31 47%  trig 2026-08-07  plan 6.55/5.5998/13.29  fleet 1
- `15:58:04`       CMP    stocks   TRIGGERED     D      85.3 A     sc 2026-08-06 3.85x  test 2026-08-18 29%  trig 2026-08-21  plan 25.91/24.3112/27.82  fleet 0
- `15:58:04`       GNTX   stocks   TRIGGERED     D      84.0 A     sc 2026-07-24 3.06x  test 2026-09-01 32%  trig 2026-09-02  plan 22.505/21.9614/24.44  fleet 0
- `15:58:04`       TLK    stocks   TRIGGERED     D      83.6 A     sc 2026-06-08 3.6x  test 2026-06-30 47%  trig 2026-07-01  plan 13.54/13.17/16.39  fleet 1
- `15:58:04`       FLIN   countrie TRIGGERED     W      81.4 A     sc 2026-03-27 2.33x  test 2026-05-22 19%  trig 2026-05-29  plan 34.85/33.6859/36.88  fleet 1
## base rates (graded from the tape)

- `15:58:04`    sequences 19756, with rally 14504, triggered 5969, outcome mix {"STOPPED": 3825, "NO_TEST_BREAKOUT": 6409, "NO_RALLY": 5405, "COMPLETED": 2144, "FAILED": 1928, "EXPIRED": 45}
- `15:58:04`    triggered all: {"n": 5969, "ret_21": {"n": 5932, "median": 0.58, "mean": 2.93, "hit": 52.0}, "ret_63": {"n": 5657, "median": 2.65, "mean": 10.89, "hit": 55.0}, "managed_21": {"n": 5969, "median": -3.27, "mean": 1.92, "hit": 41.0}, "managed_63": {"n": 5892, "median": -5.14, "mean": 5.48, "hit": 32.0}, "stop_hit_pct": 64.0, "target1_hit_pct": 78.0, "mae_median": -7.2, "mfe_median": 8.7, "target1_before_stop_pct": 79.0, "stops": {"rules": {"paper": {"n": 5969, "stop_hit_pct": 64.0, "managed_21": {"n": 5969, "medi
- `15:58:04`    crowd vs pro: {"crowd_buys_the_bounce": {"n": 14414, "ret_21": {"n": 14414, "median": 2.22, "mean": 5.39, "hit": 58.0}, "ret_63": {"n": 13868, "median": 4.92, "mean": 13.3, "hit": 59.0}, "worst_drawdown_median_pct": -10.7, "later_undercut_climax_low_pct": 52.0, "sequence_failed_pct": 13.0}, "pro_waits_for_the_trigger": {"n": 5969, "ret_21": {"n": 5969, "median": -3.27, "mean": 1.92, "hit": 41.0}, "ret_63": {"n": 5892, "median": -5.14, "mean": 5.48, "hit": 32.0}, "worst_drawdown_median_pct": -7.2, "stopped_out_pct": 64.0, "share_of_sequences_that_ever_trigger_pct": 41.0}, "note": "measured from every selling-climax sequence in the 5-year window; crowd entry = close of the bar the automatic rally reached 2 ATR off the low; pro entry = close above the test candle's high; managed returns exit at the stop when it hits first"}
- `15:58:04`       bonds        n   87  +21 2.32 (hit 72.0%)  +63 -0.41 (hit 42.0%)  managed63 -1.44  stop 67.0%  t1 85.0%
- `15:58:04`       commodities  n   29  +21 1.66 (hit 55.0%)  +63 4.84 (hit 76.0%)  managed63 -2.21  stop 52.0%  t1 93.0%
- `15:58:04`       countries    n  148  +21 3.77 (hit 66.0%)  +63 2.6 (hit 56.0%)  managed63 -2.28  stop 64.0%  t1 91.0%
- `15:58:04`       crypto       n  184  +21 -1.85 (hit 45.0%)  +63 -1.54 (hit 45.0%)  managed63 -11.42  stop 71.0%  t1 68.0%
- `15:58:04`       currencies   n    2  +21 1.09 (hit 50.0%)  +63 3.79 (hit 50.0%)  managed63 -5.19  stop 100.0%  t1 50.0%
- `15:58:04`       equity_etfs  n  435  +21 1.28 (hit 58.0%)  +63 -0.5 (hit 48.0%)  managed63 -3.8  stop 72.0%  t1 88.0%
- `15:58:04`       gold_metals  n   20  +21 0.84 (hit 50.0%)  +63 10.83 (hit 67.0%)  managed63 -3.08  stop 60.0%  t1 90.0%
- `15:58:04`       stocks       n 5064  +21 0.31 (hit 51.0%)  +63 3.48 (hit 56.0%)  managed63 -5.58  stop 63.0%  t1 77.0%
- `15:58:04`       test volume quiet (<=0.4x climax)  n 3223  +63 2.61 (hit 55.0%)  stop 67.0%
- `15:58:04`       test volume diminished (0.4-0.7x)  n 2000  +63 2.5 (hit 55.0%)  stop 62.0%
- `15:58:04`       test volume loud (>0.7x)           n  746  +63 3.26 (hit 57.0%)  stop 55.0%
- `15:58:04`       stop rule paper   n  5969  hit 64.0%  bars-to-stop 11.0  managed +21 -3.27 (hit 41.0%)  +63 -5.14 (hit 32.0%)
- `15:58:04`       stop rule climax  n  5969  hit 53.0%  bars-to-stop 15.0  managed +21 -1.21 (hit 47.0%)  +63 -5.37 (hit 39.0%)
- `15:58:04`       stop rule wide    n  5969  hit 47.0%  bars-to-stop 18.0  managed +21 -0.17 (hit 50.0%)  +63 -5.1 (hit 43.0%)
- `15:58:04`    finding: 5969 sequences reached the trigger. Unmanaged, the trigger entry made a median +2.6% after 63 bars (hit 55%) and reached the rally high (target 1) in 78% of cases, 79% of them before the paper's stop was touched.
- `15:58:04`    finding: The paper's stop (0.1 ATR under the test low) was hit in 64% of triggered sequences (median 11 bars after entry); managed by that stop the 63-bar outcome is a median -5.1% (hit 32%). A stop that tight is whipsawed by the range itself: the tape revisits the tes
- `15:58:04`    finding: Alternatives measured on the same trades: a stop 0.25 ATR under the climax low is hit 53% of the time (managed 63-bar median -5.4%); a stop 1 ATR under the test low is hit 47% (median -5.1%). Best rule by median managed return: wide.
- `15:58:04`    finding: The crowd's bounce entry (n 14414) made a median +4.9% after 63 bars (hit 59%) but with a median worst drawdown of -10.7%; in 52% of sequences the tape later undercut the climax low and 13% failed outright. Waiting for the test forfeits the V-bottoms: 32% of a
- `15:58:04`    finding: Test volume: quiet tests (<=0.4x climax volume, n 3223) made a median +2.6% at 63 bars vs +3.3% for loud tests (n 746) -- no return edge from the volume ratio alone in this window; use it as a risk filter, not a return forecast.
- `15:58:04`    finding: Grade A sequences (n 1057) made a median +17.8% at 63 bars vs +16.2% for grade C (n 256).
- `15:58:04`    [bottom] feeds: finviz=11614 accum=17 phase=681 fortress=950 katlin=252 f13=7526 dark=941 insider=15 flows=300
## health

- `15:58:04`    degraded: []
- `15:58:04`    row_errors: {}
- `15:58:04`    feeds_asof: {"finviz": "2026-09-09T14:00:38.228355+00:00", "accumulation_radar": "2026-09-08T21:50:21.620419+00:00", "phase_detector": "2026-09-08T22:10:41.844108+00:00", "fortress": "2026-09-09T03:31:57+00:00", "katlin": "2026-09-09T15:47:27Z", "f13": "2026-09-09T15:07:02.645497+00:00", "dark_pool": "2026-09-09T14:01:20.450489+00:00", "insider": "2026-09-09T14:40:29.846595+00:00", "etf_flows": "2026-09-08T22:00:25.396312+00:00"}
- `15:58:04`       [bottom] feeds: finviz=11614 accum=17 phase=681 fortress=950 katlin=252 f13=7526 dark=941 insider=15 flows=300
- `15:58:04`       [bottom] universe: 7666 instruments (3838 stocks, 3828 etf wrappers)
- `15:58:04`       [bottom] bars 28/1260 sessions, 4599 tickers
- `15:58:04`       [bottom] bars 308/1260 sessions, 5056 tickers
- `15:58:04`       [bottom] bars 588/1260 sessions, 5510 tickers
- `15:58:04`       [bottom] bars 868/1260 sessions, 6180 tickers
- `15:58:04`       [bottom] bars 1148/1260 sessions, 7141 tickers
- `15:58:04`       [bottom] split repair: 4 names rebased (calendar banked 2026-09-08)
- `15:58:04`       [bottom] bars loaded: 1260 sessions 2021-08-31..2026-09-08, 7662 tickers in 64s
- `15:58:04`       [bottom] equities/wrappers: 4836 scored, 587 rows with a live or recent sequence, 19353 historical sequences in 116s
- `15:58:04`       [bottom] crypto lane: 64 symbols, 63 with >=200 days, 0 errors
- `15:58:04`    data/bottom.json = 2.23 MB
## schedule (EventBridge Scheduler, UTC)

- `15:58:05` ✅    justhodl-bottom-daily updated cron(45 3 ? * TUE-SAT *)
## page

- `15:58:05`    bottom.html carries marker BOTTOM_DESK_V1 at the edge: True
- `15:58:30`    1440px: {"headline": "selective bottoming processes", "funnel": 7, "board": 320, "helps": 22, "evid": 424, "svg": true, "defs": 14, "overflow": 0, "err": "", "rates_cards": 2, "rates_tables": 6} errors=[]
- `15:58:41`     390px: {"headline": "selective bottoming processes", "funnel": 7, "board": 320, "helps": 22, "evid": 429, "svg": true, "defs": 14, "overflow": 0, "err": "", "rates_cards": 2, "rates_tables": 6} errors=[]
## consumers

- `16:06:14`    katlin v2.5.1 fresh: 249 picks, 52 carry wyckoff_bottom ([('TLRY', 'TESTING'), ('HCKT', 'TRIGGERED'), ('ADMA', 'ST_CONFIRMED'), ('CNXC', 'MARKUP'), ('PHR', 'MARKUP'), ('QDEL', 'MARKUP')])
- `16:16:20`    alert-router invoked (check_bottom registered; Telegram delivery depends on the bot token Khalid must rotate)
- `16:16:20` ⚠    desk bonds has no live/recent sequence this session (possible, but check the classifier if it persists)
- `16:16:20` ⚠    desk commodities has no live/recent sequence this session (possible, but check the classifier if it persists)
- `16:16:20` ⚠    jhsignal-bridge redeploy not observed within 10 min -- fusion proof waits for the hourly bridge
- `16:16:20` ✅    GREEN: BOTTOM live -- engine, feed, schedule, page (with warnings)
