# ops 5580 -- harvest serving path: Cloudflare data-proxy -> S3 (no CloudFront); origin freshness

**Status:** success  
**Duration:** 0.3s  
**Finished:** 2026-09-15T04:35:33+00:00  

## Log
- `04:35:33` ✅ s3://justhodl-dashboard-live/data/fmp-ratios.json: 181618 bytes, application/json, cache-control=max-age=300, last-modified=2026-09-15 04:25:42+00:00
- `04:35:33` ✅ s3://justhodl-dashboard-live/data/cryptoquant-onchain.json: 59938 bytes, application/json, cache-control=max-age=300, last-modified=2026-09-15 04:19:18+00:00
- `04:35:33` ✅ s3://justhodl-dashboard-live/data/symbology/master.json: 3816209 bytes, application/json, cache-control=no-cache, last-modified=2026-09-14 05:16:06+00:00
- `04:35:33` ✅ serving: justhodl.ai/data/* -> Cloudflare worker justhodl-data-proxy -> S3 object (max-age 300 s); no invalidation exists or is needed
- `04:35:33` ✅ GREEN -- harvest reachable from the chart's origin; the chart bug was the lookup key (US__AAPL), fixed in 5a3eb89cc
