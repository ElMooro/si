# ops 4643 — DXY predict-the-future engine

**Status:** success  
**Duration:** 73.6s  
**Finished:** 2026-08-13T00:02:30+00:00  

## Data

| by_prefix | candidates | fn_error | list | members | n_unresolved | polarity_rows | resolved | reversal | rlabel | tlabel | trend |
|---|---|---|---|---|---|---|---|---|---|---|---|
|  | [["Bitcoin : Nikkei TOP and Bottom in USD ALWAYS MARKED Bitcoin and Crypto Top and Bottom.", 437], ["Crypto : Nikkei TOP and Bottom in USD ALWAYS MARKED Bitcoin and Crypto Top and Bottom.", 327], ["Dollar Shortage Indicators", 17], ["DXY predict Future Moves : Currencies best seen in \"3M\": FED hiking rates strengthen the Dollar", 85], ["DXY: Currencies best seen in \"3M\" : DXY pumping means tightening and liquidity drying up in the Eurodollar system.", 90], ["DXY: DIFFERENT TYPE OF DXY: IN CURRENCY MARKETS THE UPSIDE AND DOWNSIDE ARE SYMMETRICAL.", 18], ["Emerging Market Sovereign Crisis - Eurodollar crisis", 20], ["Euro Dollar Shortage & Liquidity squeeze", 14]] |  |  |  |  |  |  |  |  |  |  |
|  |  | None |  |  |  |  |  |  |  |  |  |
|  |  |  | DXY FAMILY (21 lists) | 408 |  | 22 | 229 | -54.5 | CONFIRMED TURN TO USD-DOWN | USD_UP | 36.4 |
| [["TVC", 75], ["ECONOMICS", 37], ["NASDAQ", 10], ["1-TVC", 9], ["ICEEUR", 8], ["FX", 4], ["HKEX", 4], ["CME", 3], ["FX_IDC", 2], ["ICEUS", 2]] |  |  |  |  | 172 |  |  |  |  |  |  |

## Log
## pre-dump: dxy/dollar list candidates

- `00:01:17` ✅   [list-exists] dxy/dollar list present: [('Bitcoin : Nikkei TOP and Bottom in USD ALWAYS MARKED Bitcoin and Crypto Top and Bottom.', 437), ('Crypto : Nikkei TOP and Bottom in USD ALWAYS MARKED Bitcoin and Crypto Top and Bottom.', 327), ('Dollar Shortage Indicators', 17)]
## deploy (ops-side) + settle + schedule

- `00:01:19` ✅   [deploy] v1.1.0 live (created=False)
## crypto-closes shape (pre-dump)

- `00:01:19` dates=235 series_keys(30)=['BTC', 'NEAR', 'ADA', 'XLM', 'SOL', 'ETH', 'XRP', 'DOGE', 'SUI', 'LTC', 'XMR', 'LINK', 'ZEC', 'UST', 'HYPE', 'ONDO', 'AVAX', 'ENA', 'TAO', 'BICO', 'CRV', 'UNI', 'DOT', 'FET']
## run + dxy truth

- `00:02:30` crypto z-based: 0 (e.g. [])
- `00:02:30` ⚠ crypto route armed fleet-wide; this family holds no crypto members (keyword hygiene excluded the Nikkei-crypto lists)
- `00:02:30` ✅   [crypto-route] 0 crypto rows here (route armed)
- `00:02:30` CME:GE1! · NASDAQ:NQEMASIA3010T · ECONOMICS:EUCU+ECONO · ECONOMICS:EUMPMI · TVC:CN10Y-TVC:US10Y · 1/(TVC:CN10Y/TVC:DXY
- `00:02:30` TVC:CN10Y/TVC:DXY · FTSE:FTEMSLU · ICEEUR:I1! · EUREX:FMMG1! · TVC:JXY · TVC:EXY
- `00:02:30` TVC:SG10 · FX_IDC:USDWCU · TVC:CN02Y-TVC:US02Y · TVC:JP02Y-TVC:US02Y · TVC:EU02Y-TVC:US02Y · ECONOMICS:DEMPMI
- `00:02:30` TVC:US10Y-TVC:CN10Y · NASDAQ:NQEUSCEUR · TVC:EU02Y · RUS:ED1! · SWB:JSGW · TVC:CL10Y-TVC:CL02Y
- `00:02:30` ECONOMICS:EUESI · FX:EURDLR3M · ECONOMICS:EULR · FX:EMBASKET · FRED:ICERATES1100USD · TVC:GB05Y
- `00:02:30` TVC:CN10 · CBOE:EVZ · NASDAQ:EUI · TVC:SXY · TVC:ZXY · TVC:AXY
- `00:02:30` ICEUS:DX1!-TVC:DXY · LUXSE:LU0310511422 · DUS:JSGW · FWB:JSGW · NYMEX:CL1!-BLACKBULL · ECONOMICS:USRR-FRED:
- `00:02:30` 1-TVC:HK02Y · ECONOMICS:SGINBR · ECONOMICS:PAINTR · HKEX:HB11! · HKEX:HB31! · HKEX:HB12!
- `00:02:30` ECONOMICS:KRINTR-ECO · TVC:JP03MY · ICEEUR:USW1! · ICEEUR:SF32! · HKEX:HB32! · ICEEUR:SO32!
- `00:02:30` NASDAQ:NQEM3010 · NASDAQ:NQHKBANK · NASDAQ:NQEM30 · NASDAQ:NQJP30T · NASDAQ:NQJP3010T · OMXNORDIC:OMRXGOVT
- `00:02:30` FX_IDC:KYDUSD              pol=-1 trend=DOWN  rev=REVERSAL_DOWN  z=2.76
- `00:02:30` FX_IDC:USDCNY              pol=+1 trend=DOWN  rev=REVERSAL_DOWN  z=1.67
- `00:02:30` FX_IDC:CNYUSD              pol=-1 trend=UP    rev=REVERSAL_UP    z=1.67
- `00:02:30` FRED:DTWEXAFEGS            pol=+1 trend=UP    rev=REVERSAL_DOWN  z=1.24
- `00:02:30` FRED:DTWEXBGS              pol=+1 trend=UP    rev=REVERSAL_DOWN  z=1.11
- `00:02:30` FX:USDCHF                  pol=+1 trend=UP    rev=REVERSAL_DOWN  z=1.02
- `00:02:30` FX_IDC:CHFUSD              pol=-1 trend=DOWN  rev=REVERSAL_UP    z=1.01
- `00:02:30` FRED:DTWEXEMEGS            pol=+1 trend=DOWN  rev=REVERSAL_DOWN  z=0.86
- `00:02:30` FX:NZDUSD                  pol=-1 trend=UP    rev=NONE           z=0.69
- `00:02:30` FX_IDC:KRWUSD              pol=-1 trend=UP    rev=NONE           z=0.59
- `00:02:30` FX_IDC:USDKRW              pol=+1 trend=DOWN  rev=NONE           z=0.58
- `00:02:30` TVC:US10Y-TVC:DE10Y        pol=+1 trend=UP    rev=NONE           z=0.51
- `00:02:30` TVC:DXY                    pol=+1 trend=UP    rev=REVERSAL_DOWN  z=0.49
- `00:02:30` FX:USDJPY                  pol=+1 trend=UP    rev=REVERSAL_DOWN  z=0.47
- `00:02:30` ✅   [list-found] list 'DXY FAMILY (21 lists)' (408 members)
- `00:02:30` ✅   [resolution] 229/408 resolved (shared cache pool)
- `00:02:30` ✅   [polarity] 22 mechanically-signed rows
- `00:02:30` ✅   [dials] DXY TREND 36.4 (USD_UP) · REVERSAL -54.5 (CONFIRMED TURN TO USD-DOWN)
## edge

- `00:02:30` ✅   [edge] page + payload at the edge
## verdict

- `00:02:30` ✅ DXY PREDICT LIVE — list 'DXY FAMILY (21 lists)': 229/408 resolved, 22 signed rows · TREND 36.4 (USD_UP) · REVERSAL -54.5 (CONFIRMED TURN TO USD-DOWN) · https://justhodl.ai/dxy-predict.html
