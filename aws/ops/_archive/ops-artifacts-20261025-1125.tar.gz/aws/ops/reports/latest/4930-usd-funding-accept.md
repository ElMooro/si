# ops 4930 — justhodl-usd-funding v1.0.0 launch

**Status:** success  
**Duration:** 0.6s  
**Finished:** 2026-08-20T03:59:26+00:00  

## Data

| status |
|---|
| RED |

## Log
## Invoke

- `03:59:25` ✗ invoke failed: An error occurred (ResourceNotFoundException) when calling the Invoke operation: Function not found: arn:aws:lambda:us-east-1:857687956942:function:justhodl-usd
## Read live payload

- `03:59:26` ✗ cannot read data/usd-funding.json: An error occurred (NoSuchKey) when calling the GetObject operation: The specified key does not exist.
