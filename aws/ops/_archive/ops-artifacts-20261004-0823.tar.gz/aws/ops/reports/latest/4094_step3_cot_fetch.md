# ops 4094 — STEP 3 fetch half: cftc on the ALIAS path

**Status:** failure  
**Duration:** 759.9s  
**Finished:** 2026-07-29T21:05:23+00:00  

## Error

```
SystemExit: 1
```

## Data

| cftc_live | cot_aliased | cot_skipped | cot_total | n_aliases | vault_live | vault_rows |
|---|---|---|---|---|---|---|
|  | 65 | 0 | 340 | 911 |  |  |
| 0 |  |  |  |  | 1176 | 1358 |

## Log
## A. deploy resolver v3.0 + vault v3.13.0

- `20:52:55`   ✓ justhodl-symbol-resolver settled (attempt 2)
- `20:53:18`   ✓ justhodl-tradingview settled (attempt 2)
## B. resolve COT tickers (async + poll)

- `20:57:19`   ✓ data/symbol-aliases.json moved after 240s
- `20:57:19`   COT tickers 340 · aliased 65 · skipped 0
- `20:57:19`   by_route: {'fred-verified': 696, 'economics-matched': 150, 'cot-verified': 65}
## Verified COT aliases (sample)

- `20:57:19`   020601_FO_AMP_SPREAD       → cftc:yw9f-hn96:020601:asset_mgr_positions_sp asof 2026-07-21
- `20:57:19`   020601_FO_DP_SPREAD        → cftc:yw9f-hn96:020601:dealer_positions_sprea asof 2026-07-21
- `20:57:19`   020601_FO_LMP_SPREAD       → cftc:yw9f-hn96:020601:lev_money_positions_sp asof 2026-07-21
- `20:57:19`   020601_FO_ORP_SPREAD       → cftc:yw9f-hn96:020601:other_rept_positions_s asof 2026-07-21
- `20:57:19`   020601_FO_TAM_SPREAD       → cftc:yw9f-hn96:020601:traders_asset_mgr_spre asof 2026-07-21
- `20:57:19`   020601_FO_TD_SPREAD        → cftc:yw9f-hn96:020601:traders_dealer_spread_ asof 2026-07-21
- `20:57:19`   020601_FO_TLM_SPREAD       → cftc:yw9f-hn96:020601:traders_lev_money_spre asof 2026-07-21
- `20:57:19`   020601_FO_TOR_SPREAD       → cftc:yw9f-hn96:020601:traders_other_rept_spr asof 2026-07-21
- `20:57:19`   020601_F_AMP_SPREAD        → cftc:gpe5-46if:020601:asset_mgr_positions_sp asof 2026-07-21
- `20:57:19`   020601_F_DP_SPREAD         → cftc:gpe5-46if:020601:dealer_positions_sprea asof 2026-07-21
- `20:57:19`   020601_F_LMP_SPREAD        → cftc:gpe5-46if:020601:lev_money_positions_sp asof 2026-07-21
- `20:57:19`   020601_F_ORP_SPREAD        → cftc:gpe5-46if:020601:other_rept_positions_s asof 2026-07-21
- `20:57:19`   020601_F_TAM_SPREAD        → cftc:gpe5-46if:020601:traders_asset_mgr_spre asof 2026-07-21
- `20:57:19`   020601_F_TD_SPREAD         → cftc:gpe5-46if:020601:traders_dealer_spread_ asof 2026-07-21
## C. vault fetches them for real

- `21:05:23`   ✓ data/tradingview.json moved after 480s
- `21:05:23`   vault rows 1314 → 1358 · LIVE 1132 → 1176
## CFTC-routed symbols carrying real values

## VERDICT

- `21:05:23`   ✓ resolver v3.0 settled
- `21:05:23`   ✓ vault v3.13.1 settled
- `21:05:23`   ✓ resolver async accepted
- `21:05:23`   ✓ COT aliases produced
- `21:05:23`   ✓ every COT alias points at a real CFTC column
- `21:05:23`   ✓ every COT alias was verified against a live row
- `21:05:23`   ✓ vault async accepted
- `21:05:23`   ✗ cftc: adapter returns real values
- `21:05:23`   ✓ pre-existing LIVE not regressed
- `21:05:23` ✗ FAILED: ['cftc: adapter returns real values']
