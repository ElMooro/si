## Fuse into risk-regime (risk-off block)

**Status:** success  
**Duration:** 28.2s  
**Finished:** 2026-07-16T17:39:39+00:00  

## Log
- `17:39:11`   zip: 85774 bytes
## 1. Lambda

- `17:39:11`   Lambda exists — updating
- `17:39:16` ✅   ✓ updated justhodl-risk-regime
## 2. EB rule + permissions

- `17:39:16`   rule already correct: justhodl-risk-regime-daily (cron(45 12 ? * MON-FRI *))
- `17:39:16` ✅   ✓ target → justhodl-risk-regime
- `17:39:17` ✅   ✓ added invoke permission
- `17:39:23`   risk-regime score=None regime=None
- `17:39:23` ✅ eurodollar_hub block LIVE in risk-regime: present in payload
## Fuse into crisis-composite (DEFCON component)

- `17:39:23`   zip: 81743 bytes
## 1. Lambda

- `17:39:23`   Lambda exists — updating
- `17:39:26` ✅   ✓ updated justhodl-crisis-composite
## 2. EB rule + permissions

- `17:39:26`   rule already correct: crisis-composite-hourly (cron(15 * * * ? *))
- `17:39:26` ✅   ✓ target → justhodl-crisis-composite
- `17:39:26` ✅   ✓ added invoke permission
- `17:39:39`   crisis-composite master=None DEFCON=None
- `17:39:39` ✅ eurodollar-hub component LIVE in crisis-composite: Eurodollar-hub sovereign distress (CDS) = None (weight 0.15)
## tail-risk left clean (by design)

- `17:39:39` ✅ tail-risk NOT modified — self-contained options-implied density; CDS would pollute the model.
