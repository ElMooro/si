## P0 shape evidence (runner)

**Status:** failure  
**Duration:** 4716.8s  
**Finished:** 2026-08-26T22:59:15+00:00  

## Error

```
SystemExit: 1
```

## Log
- `21:40:39`   getMetadata MD11: 399164B head=b'{\n "STATUS":200,\n "MESSAGEID":"M181000I",\n "MESSAGE":"Successfully completed",\n "DATE":"2026-08-22T5:01:59.017+09:00",\n "DB":"MD11",\n "RESULTSET":[\n{\n "SERIES_CODE":"",\n "NAME_OF_TIME_SERIES":"Deposits, Vault Cash, and L'
- `21:40:39`   getDataCode err HTTP Error 400: Bad Request
## G0 settle

- `21:40:39`   settled (0s)
## G0 runner-deploys (event-blip fallback)

- `21:40:40`   justhodl-boj-full already carries v1.1.3 ops4987
- `21:40:40`   justhodl-provider-catalog already carries boj-note-v3
## P0b window ladder (single code)

- `21:40:40`   full -> HTTP Error 400: Bad Request
- `21:40:41`   20y (197001-198912) -> 3584B dates=True
- `21:40:42`   10y (198001-198912) -> 2144B dates=True
- `21:40:42`   5y (198501-198912) -> 1424B dates=True
- `21:40:43`   2y (198801-198912) -> 992B dates=True
- `21:40:43`   widest working window: 20y (engine CHUNK_Y=10)
## P1 sharded sync drive (6 lanes, 60min)

- `21:40:44`   dbs=22 ['BP01', 'BS01', 'BS02', 'FF', 'FM01', 'FM02', 'FM03', 'FM08', 'IR01', 'IR02', 'IR03', 'IR04', 'LA01', 'MD01', 'MD02', 'MD11', 'MD12', 'MD13', 'PR01', 'PR02', 'PR03', 'PS01']
- `21:41:29`   t+  45s series 50986/85102 parts=7148 live=2
- `21:42:15`   t+  91s series 51046/85102 parts=7148 live=2
- `21:43:01`   t+ 136s series 51106/85102 parts=7148 live=2
- `21:43:46`   t+ 182s series 51106/85102 parts=7148 live=2
- `21:44:32`   t+ 228s series 51226/85102 parts=7148 live=2
- `21:45:18`   t+ 273s series 51226/85102 parts=7148 live=2
- `21:46:03`   t+ 319s series 51226/85102 parts=7148 live=2
- `21:46:49`   t+ 365s series 51346/85102 parts=7148 live=2
- `21:47:34`   t+ 410s series 51346/85102 parts=7148 live=2
- `21:48:20`   t+ 456s series 51346/85102 parts=7148 live=2
- `21:49:06`   t+ 502s series 51466/85102 parts=7148 live=2
- `21:49:52`   t+ 548s series 51466/85102 parts=7148 live=2
- `21:50:37`   t+ 593s series 51586/85102 parts=7148 live=2
- `21:51:23`   t+ 639s series 51586/85102 parts=7148 live=2
- `21:52:09`   t+ 685s series 51586/85102 parts=7148 live=2
- `21:52:54`   t+ 730s series 51706/85102 parts=7148 live=2
- `21:53:40`   t+ 776s series 51706/85102 parts=7148 live=2
- `21:54:26`   t+ 822s series 51826/85102 parts=7148 live=2
- `21:55:11`   t+ 867s series 51826/85102 parts=7148 live=2
- `21:55:57`   t+ 913s series 51886/85102 parts=7148 live=2
- `21:56:43`   t+ 959s series 51946/85102 parts=7148 live=2
- `21:57:28`   t+1004s series 51946/85102 parts=7148 live=2
- `21:58:14`   t+1050s series 52066/85102 parts=7148 live=2
- `21:59:00`   t+1095s series 52066/85102 parts=7148 live=2
- `21:59:45`   t+1141s series 52186/85102 parts=7148 live=2
- `22:00:31`   t+1187s series 52186/85102 parts=7148 live=2
- `22:01:17`   t+1232s series 52186/85102 parts=7148 live=2
- `22:02:02`   t+1278s series 52306/85102 parts=7148 live=2
- `22:02:48`   t+1324s series 52306/85102 parts=7148 live=2
- `22:03:34`   t+1369s series 52306/85102 parts=7148 live=2
- `22:04:19`   t+1415s series 52426/85102 parts=7148 live=2
- `22:05:05`   t+1461s series 52426/85102 parts=7148 live=2
- `22:05:50`   t+1506s series 52546/85102 parts=7148 live=2
- `22:06:36`   t+1552s series 52546/85102 parts=7148 live=2
- `22:07:22`   t+1598s series 52546/85102 parts=7148 live=2
- `22:08:07`   t+1643s series 52666/85102 parts=7148 live=2
- `22:08:53`   t+1689s series 52666/85102 parts=7148 live=2
- `22:09:39`   t+1735s series 52786/85102 parts=7148 live=2
- `22:10:24`   t+1780s series 52786/85102 parts=7148 live=2
- `22:11:10`   t+1826s series 52786/85102 parts=7148 live=2
- `22:11:55`   t+1871s series 52906/85102 parts=7148 live=2
- `22:12:41`   t+1917s series 52906/85102 parts=7148 live=2
- `22:13:27`   t+1963s series 53026/85102 parts=7148 live=2
- `22:14:12`   t+2008s series 53026/85102 parts=7148 live=2
- `22:14:58`   t+2054s series 53086/85102 parts=7148 live=2
- `22:15:44`   t+2099s series 53146/85102 parts=7148 live=2
- `22:16:29`   t+2145s series 53146/85102 parts=7148 live=2
- `22:17:15`   t+2191s series 53206/85102 parts=7148 live=2
- `22:18:01`   t+2237s series 53266/85102 parts=7148 live=2
- `22:18:46`   t+2282s series 53266/85102 parts=7148 live=2
- `22:19:32`   t+2328s series 53386/85102 parts=7148 live=2
- `22:20:18`   t+2374s series 53386/85102 parts=7148 live=2
- `22:21:03`   t+2419s series 53446/85102 parts=7148 live=2
- `22:21:49`   t+2465s series 53506/85102 parts=7148 live=2
- `22:22:35`   t+2511s series 53506/85102 parts=7148 live=2
- `22:23:20`   t+2556s series 53626/85102 parts=7148 live=2
- `22:24:06`   t+2602s series 53626/85102 parts=7148 live=2
- `22:24:52`   t+2648s series 53686/85102 parts=7148 live=2
- `22:25:37`   t+2693s series 53746/85102 parts=7148 live=2
- `22:26:23`   t+2739s series 53806/85102 parts=7148 live=2
- `22:27:09`   t+2785s series 53866/85102 parts=7148 live=2
- `22:27:55`   t+2830s series 53866/85102 parts=7148 live=2
- `22:28:40`   t+2876s series 53926/85102 parts=7148 live=2
- `22:29:26`   t+2922s series 53986/85102 parts=7148 live=2
- `22:30:12`   t+2967s series 54046/85102 parts=7148 live=2
- `22:30:57`   t+3013s series 54106/85102 parts=7148 live=2
- `22:31:43`   t+3059s series 54106/85102 parts=7148 live=2
- `22:32:28`   t+3104s series 54166/85102 parts=7148 live=2
- `22:33:14`   t+3150s series 54226/85102 parts=7148 live=2
- `22:34:00`   t+3196s series 54226/85102 parts=7148 live=2
- `22:34:45`   t+3241s series 54286/85102 parts=7148 live=2
- `22:35:31`   t+3287s series 54346/85102 parts=7148 live=2
- `22:36:17`   t+3332s series 54406/85102 parts=7148 live=2
- `22:37:02`   t+3378s series 54466/85102 parts=7148 live=2
- `22:37:48`   t+3424s series 54466/85102 parts=7148 live=2
- `22:38:34`   t+3470s series 54526/85102 parts=7148 live=2
- `22:39:19`   t+3515s series 54586/85102 parts=7148 live=2
- `22:40:05`   t+3561s series 54646/85102 parts=7148 live=2
- `22:40:50`   t+3606s series 54706/85102 parts=7148 live=2
- `22:41:36`   t+3652s series 54706/85102 parts=7148 live=2
- `22:42:22`   t+3698s series 54766/85102 parts=7148 live=2
- `22:43:08`   t+3744s series 54826/85102 parts=7148 live=2
- `22:43:53`   t+3789s series 54886/85102 parts=7148 live=2
- `22:44:39`   t+3835s series 54946/85102 parts=7148 live=2
- `22:45:25`   t+3880s series 54946/85102 parts=7148 live=2
- `22:46:10`   t+3926s series 55006/85102 parts=7148 live=2
- `22:46:56`   t+3972s series 55066/85102 parts=7148 live=2
- `22:47:41`   t+4017s series 55126/85102 parts=7148 live=2
- `22:48:27`   t+4063s series 55186/85102 parts=7148 live=2
- `22:49:13`   t+4108s series 55186/85102 parts=7148 live=2
- `22:49:13`     BP01 fail: HTTP 500 @2360 195501
- `22:49:13`     PR02 fail: HTTP 500 @520 196501
- `22:49:13`     PR03 fail: HTTP 500 @9240 196501
- `22:49:13`   remainder: ['BP01 11880/17989', 'FF 10080/33887']
- `22:49:13` P1 PASS dbs=22 series=55186/85102 parts=7148
## G2 substance (early depth + modern density)

- `22:49:13`   early - series=0 | modern - series=0
- `22:49:13` G2 FAIL
## G3 card

- `22:59:15` G3 note=FULL flat-file warehouse (boj-full v1): 16/16 database zips · 19MB · the entire time-series portal · API universe: 22 dbs · 55306/120394 series · 7148 parts
- `22:59:15` ops 4987 RED: REMAINDER(2 dbs); G2
