# ops 5086 -- justhodl-fortress v2.0.0 deploy + daily + weekly backtest, verified

**Status:** success  
**Duration:** 339.2s  
**Finished:** 2026-09-01T04:03:47+00:00  

## Data

| as_of | base_rates | board | coverage_pct | donor | elapsed_s | etf_tiers | first | g1 | g2 | g3 | g4 | g5 | g6 | g7 | g8 | g8_as_of | g9 | keys | last | last_update | ledger | memory | n_observations | n_rows_sampled | n_scored | n_test_dates | n_universe_bars | note | picks | runtime | schedule | schedule_expr | schedule_state | session | sessions | sessions_loaded | snapshot | state | tiers | timeout | top_picks | v2_coverage_pct_board | validation_n | validation_status |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|  |  |  |  | justhodl-equity-research |  |  |  | PASS |  |  |  |  |  |  |  |  |  | ['FMP_KEY', 'FORTRESS_VERSION', 'POLYGON_API_KEY'] |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  | PASS |  |  |  |  |  |  |  |  |  |  | Successful |  | 8192 |  |  |  |  |  |  |  | python3.12 |  |  |  |  |  |  |  | Active |  | 900 |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  | PASS |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | updated |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | cron(30 3 ? * TUE-SAT *) | ENABLED |  |  |  |  |  |  |  |  |  |  |  |
| 2026-09-01T03:59:52+00:00 |  |  |  |  | 94.3 | {'ETF_FORTRESS': 0, 'ETF_COILED': 19, 'ETF_WATCH': 425, 'SCREENED': 1836} |  |  |  |  | PASS |  |  |  |  |  |  |  |  |  |  |  |  |  | 5181 |  | 11614 |  |  |  |  |  |  | 2026-08-31 |  | 760 |  |  | {'COILED': 39, 'ACCUMULATING': 334, 'WATCH': 1212, 'SCREENED': 3596} |  |  |  |  |  |
|  |  |  | {'dump_capture': 100.0, 'bb_width_pctile': 99.5, 'valuation_score': 90.0, 'flow_score': 100.0, 'vs_ema250_pct': 93.4, 'growth_score': 99.8, 'safety_score': 100.0} |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 3300 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | {'obv_slope_63': 100.0, 'absorption_clv': 100.0, 'conviction': 100.0, 'confidence': 100.0, 'trade_plan': 100.0, 'higher_lows': 100.0, 'cvar5_pct': 100.0, 'capture_days_weighted': 100.0, 'worst_days_tstat': 100.0, 'rate_beta': 100.0, 'etf_pressure_21d_usd': 29.4, 'dark_pool_state': 26.4, 'pillar_ranks': 100.0} |  |  |
|  |  | 800 |  |  |  |  |  |  |  |  |  | PASS |  |  |  |  |  |  |  |  | 2500 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 39 |  |  |  |
|  | accruing |  |  |  |  |  |  |  |  |  |  |  | PASS |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 373 |  |  |  |  |  |  |  | data/fortress/history/2026-08-31.json.gz |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  | PASS |  |  |  |  |  |  |  |  |  |  |  |  |  | justhodl-signal-harvester reads data/fortress.json top_picks as eng:fortress at 23:15 UTC |  |  |  |  |  |  |  |  |  |  |  |  | 39 |  |  |  |
|  |  |  |  |  | 120.4 |  | 2022-06-24 |  |  |  |  |  |  |  |  | 2026-09-01T04:02:00+00:00 |  |  | 2026-08-31 |  |  |  | 57764 |  |  | 16 |  |  |  |  |  |  |  |  | 1050 |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | PASS |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  | 95.1 |  |  |  |  |  |  |  |  |  |  |  | PASS |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 57764 | measured |

## Log
## G1 key inheritance

## G2 deploy

- `03:58:08`   zip: 143961 bytes
## 1. Lambda

- `03:58:08`   Lambda exists — updating
- `03:58:12` ✅   ✓ updated justhodl-fortress
## G3 schedule (EventBridge Scheduler -- classic rule cap is saturated)

## G4 first run (async, verified on disk)

- `03:58:17` async invoke fired at 2026-09-01T03:58:08+00:00; polling data/fortress.json (prev as_of=2026-09-01T00:44:52+00:00)
- `03:59:24`   poll 60s: not fresh yet
- `03:59:58`   engine:   39.7s bars 576/760 sessions, 9995 tickers
- `03:59:58`   engine:   41.6s bars 600/760 sessions, 10158 tickers
- `03:59:58`   engine:   43.4s bars 624/760 sessions, 10336 tickers
- `03:59:58`   engine:   45.3s bars 648/760 sessions, 10494 tickers
- `03:59:58`   engine:   47.2s bars 672/760 sessions, 10667 tickers
- `03:59:58`   engine:   49.2s bars 696/760 sessions, 10902 tickers
- `03:59:58`   engine:   51.1s bars 720/760 sessions, 11226 tickers
- `03:59:58`   engine:   53.2s bars 744/760 sessions, 11457 tickers
- `03:59:58`   engine:   54.5s bars 760/760 sessions, 11614 tickers
- `03:59:58`   engine:   54.5s market: 8 dump episodes (4 big), 12 worst days, SPY vs EMA250 9.27%
- `03:59:58`   engine:   82.1s stock rows built: 5181 (finviz-matched 5287)
- `03:59:58`   engine:   93.7s etf rows built: 2280
## G5 real-data assertions (from S3, independent of the engine's own view)

- `03:59:58` regime: {"meta_regime": "LATE_CYCLE", "meta_class": "late-cycle", "composite_score": 54.7, "as_of": "2026-07-31T17:51:42.374086+00:00", "vol_regime": "NORMAL", "vol_score": 22.5, "vol_as_of": "2026-07-31T17:51:50+00:00", "spy_vs_ema250_pct": 9.27, "spy_dd_from_high_pct": -1.39, "n_dump_episodes_3y": 8, "n_dump_episodes_1y": 3, "n_big_dumps_3y": 4, "y10_pct": 4.67, "read": "3 dump episode(s) in the trailing year, 8 in the three-year window (4 of 8%+)"}
- `03:59:58` changes: {"status": "ok", "prev_session": "2026-08-28", "new_fortress": [], "upgrades": [{"ticker": "JBS", "from": "ACCUMULATING", "to": "COILED"}, {"ticker": "GEHC", "from": "ACCUMULATING", "to": "COILED"}, {"ticker": "ADMA", "from": "ACCUMULATING", "to": "COILED"}, {"ticker": "SPH", "from": "ACCUMULATING", "to": "COILED"}, {"ticker": "SNN", "from": "ACCUMULATING", "to": "COILED"}, {"ticker": "CC", "from": "ACCUMULATING", "to": "COILED"}, {"ticker": "RPAY", "from": "ACCUMULATING", "to": "COILED"}], "downgrades": [{"ticker": "INVA", "from": "FORTRESS_COIL", "to": "COILED"}, {"ticker": "PHAT", "from": "COILED", "to": "ACCUMULATING"}, {"ticker": "BFAM", "from": "COILED", "to": "ACCUMULATING"}, {"ticker": "STZ", "from": "COILED", "to": "ACCUMULATING"}, {"ticker": "ZKH", "from": "COILED", "to": "ACCUMULATING"}, {"ticker": "DFIN", "from": "COILED", "to": "ACCUMULATING"}, {"ticker": "EVAX", "from": "COILED", "to": "ACCUMULATING"}, {"ticker": "NICE", "from": "COILED", "to": "ACCUMULATING"}], "new_entries": [{"ticker": "PPG", "tier": "COILED"}, {"ticker": "ALB", "tier": "COILED"}, {"ticker": "AA", "tier": "COILED"}, {"ticker": "DGX", "tier": "ACCUMULATING"}, {"ticker": "SR", "tier": "ACCUMULATING"}, {"ticker": "SD", "tier": "ACCUMULATING"}, {"ticker": "INSP", "tier": "ACCUMULATING"}, {"ticker": "INFU", "tier": "ACCUMULATING"}], "exits": [{"ticker": "INVH", "was": "COILED"}, {"ticker": "RBBN", "was": "COILED"}, {"ticker": "PINE", "was": "ACCUMULATING"}, {"ticker": "JAZZ", "was": "ACCUMULATING"}, {"ticker": "BVS", "was": "ACCUMULATING"}, {"ticker": "GRNT", "was": "ACCUMULATING"}, {"ticker": "CNX", "was": "ACCUMULATING"}, {"ticker": "BF.B", "was": "ACCUMULATING"}], "n_prev": 400, "n_now": 373}
- `03:59:58` sizing: {"INVA": 9.6, "JBS": 4.8, "SNDX": 3.8, "UNCY": 2.0, "NPB": 7.1, "BRO": 4.5, "FCN": 5.4, "DXC": 2.6, "ATEC": 2.0, "GIB": 3.2, "RARE": 2.4, "SRAD": 2.5, "WM": 7.3, "NOC": 5.4, "CE": 3.3, "RGR": 4.0, "GEHC": 3.4, "YALA": 4.1, "ADMA": 2.4, "SPH": 6.8, "SNN": 4.7, "ALLT": 1.7, "PPG": 3.5, "UPBD": 1.9, "GRAB": 1.5}
- `03:59:58` market window: 2023-08-21..2026-08-31 (760 sessions) episodes3y=8 recent=3 big=4
- `03:59:58` v2 COILED INVA conv=74.9 conf=0.98 comp=74.8 abs=71.1 accum=46.9 struct=41.6 obv=0.0939 clv=0.3025 dcap=-0.1667 t=4.2646 dp=None hl=0 vcp=[6.1, 5.9, 7.7] rs=False cvar=-3.1931 plan={'pivot': 23.64, 'pivot_dist_pct': 13.8, 'stop': 20.3, 'risk_pct': 2.2, 'target': 23.74, 'reward_pct': 14.3, 'target_2': 35.0, 'reward_to_risk': 6.39, 'note': 'enter on the pivot break with volume or scale inside the coil; stop under the range low / 2.5 ATR'} trig=dump capture -1.00 (worst 2.07) -- needs the next SPY dump held (capture <= 0.35, never worse than the market)
- `03:59:58` v2 COILED JBS conv=65.6 conf=0.91 comp=69.2 abs=67.6 accum=66.5 struct=44.5 obv=0.1135 clv=0.5978 dcap=-0.0092 t=2.8476 dp=ACCUMULATION hl=1 vcp=[25.2, 4.9, 4.3, 8.5] rs=False cvar=-4.5404 plan={'pivot': 14.29, 'pivot_dist_pct': 6.3, 'stop': 12.37, 'risk_pct': 8.0, 'target': 17.07, 'reward_pct': 27.0, 'target_2': 18.43, 'reward_to_risk': 3.38, 'note': 'enter on the pivot break with volume or scale inside the coil; stop under the range low / 2.5 ATR'} trig=XLP flow score 42.0 -- needs >= 55 with a positive leg
- `03:59:58` v2 COILED SNDX conv=68.0 conf=0.98 comp=68.4 abs=63.0 accum=50.4 struct=70.6 obv=-0.033 clv=0.3336 dcap=0.5887 t=1.1116 dp=None hl=2 vcp=[10.8, 9.9, 23.3, 6.5] rs=False cvar=-5.7958 plan={'pivot': 24.84, 'pivot_dist_pct': 28.8, 'stop': 16.97, 'risk_pct': 12.0, 'target': 23.78, 'reward_pct': 23.3, 'target_2': 37.55, 'reward_to_risk': 1.94, 'note': 'enter on the pivot break with volume or scale inside the coil; stop under the range low / 2.5 ATR'} trig=dump capture 0.49 (worst 5.11) -- needs the next SPY dump held (capture <= 0.35, never worse than the market)
- `03:59:58` v2 COILED UNCY conv=71.7 conf=0.98 comp=66.5 abs=62.5 accum=42.5 struct=49.3 obv=-0.1826 clv=0.3697 dcap=0.8441 t=0.5154 dp=None hl=1 vcp=[7.1, 18.0, 42.9, 16.7] rs=False cvar=-11.036 plan={'pivot': 8.21, 'pivot_dist_pct': 57.9, 'stop': 4.64, 'risk_pct': 10.7, 'target': 7.24, 'reward_pct': 39.3, 'target_2': 29.6, 'reward_to_risk': 3.67, 'note': 'enter on the pivot break with volume or scale inside the coil; stop under the range low / 2.5 ATR'} trig=dump capture 0.88 (worst 4.99) -- needs the next SPY dump held (capture <= 0.35, never worse than the market)
- `03:59:58` v2 COILED NPB conv=59.7 conf=0.98 comp=65.2 abs=62.7 accum=52.5 struct=57.8 obv=0.0588 clv=0.4909 dcap=0.4857 t=2.0755 dp=None hl=1 vcp=[2.9, 6.1, 11.8, 2.9] rs=False cvar=-4.4238 plan={'pivot': 19.31, 'pivot_dist_pct': 13.7, 'stop': 16.72, 'risk_pct': 1.6, 'target': 19.03, 'reward_pct': 12.0, 'target_2': 20.38, 'reward_to_risk': 7.59, 'note': 'enter on the pivot break with volume or scale inside the coil; stop under the range low / 2.5 ATR'} trig=KRE flow score 19.0 -- needs >= 55 with a positive leg
- `03:59:58` v2 COILED BRO conv=44.2 conf=0.98 comp=65.0 abs=61.4 accum=57.2 struct=57.4 obv=0.0535 clv=0.4607 dcap=0.0588 t=4.7962 dp=NEUTRAL hl=4 vcp=[6.0, 3.2, 5.8, 8.0] rs=False cvar=-4.7914 plan={'pivot': 74.87, 'pivot_dist_pct': 3.7, 'stop': 67.14, 'risk_pct': 7.0, 'target': 76.69, 'reward_pct': 6.3, 'target_2': 90.62, 'reward_to_risk': 0.9, 'note': 'enter on the pivot break with volume or scale inside the coil; stop under the range low / 2.5 ATR'} trig=KIE flow score 0.0 -- needs >= 55 with a positive leg
- `03:59:58` probe MSFT: tier=SCREENED comp=54.5 capture=1.705 worst_bps=27.012 vsEMA250=16.087 bbw_pct=39.286 val=39.937 growth=71.54 flows=58.813 etf=IGV
- `03:59:58` board COILED INVA comp=74.8 asym=12.35 cap=-0.9985 ema=-2.1331 bbw=5.9524 val=100.0 g=55.6957 fl=69.375 bk=None ct=None flags=['MAJOR_INFLOWS', 'TIGHT_COIL', 'BIG_DUMP_PROOF', 'OBV_DIVERGENCE']
- `03:59:58`       - ROSE while SPY dumped: capture -1.00 across 8 drawdown episode(s), flat-or-up in 50% of them
- `03:59:58`       - but fell MORE than the market in its worst episode (2024-12-06..2025-01-10 SPY -4.5% stock -9.3%)
- `03:59:58`       - on SPY's 12 worst days: +169 bps vs SPY, green 42% of the time
- `03:59:58`       - 2.1% below the 250-day EMA
- `03:59:58`       - Bollinger bandwidth in the 6th percentile of its own year -- TTM squeeze ON for 13 sessions
- `03:59:58` board COILED JBS comp=69.2 asym=4.71 cap=-0.7229 ema=-4.514 bbw=17.4603 val=59.0658 g=60.35 fl=42.4062 bk=None ct=None flags=['MAJOR_GROWTH', 'BIG_DUMP_PROOF', 'DARK_POOL_ACCUM']
- `03:59:58`       - ROSE while SPY dumped: capture -0.72 across 3 drawdown episode(s), flat-or-up in 67% of them
- `03:59:58`       - on SPY's 12 worst days: +245 bps vs SPY, green 58% of the time
- `03:59:58`       - 4.5% below the 250-day EMA
- `03:59:58`       - Bollinger bandwidth in the 17th percentile of its own year -- TTM squeeze ON for 2 sessions
- `03:59:58`       - valuation cheaper than 59% of its industry peers (PEG 14.59)
- `03:59:58` board COILED SNDX comp=68.4 asym=6.78 cap=0.4922 ema=-1.2371 bbw=1.9841 val=66.835 g=78.4197 fl=69.375 bk=None ct=None flags=['MAJOR_GROWTH', 'MAJOR_INFLOWS', 'TIGHT_COIL', 'VCP']
- `03:59:58`       - captured only 49% of the SPY dumps (size-weighted) across 8 episode(s), flat-or-up in 25% of them
- `03:59:58`       - but fell MORE than the market in its worst episode (2024-12-06..2025-01-10 SPY -4.5% stock -22.9%)
- `03:59:58`       - on SPY's 12 worst days: +67 bps vs SPY, green 25% of the time
- `03:59:58`       - 1.2% below the 250-day EMA
- `03:59:58`       - Bollinger bandwidth in the 2th percentile of its own year -- TTM squeeze ON for 8 sessions
- `03:59:58` board COILED UNCY comp=66.5 asym=15.36 cap=0.8751 ema=-15.4316 bbw=12.3016 val=99.697 g=85.2238 fl=69.375 bk=None ct=None flags=['MAJOR_INFLOWS', 'OBV_DIVERGENCE']
- `03:59:58`       - captured only 88% of the SPY dumps (size-weighted) across 8 episode(s), flat-or-up in 25% of them
- `03:59:58`       - but fell MORE than the market in its worst episode (2024-03-27..2024-04-19 SPY -5.3% stock -26.7%)
- `03:59:58`       - on SPY's 12 worst days: +64 bps vs SPY, green 25% of the time
- `03:59:58`       - 15.4% below the 250-day EMA
- `03:59:58`       - Bollinger bandwidth in the 12th percentile of its own year -- TTM squeeze ON for 2 sessions
- `03:59:58` board COILED NPB comp=65.2 asym=3.44 cap=0.2756 ema=-0.2287 bbw=3.5714 val=100.0 g=55.0002 fl=18.6875 bk=None ct=None flags=['TIGHT_COIL', 'OBV_DIVERGENCE', 'VCP']
- `03:59:58`       - captured only 28% of the SPY dumps (size-weighted) across 4 episode(s), flat-or-up in 25% of them
- `03:59:58`       - on SPY's 12 worst days: +113 bps vs SPY, green 42% of the time
- `03:59:58`       - 0.2% below the 250-day EMA
- `03:59:58`       - Bollinger bandwidth in the 4th percentile of its own year -- TTM squeeze ON for 10 sessions
- `03:59:58`       - valuation cheaper than 100% of its industry peers
- `03:59:58` board COILED BRO comp=65.0 asym=2.21 cap=0.2712 ema=-2.768 bbw=29.3651 val=62.9848 g=63.4934 fl=0.0 bk=None ct=None flags=['MAJOR_GROWTH', 'HIGHER_LOWS']
- `03:59:58`       - captured only 27% of the SPY dumps (size-weighted) across 8 episode(s), flat-or-up in 38% of them
- `03:59:58`       - but fell MORE than the market in its worst episode (2024-12-06..2025-01-10 SPY -4.5% stock -6.6%)
- `03:59:58`       - on SPY's 12 worst days: +252 bps vs SPY, green 67% of the time
- `03:59:58`       - 2.8% below the 250-day EMA
- `03:59:58`       - Bollinger bandwidth in the 29th percentile of its own year -- TTM squeeze ON for 4 sessions
- `03:59:58` board COILED FCN comp=64.5 asym=2.95 cap=0.3609 ema=-8.3337 bbw=8.3333 val=72.5476 g=47.1594 fl=47.2812 bk=None ct=None flags=['TIGHT_COIL']
- `03:59:58`       - captured only 36% of the SPY dumps (size-weighted) across 8 episode(s), flat-or-up in 38% of them
- `03:59:58`       - but fell MORE than the market in its worst episode (2025-02-19..2025-04-08 SPY -19.0% stock -19.6%)
- `03:59:58`       - on SPY's 12 worst days: +266 bps vs SPY, green 50% of the time
- `03:59:58`       - 8.3% below the 250-day EMA
- `03:59:58`       - Bollinger bandwidth in the 8th percentile of its own year -- TTM squeeze ON for 4 sessions
- `03:59:58` board COILED DXC comp=63.9 asym=2.15 cap=1.7778 ema=-7.1773 bbw=9.5238 val=87.1218 g=42.4259 fl=58.8125 bk=None ct=None flags=['TIGHT_COIL', 'VCP', 'HIGHER_LOWS']
- `03:59:58`       - captured only 178% of the SPY dumps (size-weighted) across 8 episode(s), flat-or-up in 0% of them
- `03:59:58`       - but fell MORE than the market in its worst episode (2024-12-06..2025-01-10 SPY -4.5% stock -12.3%)
- `03:59:58`       - on SPY's 12 worst days: +56 bps vs SPY, green 25% of the time
- `03:59:58`       - 7.2% below the 250-day EMA
- `03:59:58`       - Bollinger bandwidth in the 10th percentile of its own year -- TTM squeeze ON for 4 sessions
- `03:59:58` episodes: [{"peak_date": "2023-09-01", "trough_date": "2023-10-27", "spy_dd_pct": -8.98, "closed": true}, {"peak_date": "2024-03-27", "trough_date": "2024-04-19", "spy_dd_pct": -5.35, "closed": true}, {"peak_date": "2024-07-16", "trough_date": "2024-08-05", "spy_dd_pct": -8.41, "closed": true}, {"peak_date": "2024-12-06", "trough_date": "2025-01-10", "spy_dd_pct": -4.49, "closed": true}, {"peak_date": "2025-02-19", "trough_date": "2025-04-08", "spy_dd_pct": -19.0, "closed": true}, {"peak_date": "2025-10-29", "trough_date": "2025-11-20", "spy_dd_pct": -5.07, "closed": true}, {"peak_date": "2026-01-27", "trough_date": "2026-03-30", "spy_dd_pct": -9.13, "closed": true}, {"peak_date": "2026-06-02", "trough_date": "2026-06-10", "spy_dd_pct": -4.49, "closed": true}]
- `03:59:58` industries top: [{"etf": "IGV", "n_stocks": 464, "tiers": {"COILED": 12, "ACCUMULATING": 83, "WATCH": 112, "SCREENED": 257}, "flow_score": 58.8, "inflow_major": false}, {"etf": "XBI", "n_stocks": 578, "tiers": {"COILED": 6, "ACCUMULATING": 39, "WATCH": 121, "SCREENED": 412}, "flow_score": 69.4, "inflow_major": true}, {"etf": "XLB", "n_stocks": 100, "tiers": {"COILED": 4, "ACCUMULATING": 19, "WATCH": 28, "SCREENED": 49}, "flow_score": 61.0, "inflow_major": false}, {"etf": "XLK", "n_stocks": 188, "tiers": {"COILED": 4, "ACCUMULATING": 18, "WATCH": 67, "SCREENED": 99}, "flow_score": 55.9, "inflow_major": true}, {"etf": "IHI", "n_stocks": 194, "tiers": {"COILED": 3, "ACCUMULATING": 17, "WATCH": 62, "SCREENED": 112}, "flow_score": 77.0, "inflow_major": true}, {"etf": "XLRE", "n_stocks": 248, "tiers": {"ACCUMULATING": 17, "WATCH": 49, "SCREENED": 182}, "flow_score": 45.2, "inflow_major": false}, {"etf": "XLU", "n_stocks": 86, "tiers": {"COILED": 1, "ACCUMULATING": 14, "WATCH": 36, "SCREENED": 35}, "flow_score": 52.3, "inflow_major": false}, {"etf": "ITA", "n_stocks": 87, "tiers": {"COILED": 2, "ACCUMULATING": 10, "WATCH": 33, "SCREENED": 42}, "flow_score": 61.3, "inflow_major": true}]
- `03:59:58` etfs top: [{"ticker": "CSRE", "tier": "ETF_COILED", "composite": 69.0, "dump_capture": 0.0976, "flow_score": 100.0}, {"ticker": "LPRE", "tier": "ETF_COILED", "composite": 63.0, "dump_capture": 0.1188, "flow_score": 100.0}, {"ticker": "INDA", "tier": "ETF_COILED", "composite": 62.6, "dump_capture": 0.5486, "flow_score": 78.0253}, {"ticker": "RSPU", "tier": "ETF_COILED", "composite": 62.3, "dump_capture": 0.0328, "flow_score": 63.0}, {"ticker": "FUTY", "tier": "ETF_COILED", "composite": 62.3, "dump_capture": 0.1087, "flow_score": 67.125}, {"ticker": "FLCH", "tier": "ETF_COILED", "composite": 59.7, "dump_capture": 1.0504, "flow_score": 100.0}, {"ticker": "SPYT", "tier": "ETF_COILED", "composite": 58.8, "dump_capture": 1.1456, "flow_score": 91.75}, {"ticker": "FLIN", "tier": "ETF_COILED", "composite": 56.7, "dump_capture": 0.5692, "flow_score": 55.125}]
- `03:59:58` inputs: {"bars": "data/warm/polygon-full/grouped/ (2023-08-21..2026-08-31, 760 sessions)", "finviz_universe": "2026-08-31T22:00:37.715951+00:00", "fundamental_census_matrix": "2026-09-01T03:37:49.299276+00:00", "industry_boom": "2026-08-31T10:50:03.806562+00:00", "industry_rotation": "2026-08-31T21:38:24.333669+00:00", "etf_flows_polygon": "2026-08-31T22:00:25.581028+00:00", "etf_true_flows": "2026-08-31T15:45:23.111432+00:00", "backlog": "2026-08-31T11:30:46.752693+00:00", "backlog_mined": "2026-09-01T02:30:11+00:00", "deal_history": "2026-09-01T03:05:24.131721+00:00", "catalyst": "2026-09-01T02:29:32+00:00", "floor_audit": "2026-08-31T21:37:21+00:00", "resilience": "2026-08-31T22:46:01.117625+00:00", "f13_flows": "2026-09-01T03:06:33.320101+00:00", "short_interest": "2026-08-31T21:15:38.904686+00:00", "insider_radar": "2026-08-31T14:40:32.785479+00:00", "estimate_revisions": "2026-08-31T17:40:22.896922+00:00", "sp500": "2026-08-31T21:45:45.403867+00:00", "stock_exposure": "etf-flows/stock-exposure-lookup.json (2328 names)", "dark_pool": "2026-08-31T21:41:16.023658+00:00 (week 2026-08-10, 936 names)", "political_trades": "2026-08-31T13:45:28.717233+00:00", "options_analytics": "2026-08-31T21:30:51.401089+00:00", "regime_composite": "2026-07-31T17:51:42.374086+00:00", "vol_regime": "2026-07-31T17:51:50+00:00", "yield_curve": "2026-08-31T13:53:02.310441+00:00", "backtest": null}
- `03:59:58` capture distribution over 3299 sampled rows: p10 -0.33 p25 0.27 p50 0.96 p75 1.93 p90 3.12; <=0.35: 929; <0: 554
- `03:59:58` worst-day excess bps: p10 -225 p50 44 p90 203; >=25: 1762
- `03:59:58` bb width pctile: p10 4 p50 36; <=20: 1121; squeeze on: 1134
- `03:59:58` worst days: [{"date": "2025-10-10", "spy_ret_pct": -2.7}, {"date": "2026-06-05", "spy_ret_pct": -2.58}, {"date": "2026-01-20", "spy_ret_pct": -2.04}, {"date": "2026-03-26", "spy_ret_pct": -1.79}, {"date": "2026-03-27", "spy_ret_pct": -1.71}, {"date": "2026-03-20", "spy_ret_pct": -1.7}, {"date": "2025-11-13", "spy_ret_pct": -1.66}, {"date": "2026-06-10", "spy_ret_pct": -1.58}, {"date": "2026-02-12", "spy_ret_pct": -1.54}, {"date": "2026-07-29", "spy_ret_pct": -1.54}, {"date": "2025-11-20", "spy_ret_pct": -1.52}, {"date": "2026-03-12", "spy_ret_pct": -1.52}]
- `03:59:58` breadth: {"pct_under_ema250": 50.2, "pct_coiled": 33.4, "pct_dump_resilient": 5.4}
- `03:59:58` etf ETF_COILED CSRE comp=69.0 cap=0.0976 worst=109.0086 ema=3.413 bbw=11.1111 flow=100.0 vol100=13.8587 aum=573516000.0 type=US Equities | Cohen & Steers Real Estate Active ETF
- `03:59:58` etf ETF_COILED LPRE comp=63.0 cap=0.1188 worst=93.9834 ema=4.634 bbw=17.4603 flow=100.0 vol100=15.8464 aum=181029600.0 type=US Equities | Long Pond Real Estate Select ETF
- `03:59:58` etf ETF_COILED INDA comp=62.6 cap=0.5486 worst=73.3856 ema=-1.6156 bbw=4.7619 flow=78.0253 vol100=14.5395 aum=6724626384.0 type=Global Ex. US Equities | iShares MSCI India ETF
- `03:59:58` etf ETF_COILED RSPU comp=62.3 cap=0.0328 worst=154.671 ema=-3.7694 bbw=44.8413 flow=63.0 vol100=15.898 aum=524186376.0 type=US Equities | Invesco S&P 500 Equal Weight Utilities E
- `03:59:58` etf ETF_COILED FUTY comp=62.3 cap=0.1087 worst=134.1388 ema=-3.9167 bbw=42.4603 flow=67.125 vol100=16.0493 aum=2275526059.0 type=US Equities | Fidelity MSCI Utilities Index ETF
- `03:59:58` etf ETF_COILED FLCH comp=59.7 cap=1.0504 worst=27.9649 ema=-3.5465 bbw=7.9365 flow=100.0 vol100=18.1033 aum=336952000.0 type=Global Ex. US Equities | Franklin FTSE China ETF
- `03:59:58` etf ETF_COILED SPYT comp=58.8 cap=1.1456 worst=11.3733 ema=-0.6362 bbw=0.3968 flow=91.75 vol100=11.9874 aum=162116797.0 type=US Equity Income | Defiance S&P 500 Target Income ETF
- `03:59:58` etf ETF_COILED FLIN comp=56.7 cap=0.5692 worst=76.1353 ema=-1.4527 bbw=1.1905 flow=55.125 vol100=14.411 aum=2677995000.0 type=Global Ex. US Equities | Franklin FTSE India ETF
- `03:59:58` etf ETF_COILED ITB comp=55.7 cap=1.1431 worst=5.4633 ema=-4.1281 bbw=0.7937 flow=84.625 vol100=31.5771 aum=2404076910.0 type=US Equities | iShares U.S. Home Construction ETF
- `03:59:58` etf ETF_COILED ZAP comp=54.5 cap=0.3243 worst=66.1627 ema=-0.8696 bbw=76.5873 flow=75.625 vol100=17.8113 aum=455616972.0 type=US Equities | Global X U.S. Electrification ETF
- `03:59:58` etf ETF_COILED HAUZ comp=54.1 cap=0.7327 worst=63.4058 ema=-2.3982 bbw=3.9683 flow=63.5 vol100=13.7006 aum=1067634382.0 type=Global Ex. US Equities | Xtrackers International Real Estate ETF
- `03:59:58` etf ETF_COILED IDRV comp=53.4 cap=1.5014 worst=-59.4776 ema=-2.5438 bbw=0.3968 flow=100.0 vol100=29.1752 aum=152053666.0 type=Global Equities | iShares Self-Driving EV and Tech ETF
- `03:59:58` etf ETF_COILED MCHI comp=51.4 cap=1.124 worst=17.7982 ema=-3.1638 bbw=3.1746 flow=69.8872 vol100=18.6335 aum=6361740288.0 type=Global Ex. US Equities | iShares MSCI China ETF
- `03:59:58` etf ETF_COILED VNQI comp=50.8 cap=0.754 worst=63.1294 ema=-2.6401 bbw=17.8571 flow=55.0 vol100=13.6107 aum=3495636062.0 type=Global Ex. US Equities | Vanguard Global ex-U.S. Real Estate ETF
- `03:59:58` row COILED INVA small Biotechnology cap=-0.9985 worst_cap=2.07 n_ep=8 worst=168.638 green=0.4167 dc=-8.1633 bbw=5.9524 sq=13 vol100=24.4264 adv=13566302.1105 px=20.77 eps=[(-3.9, 0.43), (-2.22, 0.42), (6.76, -0.8), (-9.29, 2.07), (-4.33, 0.23), (20.43, -4.03), (16.18, -1.77), (7.73, -1.72)] risks=[]
- `03:59:58` row COILED JBS large Packaged Foods cap=-0.7229 worst_cap=0.31 n_ep=3 worst=244.5452 green=0.5833 dc=46.4533 bbw=17.4603 sq=2 vol100=37.4682 adv=78062820.6867 px=13.44 eps=[(4.69, -0.92), (11.15, -1.22), (-1.39, 0.31)] risks=[]
- `03:59:58` row COILED SNDX small Biotechnology cap=0.4922 worst_cap=5.11 n_ep=8 worst=66.9388 green=0.25 dc=35.1069 bbw=1.9841 sq=8 vol100=47.2701 adv=25250209.6365 px=19.29 eps=[(-37.14, 4.14), (-9.84, 1.84), (-20.76, 2.47), (-22.93, 5.11), (-28.41, 1.5), (28.97, -5.71), (5.49, -0.6), (-4.4, 0.98)] risks=['short float 28% -- crowded short, violent both ways']
- `03:59:58` row COILED UNCY micro Biotechnology cap=0.8751 worst_cap=4.99 n_ep=8 worst=63.8505 green=0.25 dc=55.7188 bbw=12.3016 sq=2 vol100=106.5155 adv=3837203.4154 px=5.2 eps=[(-23.84, 2.65), (-26.71, 4.99), (-15.7, 1.87), (-8.77, 1.95), (-21.06, 1.11), (9.79, -1.93), (-15.14, 1.66), (6.36, -1.42)] risks=['CVaR(5%) -11.0%: the worst twentieth of days average that loss', 'thin liquidity: $3.8M average daily dollar volume']
- `03:59:58` row COILED NPB small Banks - Regional cap=0.2756 worst_cap=0.61 n_ep=4 worst=113.2885 green=0.4167 dc=82.1665 bbw=3.5714 sq=10 vol100=29.855 adv=2798133.6949 px=16.99 eps=[(-11.62, 0.61), (-0.13, 0.02), (-5.14, 0.56), (2.97, -0.66)] risks=['thin liquidity: $2.8M average daily dollar volume']
- `03:59:58` row COILED BRO large Insurance Brokers cap=0.2712 worst_cap=1.47 n_ep=8 worst=251.8388 green=0.6667 dc=-37.7571 bbw=29.3651 sq=4 vol100=34.7526 adv=120896608.3246 px=72.17 eps=[(-8.85, 0.99), (-5.83, 1.09), (5.43, -0.65), (-6.62, 1.47), (0.09, -0.0), (-0.85, 0.17), (-11.95, 1.31), (6.34, -1.41)] risks=['share count +16% y/y -- dilution', 'Altman Z 1.59 -- distress zone']
- `03:59:58` row COILED FCN mid Consulting Services cap=0.3609 worst_cap=1.03 n_ep=8 worst=265.8175 green=0.5 dc=2.4641 bbw=8.3333 sq=4 vol100=32.3446 adv=59169019.8991 px=150.57 eps=[(17.8, -1.98), (0.87, -0.16), (-5.47, 0.65), (-2.64, 0.59), (-19.61, 1.03), (-4.01, 0.79), (-4.99, 0.55), (4.0, -0.89)] risks=[]
- `03:59:58` row COILED DXC small Information Technology cap=1.7778 worst_cap=2.73 n_ep=8 worst=55.6471 green=0.25 dc=59.2315 bbw=9.5238 sq=4 vol100=69.6804 adv=29394970.6297 px=11.3 eps=[(-7.39, 0.82), (-4.37, 0.82), (-6.5, 0.77), (-12.26, 2.73), (-30.54, 1.61), (-7.44, 1.47), (-18.54, 2.03), (-11.8, 2.63)] risks=['CVaR(5%) -8.7%: the worst twentieth of days average that loss']
- `03:59:58` row COILED ATEC small Medical Devices cap=0.9172 worst_cap=5.33 n_ep=8 worst=22.4663 green=0.25 dc=114.3862 bbw=5.5556 sq=1 vol100=87.0618 adv=18643278.385 px=9.37 eps=[(-41.23, 4.59), (-9.13, 1.71), (-44.82, 5.33), (3.58, -0.8), (-13.17, 0.69), (18.92, -3.73), (-27.92, 3.06), (8.69, -1.94)] risks=['6 overnight gaps of 5%+ in the year (max 23%) -- event-driven tape', 'CVaR(5%) -10.9%: the worst twentieth of days average that loss', 'max drawdown -69% over the year']
- `03:59:58` row COILED GIB large Information Technology cap=1.0304 worst_cap=1.94 n_ep=8 worst=135.3417 green=0.3333 dc=58.9429 bbw=3.1746 sq=6 vol100=36.7879 adv=25836014.9174 px=75.25 eps=[(-9.97, 1.11), (-5.39, 1.01), (-0.95, 0.11), (-4.47, 1.0), (-18.61, 0.98), (0.09, -0.02), (-17.74, 1.94), (-3.59, 0.8)] risks=[]
- `03:59:58` row COILED RARE mid Biotechnology cap=1.3164 worst_cap=3.3 n_ep=8 worst=-0.3988 green=0.25 dc=154.2105 bbw=0.3968 sq=9 vol100=48.093 adv=51321265.0705 px=25.21 eps=[(-13.16, 1.46), (-9.5, 1.78), (8.42, -1.0), (-14.8, 3.3), (-29.87, 1.57), (-9.86, 1.94), (-21.61, 2.37), (5.46, -1.22)] risks=['6 overnight gaps of 5%+ in the year (max 43%) -- event-driven tape', 'CVaR(5%) -9.2%: the worst twentieth of days average that loss']
- `03:59:58` row COILED SRAD mid Software - Application cap=0.3274 worst_cap=3.8 n_ep=8 worst=52.3484 green=0.25 dc=108.9191 bbw=10.7143 sq=2 vol100=70.1342 adv=30663418.4441 px=12.43 eps=[(-23.98, 2.67), (-16.22, 3.03), (-10.02, 1.19), (7.47, -1.66), (-7.82, 0.41), (-19.24, 3.8), (-9.45, 1.03), (22.3, -4.97)] risks=['CVaR(5%) -8.9%: the worst twentieth of days average that loss', 'max drawdown -60% over the year']
- `03:59:58` row COILED WM large Waste Management cap=-0.1389 worst_cap=1.5 n_ep=8 worst=189.2408 green=0.6667 dc=-56.3924 bbw=13.0952 sq=5 vol100=22.118 adv=433360659.7549 px=218.92 eps=[(2.78, -0.31), (-3.22, 0.6), (-8.76, 1.04), (-6.72, 1.5), (-5.27, 0.28), (9.76, -1.92), (-0.6, 0.07), (5.83, -1.3)] risks=[]
- `03:59:58` row COILED NOC large Aerospace & Defense cap=-0.2327 worst_cap=0.7 n_ep=8 worst=125.5627 green=0.3333 dc=11.6478 bbw=54.3651 sq=0 vol100=28.9219 adv=352990405.5928 px=539.7 eps=[(8.6, -0.96), (-3.1, 0.58), (13.21, -1.57), (-3.16, 0.7), (13.5, -0.71), (-3.02, 0.59), (-1.05, 0.12), (1.03, -0.23)] risks=['net liquid assets negative (debt exceeds liquid assets)']
- `03:59:58` row COILED CE mid Chemicals cap=0.3079 worst_cap=2.26 n_ep=8 worst=97.0441 green=0.3333 dc=42.3073 bbw=1.1905 sq=20 vol100=47.6261 adv=74988701.2996 px=45.48 eps=[(-11.95, 1.33), (-8.95, 1.67), (-14.59, 1.73), (-7.84, 1.75), (-31.72, 1.67), (-11.44, 2.26), (37.11, -4.06), (-8.85, 1.97)] risks=['CVaR(5%) -6.6%: the worst twentieth of days average that loss']
- `03:59:58` row COILED RGR small Aerospace & Defense cap=0.6086 worst_cap=6.84 n_ep=8 worst=16.6768 green=0.0833 dc=72.361 bbw=15.873 sq=3 vol100=27.6936 adv=4551463.7611 px=37.97 eps=[(4.13, -0.46), (1.12, -0.21), (-8.01, 0.95), (-3.5, 0.78), (5.95, -0.31), (-34.7, 6.84), (5.43, -0.59), (0.13, -0.03)] risks=['thin liquidity: $4.6M average daily dollar volume']
- `03:59:58` row COILED GEHC large Medical Devices cap=0.9619 worst_cap=1.92 n_ep=8 worst=141.8943 green=0.25 dc=104.4896 bbw=12.3016 sq=0 vol100=41.4306 adv=189621278.3779 px=71.23 eps=[(-8.88, 0.99), (-6.44, 1.2), (-1.36, 0.16), (4.33, -0.96), (-36.5, 1.92), (-3.4, 0.67), (-14.38, 1.58), (2.86, -0.64)] risks=['Altman Z 1.67 -- distress zone']
- `03:59:58` row COILED YALA small Software - Application cap=0.8034 worst_cap=2.17 n_ep=8 worst=-23.1206 green=0.0833 dc=121.8455 bbw=13.4921 sq=25 vol100=31.0294 adv=1783026.1186 px=5.49 eps=[(2.71, -0.3), (-5.24, 0.98), (-17.97, 2.14), (-9.74, 2.17), (16.2, -0.85), (-5.47, 1.08), (-16.48, 1.81), (-4.6, 1.02)] risks=['thin liquidity: $1.8M average daily dollar volume']
- `03:59:58` row COILED ADMA mid Biotechnology cap=0.9707 worst_cap=4.91 n_ep=8 worst=65.9495 green=0.3333 dc=117.3068 bbw=14.2857 sq=0 vol100=47.6035 adv=21293721.8303 px=9.39 eps=[(-14.91, 1.66), (-6.97, 1.3), (-17.7, 2.1), (-6.36, 1.42), (11.14, -0.59), (5.34, -1.05), (-44.81, 4.91), (11.58, -2.58)] risks=['CVaR(5%) -9.2%: the worst twentieth of days average that loss', 'max drawdown -63% over the year']
- `03:59:58` row COILED SPH small Utilities - Regulated  cap=0.2534 worst_cap=1.33 n_ep=8 worst=166.6273 green=0.5 dc=-8.0927 bbw=12.6984 sq=1 vol100=25.7953 adv=3751921.6833 px=17.61 eps=[(16.68, -1.86), (-3.96, 0.74), (-11.15, 1.33), (-3.98, 0.89), (-13.0, 0.68), (2.19, -0.43), (-0.05, 0.01), (-0.78, 0.17)] risks=['thin liquidity: $3.8M average daily dollar volume']
- `03:59:58` row COILED SNN large Medical Devices cap=0.4896 worst_cap=2.17 n_ep=8 worst=85.7557 green=0.1667 dc=60.5356 bbw=19.8413 sq=0 vol100=29.3986 adv=42454177.8746 px=28.76 eps=[(-19.46, 2.17), (-9.49, 1.77), (6.17, -0.73), (-5.56, 1.24), (-2.54, 0.13), (-10.59, 2.09), (-7.31, 0.8), (5.25, -1.17)] risks=[]
- `03:59:58` row COILED ALLT small Software - Infrastruct cap=1.8798 worst_cap=4.44 n_ep=8 worst=-99.0753 green=0.0833 dc=245.0135 bbw=0.3968 sq=14 vol100=52.8042 adv=2068513.3677 px=7.72 eps=[(-24.6, 2.74), (-4.15, 0.78), (-10.03, 1.19), (57.14, -12.73), (-35.51, 1.87), (-10.89, 2.15), (-40.57, 4.44), (-13.69, 3.05)] risks=['CVaR(5%) -8.7%: the worst twentieth of days average that loss', 'thin liquidity: $2.1M average daily dollar volume']
- `03:59:58` row COILED PPG large Specialty Chemicals cap=0.9385 worst_cap=2.2 n_ep=8 worst=59.9617 green=0.3333 dc=105.0885 bbw=14.6825 sq=0 vol100=32.5149 adv=139640203.8473 px=112.17 eps=[(-14.99, 1.67), (-9.44, 1.76), (-10.39, 1.24), (-9.87, 2.2), (-21.52, 1.13), (-3.96, 0.78), (-5.86, 0.64), (-0.59, 0.13)] risks=[]
- `03:59:58` row COILED UPBD small Software - Application cap=1.7219 worst_cap=5.83 n_ep=8 worst=8.9549 green=0.3333 dc=193.104 bbw=7.5397 sq=4 vol100=42.0824 adv=15959737.5092 px=18.3 eps=[(-19.34, 2.15), (-11.8, 2.21), (-1.44, 0.17), (-14.05, 3.13), (-29.3, 1.54), (-29.55, 5.83), (-6.73, 0.74), (-2.85, 0.63)] risks=['CVaR(5%) -6.3%: the worst twentieth of days average that loss']
- `03:59:58` board tiers: {"COILED": 39, "ACCUMULATING": 334, "WATCH": 427}
## G6 history snapshot

## G7 harvester contract

## G8 weekly walk-forward backtest (schedule + first run verified on disk)

- `03:59:59` backtest schedule created
- `03:59:59` backtest invoke fired at 2026-09-01T03:59:59+00:00; polling data/fortress-backtest.json
- `04:01:01`   poll 60s: backtest not written yet
- `04:02:03` gates 0: {"n": 23184, "median_ex21_pct": -0.85, "mean_ex21_pct": 0.29, "hit21_pct": 46.2, "median_ex63_pct": -2.49, "mean_ex63_pct": 0.92, "hit63_pct": 44.6}
- `04:02:03` gates 1: {"n": 24442, "median_ex21_pct": -1.27, "mean_ex21_pct": -0.49, "hit21_pct": 44.1, "median_ex63_pct": -3.23, "mean_ex63_pct": -0.2, "hit63_pct": 42.5}
- `04:02:03` gates 2: {"n": 6253, "median_ex21_pct": -1.81, "mean_ex21_pct": -1.24, "hit21_pct": 40.4, "median_ex63_pct": -3.75, "mean_ex63_pct": -0.66, "hit63_pct": 39.9}
- `04:02:03` gates 3: {"n": 333, "median_ex21_pct": -1.32, "mean_ex21_pct": -1.67, "hit21_pct": 35.7, "median_ex63_pct": -4.61, "mean_ex63_pct": -3.01, "hit63_pct": 30.9}
- `04:02:03` 3/3 tight: {"n": 140, "median_ex21_pct": -1.94, "mean_ex21_pct": -2.16, "hit21_pct": 32.9, "median_ex63_pct": -5.22, "mean_ex63_pct": -3.69, "hit63_pct": 30.0}
- `04:02:03` resilient vs not: {"resilient": {"n": 4487, "median_ex21_pct": -0.97, "mean_ex21_pct": -0.7, "hit21_pct": 42.5, "median_ex63_pct": -3.98, "mean_ex63_pct": -2.28, "hit63_pct": 36.7}, "not_resilient": {"n": 49725, "median_ex21_pct": -1.22, "mean_ex21_pct": -0.21, "hit21_pct": 44.7, "median_ex63_pct": -2.86, "mean_ex63_pct": 0.43, "hit63_pct": 43.6}}
- `04:02:03` under only: {"n": 14521, "median_ex21_pct": -1.85, "mean_ex21_pct": -1.18, "hit21_pct": 42.1, "median_ex63_pct": -4.24, "mean_ex63_pct": -0.89, "hit63_pct": 41.1} knife: {"n": 3552, "median_ex21_pct": -7.93, "mean_ex21_pct": -6.53, "hit21_pct": 35.1, "median_ex63_pct": -20.26, "mean_ex63_pct": -14.1, "hit63_pct": 30.5}
- `04:02:03` decile D1: {"n": 5421, "median_ex21_pct": -1.29, "mean_ex21_pct": -0.31, "hit21_pct": 44.3, "median_ex63_pct": -3.25, "mean_ex63_pct": -0.93, "hit63_pct": 42.6, "capture_lo": -30.65, "capture_hi": 0.2}
- `04:02:03` decile D2: {"n": 5421, "median_ex21_pct": -0.95, "mean_ex21_pct": -0.35, "hit21_pct": 44.2, "median_ex63_pct": -2.84, "mean_ex63_pct": -0.76, "hit63_pct": 41.8, "capture_lo": 0.2, "capture_hi": 0.51}
- `04:02:03` decile D3: {"n": 5421, "median_ex21_pct": -1.05, "mean_ex21_pct": -0.45, "hit21_pct": 43.1, "median_ex63_pct": -3.15, "mean_ex63_pct": -0.98, "hit63_pct": 40.5, "capture_lo": 0.51, "capture_hi": 0.71}
- `04:02:03` decile D4: {"n": 5421, "median_ex21_pct": -1.26, "mean_ex21_pct": -0.76, "hit21_pct": 42.8, "median_ex63_pct": -3.33, "mean_ex63_pct": -1.41, "hit63_pct": 41.1, "capture_lo": 0.71, "capture_hi": 0.9}
- `04:02:03` decile D5: {"n": 5421, "median_ex21_pct": -1.33, "mean_ex21_pct": -0.99, "hit21_pct": 42.7, "median_ex63_pct": -3.25, "mean_ex63_pct": -1.64, "hit63_pct": 40.6, "capture_lo": 0.9, "capture_hi": 1.06}
- `04:02:03` decile D6: {"n": 5421, "median_ex21_pct": -0.86, "mean_ex21_pct": -0.36, "hit21_pct": 45.7, "median_ex63_pct": -2.18, "mean_ex63_pct": -0.15, "hit63_pct": 44.3, "capture_lo": 1.06, "capture_hi": 1.24}
- `04:02:03` decile D7: {"n": 5421, "median_ex21_pct": -0.88, "mean_ex21_pct": 0.14, "hit21_pct": 46.5, "median_ex63_pct": -2.12, "mean_ex63_pct": 1.46, "hit63_pct": 45.4, "capture_lo": 1.24, "capture_hi": 1.44}
- `04:02:03` decile D8: {"n": 5421, "median_ex21_pct": -1.24, "mean_ex21_pct": -0.69, "hit21_pct": 44.9, "median_ex63_pct": -2.81, "mean_ex63_pct": -0.15, "hit63_pct": 44.5, "capture_lo": 1.44, "capture_hi": 1.71}
- `04:02:03` decile D9: {"n": 5421, "median_ex21_pct": -1.32, "mean_ex21_pct": 0.12, "hit21_pct": 46.2, "median_ex63_pct": -2.29, "mean_ex63_pct": 2.53, "hit63_pct": 46.1, "capture_lo": 1.71, "capture_hi": 2.16}
- `04:02:03` decile D10: {"n": 5423, "median_ex21_pct": -2.22, "mean_ex21_pct": 1.15, "hit21_pct": 44.7, "median_ex63_pct": -5.77, "mean_ex63_pct": 4.1, "hit63_pct": 43.0, "capture_lo": 2.16, "capture_hi": 6.73}
- `04:02:03` date {"date": "2025-12-26", "n_scored": 3617, "spy_fwd21_pct": 0.74, "spy_fwd63_pct": -8.45, "n_fortress3": 34, "fortress3_median_ex21_pct": 0.25, "fortress3_hit21_pct": 55.9, "n_dump_episodes_asof": 7}
- `04:02:03` date {"date": "2026-01-20", "n_scored": 3668, "spy_fwd21_pct": 1.02, "spy_fwd63_pct": 3.91, "n_fortress3": 29, "fortress3_median_ex21_pct": -0.14, "fortress3_hit21_pct": 44.8, "n_dump_episodes_asof": 7}
- `04:02:03` date {"date": "2026-02-10", "n_scored": 3629, "spy_fwd21_pct": -3.77, "spy_fwd63_pct": 6.65, "n_fortress3": 18, "fortress3_median_ex21_pct": -0.78, "fortress3_hit21_pct": 38.9, "n_dump_episodes_asof": 7}
- `04:02:03` date {"date": "2026-03-04", "n_scored": 3566, "spy_fwd21_pct": -4.28, "spy_fwd63_pct": 10.09, "n_fortress3": 6, "fortress3_median_ex21_pct": 1.16, "fortress3_hit21_pct": 66.7, "n_dump_episodes_asof": 7}
- `04:02:03` date {"date": "2026-03-25", "n_scored": 3592, "spy_fwd21_pct": 8.7, "spy_fwd63_pct": 11.8, "n_fortress3": 7, "fortress3_median_ex21_pct": -9.55, "fortress3_hit21_pct": 0.0, "n_dump_episodes_asof": 7}
- `04:02:03` date {"date": "2026-04-16", "n_scored": 3607, "spy_fwd21_pct": 5.35, "spy_fwd63_pct": 5.93, "n_fortress3": 15, "fortress3_median_ex21_pct": -5.07, "fortress3_hit21_pct": 20.0, "n_dump_episodes_asof": 7}
- `04:02:03` date {"date": "2026-05-07", "n_scored": 3572, "spy_fwd21_pct": 1.04, "spy_fwd63_pct": 5.7, "n_fortress3": 35, "fortress3_median_ex21_pct": -2.35, "fortress3_hit21_pct": 20.0, "n_dump_episodes_asof": 7}
- `04:02:03` date {"date": "2026-05-29", "n_scored": 3621, "spy_fwd21_pct": -1.28, "spy_fwd63_pct": 1.7, "n_fortress3": 14, "fortress3_median_ex21_pct": 1.37, "fortress3_hit21_pct": 57.1, "n_dump_episodes_asof": 7}
## G9 daily re-run carries the validation block

## Soft: page from the edge

- `04:03:47` ✅ fortress.html live at the edge with marker fortress-v2.0.0 (50420 bytes)
- `04:03:47` ✅ PASS_ALL -- justhodl-fortress live: 5181 scored, tiers {'COILED': 39, 'ACCUMULATING': 334, 'WATCH': 1212, 'SCREENED': 3596}, session 2026-08-31
