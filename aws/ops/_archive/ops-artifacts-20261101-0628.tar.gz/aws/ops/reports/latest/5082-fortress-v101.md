# ops 5082 -- justhodl-fortress v1.0.1 redeploy + verified re-run

**Status:** success  
**Duration:** 56.8s  
**Finished:** 2026-09-01T00:27:16+00:00  

## Data

| as_of | base_rates | board | coverage_pct | donor | elapsed_s | etf_tiers | g1 | g2 | g3 | g4 | g5 | g6 | g7 | keys | last_update | ledger | memory | n_rows_sampled | n_scored | n_universe_bars | note | picks | runtime | schedule | schedule_expr | schedule_state | session | sessions_loaded | snapshot | state | tiers | timeout | top_picks |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|  |  |  |  | justhodl-equity-research |  |  | PASS |  |  |  |  |  |  | ['FMP_KEY', 'FORTRESS_VERSION', 'POLYGON_API_KEY'] |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  | PASS |  |  |  |  |  |  | Successful |  | 3008 |  |  |  |  |  | python3.12 |  |  |  |  |  |  | Active |  | 900 |  |
|  |  |  |  |  |  |  |  |  | PASS |  |  |  |  |  |  |  |  |  |  |  |  |  |  | updated |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | cron(30 3 ? * TUE-SAT *) | ENABLED |  |  |  |  |  |  |  |
| 2026-09-01T00:27:08+00:00 |  |  |  |  | 36.5 | {'ETF_FORTRESS': 2, 'ETF_COILED': 6, 'ETF_WATCH': 32, 'SCREENED': 94} |  |  |  | PASS |  |  |  |  |  |  |  |  | 5725 | 11608 |  |  |  |  |  |  | 2026-08-28 | 330 |  |  | {'FORTRESS_COIL': 5, 'COILED': 80, 'ACCUMULATING': 534, 'WATCH': 1452, 'SCREENED': 3654} |  |  |
|  |  |  | {'dump_capture': 100.0, 'bb_width_pctile': 99.1, 'valuation_score': 87.3, 'flow_score': 100.0, 'vs_ema250_pct': 91.2, 'growth_score': 98.1, 'safety_score': 100.0} |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 3300 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | 800 |  |  |  |  |  |  |  |  | PASS |  |  |  |  | 2500 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 60 |
|  | accruing |  |  |  |  |  |  |  |  |  |  | PASS |  |  |  |  |  |  |  |  |  | 400 |  |  |  |  |  |  | data/fortress/history/2026-08-28.json.gz |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  | PASS |  |  |  |  |  |  |  | justhodl-signal-harvester reads data/fortress.json top_picks as eng:fortress at 23:15 UTC |  |  |  |  |  |  |  |  |  |  |  | 60 |

## Log
## G1 key inheritance

## G2 deploy

- `00:26:20`   zip: 125561 bytes
## 1. Lambda

- `00:26:20`   Lambda exists — updating
- `00:26:26` ✅   ✓ updated justhodl-fortress
## G3 schedule (EventBridge Scheduler -- classic rule cap is saturated)

## G4 first run (async, verified on disk)

- `00:26:31` async invoke fired at 2026-09-01T00:26:20+00:00; polling data/fortress.json (prev as_of=2026-09-01T00:20:54+00:00)
- `00:27:16`   engine:   11.7s bars 144/330 sessions, 9936 tickers
- `00:27:16`   engine:   13.3s bars 168/330 sessions, 10111 tickers
- `00:27:16`   engine:   15.0s bars 192/330 sessions, 10290 tickers
- `00:27:16`   engine:   16.6s bars 216/330 sessions, 10455 tickers
- `00:27:16`   engine:   18.3s bars 240/330 sessions, 10622 tickers
- `00:27:16`   engine:   20.1s bars 264/330 sessions, 10852 tickers
- `00:27:16`   engine:   21.8s bars 288/330 sessions, 11172 tickers
- `00:27:16`   engine:   23.6s bars 312/330 sessions, 11434 tickers
- `00:27:16`   engine:   24.9s bars 330/330 sessions, 11608 tickers
- `00:27:16`   engine:   25.0s market: 3 dump episodes (1 big), 12 worst days, SPY vs EMA250 9.56%
- `00:27:16`   engine:   35.1s stock rows built: 5725 (finviz-matched 5938)
- `00:27:16`   engine:   36.0s etf rows built: 134
## G5 real-data assertions (from S3, independent of the engine's own view)

- `00:27:16` probe MSFT: tier=SCREENED comp=48.3 capture=2.3 worst_bps=27.012 vsEMA250=14.048 bbw_pct=38.492 val=34.937 growth=73.637 flows=58.813 etf=IGV
- `00:27:16` board FORTRESS_COIL INVA comp=78.8 asym=16.23 cap=-1.77 ema=-0.5924 bbw=5.5556 val=95.6715 g=60.6306 fl=69.375 bk=None ct=None flags=['MAJOR_INFLOWS', 'TIGHT_COIL']
- `00:27:16`       - ROSE while SPY dumped: capture -1.77 across 3 drawdown episode(s), flat-or-up in 100% of them
- `00:27:16`       - on SPY's 12 worst days: +169 bps vs SPY, green 42% of the time
- `00:27:16`       - 0.6% below the 250-day EMA
- `00:27:16`       - Bollinger bandwidth in the 6th percentile of its own year -- TTM squeeze ON for 12 sessions
- `00:27:16`       - valuation cheaper than 96% of its industry peers
- `00:27:16` board FORTRESS_COIL UNCY comp=77.4 asym=16.27 cap=-1.42 ema=-11.2181 bbw=14.6825 val=94.697 g=92.7244 fl=69.375 bk=None ct=None flags=['MAJOR_INFLOWS']
- `00:27:16`       - ROSE while SPY dumped: capture -1.42 across 3 drawdown episode(s), flat-or-up in 67% of them
- `00:27:16`       - on SPY's 12 worst days: +64 bps vs SPY, green 25% of the time
- `00:27:16`       - 11.2% below the 250-day EMA
- `00:27:16`       - Bollinger bandwidth in the 15th percentile of its own year -- TTM squeeze ON for 1 sessions
- `00:27:16`       - valuation cheaper than 95% of its industry peers
- `00:27:16` board FORTRESS_COIL PHAT comp=74.6 asym=8.81 cap=-0.39 ema=-16.1736 bbw=18.6508 val=80.766 g=100.0 fl=69.375 bk=None ct=None flags=['MAJOR_GROWTH', 'MAJOR_INFLOWS']
- `00:27:16`       - ROSE while SPY dumped: capture -0.39 across 3 drawdown episode(s), flat-or-up in 67% of them
- `00:27:16`       - on SPY's 12 worst days: +141 bps vs SPY, green 58% of the time
- `00:27:16`       - 16.2% below the 250-day EMA
- `00:27:16`       - Bollinger bandwidth in the 19th percentile of its own year
- `00:27:16`       - valuation cheaper than 81% of its industry peers
- `00:27:16` board FORTRESS_COIL ATEC comp=66.3 asym=4.97 cap=-1.94 ema=-20.7054 bbw=11.5079 val=58.9296 g=75.4551 fl=77.0 bk=None ct=None flags=['MAJOR_INFLOWS']
- `00:27:16`       - ROSE while SPY dumped: capture -1.94 across 3 drawdown episode(s), flat-or-up in 67% of them
- `00:27:16`       - on SPY's 12 worst days: +22 bps vs SPY, green 25% of the time
- `00:27:16`       - 20.7% below the 250-day EMA
- `00:27:16`       - Bollinger bandwidth in the 12th percentile of its own year
- `00:27:16`       - valuation cheaper than 59% of its industry peers (PEG 0.10)
- `00:27:16` board FORTRESS_COIL RGR comp=66.1 asym=4.55 cap=-0.03 ema=-1.7024 bbw=16.6667 val=89.5552 g=74.3516 fl=61.3333 bk=None ct=None flags=['MAJOR_GROWTH', 'MAJOR_INFLOWS']
- `00:27:16`       - ROSE while SPY dumped: capture -0.03 across 3 drawdown episode(s), flat-or-up in 67% of them
- `00:27:16`       - on SPY's 12 worst days: +17 bps vs SPY, green 8% of the time
- `00:27:16`       - 1.7% below the 250-day EMA
- `00:27:16`       - Bollinger bandwidth in the 17th percentile of its own year -- TTM squeeze ON for 2 sessions
- `00:27:16`       - valuation cheaper than 90% of its industry peers
- `00:27:16` board COILED UHS comp=73.2 asym=4.17 cap=-0.01 ema=-4.3011 bbw=5.1587 val=90.9604 g=50.5322 fl=48.4375 bk=None ct=None flags=['TIGHT_COIL']
- `00:27:16`       - ROSE while SPY dumped: capture -0.01 across 3 drawdown episode(s), flat-or-up in 67% of them
- `00:27:16`       - on SPY's 12 worst days: +172 bps vs SPY, green 33% of the time
- `00:27:16`       - 4.3% below the 250-day EMA
- `00:27:16`       - Bollinger bandwidth in the 5th percentile of its own year -- TTM squeeze ON for 5 sessions
- `00:27:16`       - valuation cheaper than 91% of its industry peers (PEG 1.00)
- `00:27:16` board COILED QTTB comp=72.9 asym=4.02 cap=-0.41 ema=88.1536 bbw=5.1587 val=64.0721 g=63.6037 fl=69.375 bk=None ct=None flags=['MAJOR_INFLOWS', 'TIGHT_COIL']
- `00:27:16`       - ROSE while SPY dumped: capture -0.41 across 3 drawdown episode(s), flat-or-up in 67% of them
- `00:27:16`       - on SPY's 12 worst days: +243 bps vs SPY, green 58% of the time
- `00:27:16`       - 88.2% above the 250-day EMA
- `00:27:16`       - Bollinger bandwidth in the 5th percentile of its own year -- TTM squeeze ON for 15 sessions
- `00:27:16`       - valuation cheaper than 64% of its industry peers
- `00:27:16` board COILED HRMY comp=71.9 asym=2.04 cap=-2.74 ema=14.5315 bbw=19.8413 val=99.2135 g=67.6435 fl=69.375 bk=None ct=None flags=['MAJOR_GROWTH', 'MAJOR_INFLOWS']
- `00:27:16`       - ROSE while SPY dumped: capture -2.74 across 3 drawdown episode(s), flat-or-up in 67% of them
- `00:27:16`       - on SPY's 12 worst days: +125 bps vs SPY, green 33% of the time
- `00:27:16`       - 14.5% above the 250-day EMA
- `00:27:16`       - Bollinger bandwidth in the 20th percentile of its own year
- `00:27:16`       - valuation cheaper than 99% of its industry peers (PEG 0.43)
- `00:27:16` episodes: [{"peak_date": "2025-10-29", "trough_date": "2025-11-20", "spy_dd_pct": -5.07, "closed": true}, {"peak_date": "2026-01-27", "trough_date": "2026-03-30", "spy_dd_pct": -9.13, "closed": true}, {"peak_date": "2026-06-02", "trough_date": "2026-06-10", "spy_dd_pct": -4.49, "closed": true}]
- `00:27:16` industries top: [{"etf": "IGV", "n_stocks": 464, "tiers": {"COILED": 22, "ACCUMULATING": 77, "WATCH": 115, "SCREENED": 250}, "flow_score": 58.8, "inflow_major": false}, {"etf": "XBI", "n_stocks": 577, "tiers": {"FORTRESS_COIL": 3, "COILED": 10, "ACCUMULATING": 58, "WATCH": 119, "SCREENED": 387}, "flow_score": 69.4, "inflow_major": true}, {"etf": "IHI", "n_stocks": 194, "tiers": {"FORTRESS_COIL": 1, "COILED": 9, "ACCUMULATING": 28, "WATCH": 52, "SCREENED": 104}, "flow_score": 77.0, "inflow_major": true}, {"etf": "KRE", "n_stocks": 319, "tiers": {"COILED": 1, "ACCUMULATING": 44, "WATCH": 134, "SCREENED": 140}, "flow_score": 18.7, "inflow_major": false}, {"etf": "XLRE", "n_stocks": 248, "tiers": {"COILED": 8, "ACCUMULATING": 24, "WATCH": 66, "SCREENED": 150}, "flow_score": 45.2, "inflow_major": false}, {"etf": "XLB", "n_stocks": 100, "tiers": {"COILED": 2, "ACCUMULATING": 30, "WATCH": 31, "SCREENED": 37}, "flow_score": 61.0, "inflow_major": false}, {"etf": "XLF", "n_stocks": 870, "tiers": {"COILED": 1, "ACCUMULATING": 30, "WATCH": 105, "SCREENED": 734}, "flow_score": 27.0, "inflow_major": false}, {"etf": "XLP", "n_stocks": 231, "tiers": {"COILED": 2, "ACCUMULATING": 25, "WATCH": 52, "SCREENED": 152}, "flow_score": 42.4, "inflow_major": false}]
- `00:27:16` etfs top: [{"ticker": "UNG", "tier": "ETF_FORTRESS", "composite": 71.6, "dump_capture": -0.14, "flow_score": 71.875}, {"ticker": "INDA", "tier": "ETF_FORTRESS", "composite": 63.9, "dump_capture": 0.34, "flow_score": 78.0253}, {"ticker": "TLT", "tier": "ETF_COILED", "composite": 67.6, "dump_capture": 0.2, "flow_score": 89.125}, {"ticker": "VGLT", "tier": "ETF_COILED", "composite": 62.2, "dump_capture": 0.2, "flow_score": 66.125}, {"ticker": "EDV", "tier": "ETF_COILED", "composite": 62.1, "dump_capture": 0.28, "flow_score": 75.0}, {"ticker": "EWL", "tier": "ETF_COILED", "composite": 61.8, "dump_capture": 0.25, "flow_score": 100.0}, {"ticker": "ITB", "tier": "ETF_COILED", "composite": 59.4, "dump_capture": 1.35, "flow_score": 84.625}, {"ticker": "MCHI", "tier": "ETF_COILED", "composite": 51.7, "dump_capture": 1.39, "flow_score": 69.8872}]
- `00:27:16` inputs: {"bars": "data/warm/polygon-full/grouped/ (2025-05-07..2026-08-28, 330 sessions)", "finviz_universe": "2026-08-31T22:00:37.715951+00:00", "fundamental_census_matrix": "2026-09-01T00:07:52.042094+00:00", "industry_boom": "2026-08-31T10:50:03.806562+00:00", "industry_rotation": "2026-08-31T21:38:24.333669+00:00", "etf_flows_polygon": "2026-08-31T22:00:25.581028+00:00", "etf_true_flows": "2026-08-31T15:45:23.111432+00:00", "backlog": "2026-08-31T11:30:46.752693+00:00", "backlog_mined": "2026-08-31T02:30:09+00:00", "deal_history": "2026-09-01T00:05:24.255543+00:00", "catalyst": "2026-08-31T02:29:32+00:00", "floor_audit": "2026-08-31T21:37:21+00:00", "resilience": "2026-08-31T22:46:01.117625+00:00", "f13_flows": "2026-08-31T23:06:38.303422+00:00", "short_interest": "2026-08-31T21:15:38.904686+00:00", "insider_radar": "2026-08-31T14:40:32.785479+00:00", "estimate_revisions": "2026-08-31T17:40:22.896922+00:00", "sp500": "2026-08-31T21:45:45.403867+00:00"}
- `00:27:16` capture distribution over 3299 sampled rows: p10 -0.94 p25 -0.19 p50 0.62 p75 2.17 p90 4.09; <=0.35: 1430; <0: 1036
- `00:27:16` worst-day excess bps: p10 -215 p50 56 p90 202; >=25: 1828
- `00:27:16` bb width pctile: p10 4 p50 37; <=20: 1069; squeeze on: 1138
- `00:27:16` worst days: [{"date": "2025-10-10", "spy_ret_pct": -2.7}, {"date": "2026-06-05", "spy_ret_pct": -2.58}, {"date": "2026-01-20", "spy_ret_pct": -2.04}, {"date": "2026-03-26", "spy_ret_pct": -1.79}, {"date": "2026-03-27", "spy_ret_pct": -1.71}, {"date": "2026-03-20", "spy_ret_pct": -1.7}, {"date": "2025-11-13", "spy_ret_pct": -1.66}, {"date": "2026-06-10", "spy_ret_pct": -1.58}, {"date": "2026-02-12", "spy_ret_pct": -1.54}, {"date": "2026-07-29", "spy_ret_pct": -1.54}, {"date": "2025-11-20", "spy_ret_pct": -1.52}, {"date": "2026-03-12", "spy_ret_pct": -1.52}]
- `00:27:16` breadth: {"pct_under_ema250": 48.7, "pct_coiled": 32.4, "pct_dump_resilient": 36.8}
- `00:27:16` etf ETF_FORTRESS UNG comp=71.6 cap=-0.14 worst=340.4339 ema=-15.062 bbw=8.3333 flow=71.875 vol100=36.3284 aum=538902311.0 type=Global Commodities & Metals | United States Natural Gas Fund
- `00:27:16` etf ETF_FORTRESS INDA comp=63.9 cap=0.34 worst=73.3856 ema=-2.8457 bbw=4.7619 flow=78.0253 vol100=15.8265 aum=6724626384.0 type=Global Ex. US Equities | iShares MSCI India ETF
- `00:27:16` etf ETF_COILED TLT comp=67.6 cap=0.2 worst=142.9626 ema=-3.7043 bbw=26.1905 flow=89.125 vol100=9.2986 aum=47239105422.0 type=US Bonds | iShares 20+ Year Treasury Bond ETF
- `00:27:16` etf ETF_COILED VGLT comp=62.2 cap=0.2 worst=144.1727 ema=-3.2706 bbw=25.0 flow=66.125 vol100=8.5875 aum=10596443162.0 type=US Bonds | Vanguard Long-Term Treasury ETF
- `00:27:16` etf ETF_COILED EDV comp=62.1 cap=0.28 worst=124.323 ema=-5.5938 bbw=34.127 flow=75.0 vol100=14.6622 aum=3715712000.0 type=US Bonds | Vanguard Extended Duration Treasury ETF
- `00:27:16` etf ETF_COILED EWL comp=61.8 cap=0.25 worst=96.1286 ema=5.4361 bbw=5.5556 flow=100.0 vol100=17.2853 aum=2436774609.0 type=Global Ex. US Equities | iShares MSCI Switzerland ETF
- `00:27:16` etf ETF_COILED ITB comp=59.4 cap=1.35 worst=5.4633 ema=-2.3322 bbw=0.3968 flow=84.625 vol100=32.4484 aum=2404076910.0 type=US Equities | iShares U.S. Home Construction ETF
- `00:27:16` etf ETF_COILED MCHI comp=51.7 cap=1.39 worst=17.7982 ema=-3.626 bbw=2.381 flow=69.8872 vol100=19.1926 aum=6361740288.0 type=Global Ex. US Equities | iShares MSCI China ETF
- `00:27:16` etf ETF_WATCH SPLV comp=63.8 cap=-0.34 worst=166.8667 ema=1.4355 bbw=5.1587 flow=45.2917 vol100=11.9516 aum=7148654217.0 type=US Equities | Invesco S&P 500 Low Volatility ETF
- `00:27:16` etf ETF_WATCH XLP comp=62.9 cap=-0.12 worst=222.4875 ema=3.1175 bbw=7.1429 flow=42.4062 vol100=16.4986 aum=14611264874.0 type=US Equities | State Street Consumer Staples Select Sec
- `00:27:16` etf ETF_WATCH XLU comp=62.3 cap=-0.05 worst=142.5864 ema=-2.9491 bbw=31.3492 flow=52.3125 vol100=16.3436 aum=22012028582.0 type=US Equities | State Street Utilities Select Sector SPD
- `00:27:16` etf ETF_WATCH EWP comp=59.5 cap=0.5 worst=38.8794 ema=13.8527 bbw=0.3968 flow=91.7855 vol100=18.8049 aum=2259770940.0 type=Global Ex. US Equities | iShares MSCI Spain ETF
- `00:27:16` etf ETF_WATCH DBA comp=57.2 cap=0.28 worst=152.167 ema=7.9334 bbw=82.1429 flow=86.875 vol100=13.0673 aum=1331317680.0 type=Global Commodities & Metals | Invesco DB Agriculture Fund
- `00:27:16` etf ETF_WATCH XBI comp=56.5 cap=-0.19 worst=23.2028 ema=27.4008 bbw=80.9524 flow=69.375 vol100=30.4819 aum=11509359528.0 type=US Equities | State Street SPDR S&P Biotech ETF
- `00:27:16` row FORTRESS_COIL INVA small Biotechnology cap=-1.77 n_ep=3 worst=168.638 green=0.4167 dc=-9.6041 bbw=5.5556 sq=12 vol100=24.5171 adv=13485001.2923 px=20.97 eps=[(20.43, -4.03), (16.18, -1.77), (7.73, -1.72)] risks=[]
- `00:27:16` row FORTRESS_COIL UNCY micro Biotechnology cap=-1.42 n_ep=3 worst=63.8505 green=0.25 dc=54.1456 bbw=14.6825 sq=1 vol100=106.6315 adv=3835546.0363 px=5.265 eps=[(9.79, -1.93), (-15.14, 1.66), (6.36, -1.42)] risks=['thin liquidity: $3.8M average daily dollar volume']
- `00:27:16` row FORTRESS_COIL PHAT small Biotechnology cap=-0.39 n_ep=3 worst=141.0449 green=0.5833 dc=100.448 bbw=18.6508 sq=0 vol100=72.1391 adv=11636377.5972 px=9.18 eps=[(6.13, -1.21), (-26.0, 2.85), (1.76, -0.39)] risks=[]
- `00:27:16` row FORTRESS_COIL ATEC small Medical Devices cap=-1.94 n_ep=3 worst=22.4663 green=0.25 dc=113.7976 bbw=11.5079 sq=0 vol100=87.5379 adv=20324966.5254 px=9.44 eps=[(18.92, -3.73), (-27.92, 3.06), (8.69, -1.94)] risks=['max drawdown -69% over the year']
- `00:27:16` row FORTRESS_COIL RGR small Aerospace & Defense cap=-0.03 n_ep=3 worst=16.6768 green=0.0833 dc=75.4867 bbw=16.6667 sq=2 vol100=27.6585 adv=4534161.5602 px=37.26 eps=[(-34.7, 6.84), (5.43, -0.59), (0.13, -0.03)] risks=['thin liquidity: $4.5M average daily dollar volume']
- `00:27:16` row COILED UHS large Medical Care Facilitie cap=-0.01 n_ep=3 worst=171.682 green=0.3333 dc=36.9718 bbw=5.1587 sq=5 vol100=34.501 adv=108180062.9456 px=171.66 eps=[(0.04, -0.01), (-10.14, 1.11), (1.59, -0.35)] risks=[]
- `00:27:16` row COILED QTTB small Biotechnology cap=-0.41 n_ep=3 worst=242.8873 green=0.5833 dc=-402.9019 bbw=5.1587 sq=15 vol100=174.432 adv=6411608.2058 px=15.03 eps=[(-27.99, 5.52), (47.87, -5.24), (1.82, -0.41)] risks=[]
- `00:27:16` row COILED HRMY mid Biotechnology cap=-2.74 n_ep=3 worst=124.5727 green=0.3333 dc=63.1512 bbw=19.8413 sq=0 vol100=40.7304 adv=27408416.6218 px=39.21 eps=[(13.88, -2.74), (-28.61, 3.13), (14.78, -3.29)] risks=[]
- `00:27:16` row COILED RAMP mid Software - Infrastruct cap=-0.49 n_ep=3 worst=118.0554 green=0.3333 dc=37.8805 bbw=13.4921 sq=47 vol100=43.4451 adv=32940630.5817 px=37.74 eps=[(3.43, -0.68), (4.49, -0.49), (0.24, -0.05)] risks=[]
- `00:27:16` row COILED BFAM mid Personal Services cap=-1.04 n_ep=3 worst=203.9397 green=0.75 dc=-5.628 bbw=13.4921 sq=3 vol100=49.0804 adv=45927201.508 px=74.81 eps=[(5.28, -1.04), (-11.32, 1.24), (5.34, -1.19)] risks=[]
- `00:27:16` row COILED ZBH large Medical Devices cap=-0.33 n_ep=3 worst=137.6573 green=0.3333 dc=9.2958 bbw=6.746 sq=2 vol100=34.8969 adv=209346280.4596 px=100.91 eps=[(-10.67, 2.1), (3.06, -0.33), (5.28, -1.18)] risks=[]
- `00:27:16` row COILED SNDX small Biotechnology cap=-0.6 n_ep=3 worst=66.9388 green=0.25 dc=33.3768 bbw=2.381 sq=7 vol100=47.2405 adv=25465437.7965 px=19.54 eps=[(28.97, -5.71), (5.49, -0.6), (-4.4, 0.98)] risks=['short float 28% -- crowded short, violent both ways']
- `00:27:16` row COILED TBPH small Biotechnology cap=-1.13 n_ep=3 worst=181.0262 green=0.4167 dc=51.3545 bbw=7.5397 sq=25 vol100=16.593 adv=8638870.5454 px=17.05 eps=[(26.32, -5.19), (-23.01, 2.52), (5.07, -1.13)] risks=[]
- `00:27:16` row COILED ZKH small Internet Retail cap=-0.15 n_ep=3 worst=344.1236 green=0.5833 dc=88.0743 bbw=9.127 sq=17 vol100=61.4602 adv=1149839.7834 px=2.92 eps=[(2.67, -0.53), (-11.88, 1.3), (0.69, -0.15)] risks=['thin liquidity: $1.1M average daily dollar volume']
- `00:27:16` board tiers: {"FORTRESS_COIL": 5, "COILED": 80, "ACCUMULATING": 534, "WATCH": 181}
## G6 history snapshot

## G7 harvester contract

## Soft: page from the edge

- `00:27:16` ✅ fortress.html live at the edge with marker FORTRESS_COIL_V1 (37563 bytes)
- `00:27:16` ✅ PASS_ALL -- justhodl-fortress live: 5725 scored, tiers {'FORTRESS_COIL': 5, 'COILED': 80, 'ACCUMULATING': 534, 'WATCH': 1452, 'SCREENED': 3654}, session 2026-08-28
